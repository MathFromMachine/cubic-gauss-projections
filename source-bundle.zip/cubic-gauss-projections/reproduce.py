#!/usr/bin/env python3
"""Check this source companion and compile it against a prebuilt pinned OAI project."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
MANIFEST = json.loads((ROOT / 'sources.json').read_text())

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def imports(path):
    return [m for line in path.read_text().splitlines() if line.startswith('import ')
            for m in line[7:].split()]

def check_sources():
    records = {item['module']: item for item in MANIFEST['experimental_modules']}
    seen = set()
    for module in MANIFEST['experimental_build_order']:
        item = records[module]
        path = ROOT / item['path']
        if digest(path) != item['sha256']:
            raise RuntimeError('source hash mismatch: ' + item['path'])
        if imports(path) != item['imports']:
            raise RuntimeError('import-list mismatch: ' + module)
        for dep in imports(path):
            if dep in records and dep not in seen:
                raise RuntimeError('dependency order mismatch: ' + module + ' -> ' + dep)
            if dep not in records and dep not in MANIFEST['direct_external_imports']:
                raise RuntimeError('unrecorded external import: ' + dep)
        seen.add(module)
    if seen != set(records):
        raise RuntimeError('manifest and build-order sets differ')
    if (ROOT / 'SHA256SUMS').exists():
        for line in (ROOT / 'SHA256SUMS').read_text().splitlines():
            expected, relative = line.split('  ', 1)
            if digest(ROOT / relative) != expected:
                raise RuntimeError('package hash mismatch: ' + relative)
    return {'own_source_count': len(records), 'dependency_order': 'passed', 'source_hashes': 'passed'}

def check_environment(project):
    check_sources()
    project = project.resolve()
    if (project / 'lean-toolchain').read_text().strip() != MANIFEST['lean_toolchain']:
        raise RuntimeError('wrong Lean toolchain')
    for name in ['lakefile.lean', 'lake-manifest.json']:
        if digest(project / name) != digest(ROOT / 'config' / name):
            raise RuntimeError('project configuration mismatch: ' + name)
    for item in MANIFEST['oai_source_closure']:
        if digest(project / item['project_path']) != item['sha256']:
            raise RuntimeError('OAI source mismatch: ' + item['module'])
    return {'oai_source_count': len(MANIFEST['oai_source_closure']), 'pinned_oai_sources': 'passed',
            'toolchain_and_dependency_configuration': 'passed'}

def build(project, incremental=False):
    checked = check_environment(project)
    project = project.resolve()
    destination = ROOT / 'build'
    destination.mkdir(exist_ok=True)
    env = os.environ.copy()
    old_path = env.get('LEAN_PATH', '')
    env['LEAN_PATH'] = str(destination) + (':' + old_path if old_path else '')
    env['LEAN_NUM_THREADS'] = '2'
    results = []
    prior = {}
    if incremental and (destination / 'build-summary.json').exists():
        previous = json.loads((destination / 'build-summary.json').read_text())
        prior = {item['module']: item for item in previous['modules']}
    records = {item['module']: item for item in MANIFEST['experimental_modules']}
    rebuilt = set()
    for module in MANIFEST['experimental_build_order']:
        cached = prior.get(module)
        obj = destination / (module + '.olean')
        if (cached and obj.exists()
                and cached.get('source_sha256') == records[module]['sha256']
                and cached.get('olean_sha256') == digest(obj)
                and not any(dep in rebuilt for dep in records[module]['imports'])):
            result_record = dict(cached)
            result_record['verification_action'] = 'reused_prior_bundle_compilation'
            results.append(result_record)
            print('verified unchanged ' + module, flush=True)
            continue
        rebuilt.add(module)
        log = destination / (module + '.log')
        command = ['lake', 'env', 'lean', '-j2', '-M6144', '--root=' + str(ROOT / 'lean'),
                   '-o', str(destination / (module + '.olean')),
                   str(ROOT / 'lean' / (module + '.lean'))]
        with log.open('w') as stream:
            result = subprocess.run(command, cwd=project, env=env, stdout=stream,
                                    stderr=subprocess.STDOUT, check=False)
        if result.returncode:
            raise RuntimeError('Lean build failed: ' + module + '; see build/' + log.name)
        text = log.read_text()
        receipts = re.findall(r"'[^']+' depends on axioms:\s*\[[^\]]*\]", text)
        for receipt in receipts:
            names = set(re.search(r'\[([^\]]*)\]', receipt).group(1).replace('\n', ' ').split(','))
            names = {name.strip() for name in names if name.strip()}
            if not names <= {'propext', 'Classical.choice', 'Quot.sound'}:
                raise RuntimeError('unexpected axiom in ' + module)
        results.append({'module': module, 'exit_code': result.returncode, 'axiom_receipts': receipts,
                        'olean_sha256': digest(destination / (module + '.olean')),
                        'source_sha256': records[module]['sha256'],
                        'verification_action': 'compiled_this_run'})
        print('compiled ' + module, flush=True)
    report = {'kind': 'ordinary_Lean_compilation', 'fresh_export_kernel_replay': False,
              'environment': checked, 'modules': results,
              'compiled_this_run': len(rebuilt), 'verified_unchanged_modules': len(results)-len(rebuilt)}
    (destination / 'build-summary.json').write_text(json.dumps(report, indent=2) + '\n')
    print('COMPILATION_SUCCESS (not a separate exported-proof replay)')

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['check', 'verify-env', 'build'])
    parser.add_argument('project', type=Path, nargs='?')
    parser.add_argument('--incremental', action='store_true',
                        help='reuse hash-matching prior bundle compilation for unchanged modules')
    args = parser.parse_args()
    if args.command == 'check':
        print(json.dumps(check_sources(), indent=2))
    elif args.project is None:
        parser.error('verify-env and build require the prebuilt OAI project directory')
    elif args.command == 'verify-env':
        print(json.dumps(check_environment(args.project), indent=2))
    else:
        build(args.project, args.incremental)

if __name__ == '__main__':
    try:
        main()
    except (OSError, RuntimeError, ValueError) as error:
        print('ERROR: ' + str(error), file=sys.stderr)
        sys.exit(1)
