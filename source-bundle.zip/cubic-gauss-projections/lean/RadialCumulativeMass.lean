import SparseRadialSummability
import IdealPowerSums

/-! Actual cumulative mass of the three cusp radial coefficient families.
This file retains the squarefree/cube parametrization and uses the exact
short ideal half-power estimate; it is an input to the endpoint kernel bound. -/
namespace QRHExperimental.RadialCumulativeMass
noncomputable section
set_option maxHeartbeats 2000000
open OAI OAI.ActualEisensteinCubic OAI.ConcreteTraceCRT
open OAI.CubicEisenstein OAI.CompletedGauss
open QRHExperimental.SparseRadialSummability QRHExperimental.IdealPowerSums
open scoped BigOperators Classical
local notation "Eis" => OAI.ActualEisensteinCubic.O

abbrev SquarefreeIndex := {I : Ideal Eis // Squarefree I ∧ primaryGenerator I ≠ 0}
abbrev CubeIndex := {J : Ideal Eis // primaryGenerator J ≠ 0}
abbrev OuterIndex := Eisˣ × ℕ × CubeIndex
abbrev ReorderedIndex := OuterIndex × SquarefreeIndex

def squarefreeNonzero (I : SquarefreeIndex) : NonzeroIdeal :=
  ⟨I.val, primaryGenerator_ne_zero_ideal _ I.property.2⟩

lemma squarefreeNonzero_injective : Function.Injective squarefreeNonzero := by
  intro I J h
  exact Subtype.ext (congrArg (fun K : NonzeroIdeal => K.val) h)

def reorder (p : ReorderedIndex) : ThetaFullIndex :=
  (p.1.1, p.1.2.1, p.2, p.1.2.2)

lemma reorder_injective : Function.Injective reorder := by
  rintro ⟨⟨u,m,J⟩,I⟩ ⟨⟨v,n,K⟩,L⟩ h
  simp only [reorder, Prod.mk.injEq] at h ⊢
  tauto

def frequency (p : ReorderedIndex) : Eis := thetaFullFrequency (reorder p)

lemma frequency_injective : Function.Injective frequency :=
  thetaFullFrequency_injective.comp reorder_injective

lemma short_half_all (U : ℝ) (hU : 0 < U) :
    Summable (shortHalfTerm U) ∧
      (∑' I : NonzeroIdeal, shortHalfTerm U I) ≤ 512*U^(1/2:ℝ) := by
  by_cases h1 : 1 ≤ U
  · exact ⟨short_half_summable U h1, short_half_tsum_le U h1⟩
  · have hz : shortHalfTerm U = fun _ => 0 := by
      funext I
      exact if_neg (fun h => h1 ((norm_at_least_one I.val I.property).trans h))
    rw [hz]
    exact ⟨summable_zero, by simp only [tsum_zero]; positivity⟩

lemma squarefree_short_half (U : ℝ) (hU : 0 < U) :
    Summable (fun I : SquarefreeIndex => shortHalfTerm U (squarefreeNonzero I)) ∧
      (∑' I : SquarefreeIndex, shortHalfTerm U (squarefreeNonzero I)) ≤
        512*U^(1/2:ℝ) := by
  have hall := short_half_all U hU
  have hs := hall.1.comp_injective squarefreeNonzero_injective
  refine ⟨hs, ?_⟩
  apply le_trans _ hall.2
  exact Summable.tsum_le_tsum_of_inj squarefreeNonzero squarefreeNonzero_injective
    (fun I _ => by unfold shortHalfTerm; split <;> positivity)
    (fun _ => le_rfl) hs hall.1

def outerWeight (o : OuterIndex) : ℝ :=
  (3:ℝ)^(-(5/6:ℝ)*(o.2.1:ℝ)) *
    (Ideal.absNorm o.2.2.val:ℝ)^(-(5/2):ℝ)

lemma outerWeight_nonneg (o : OuterIndex) : 0 ≤ outerWeight o := by
  unfold outerWeight
  positivity

lemma outerWeight_summable : Summable outerWeight := by
  let fJ : CubeIndex → NonzeroIdeal := fun J =>
    ⟨J.val, primaryGenerator_ne_zero_ideal _ J.property⟩
  have hJi : Function.Injective fJ := by
    intro I J h
    exact Subtype.ext (congrArg (fun K : NonzeroIdeal => K.val) h)
  have hJ := (nonzeroIdeal_norm_rpow_summable (5/2) (by norm_num)).comp_injective hJi
  have hm : Summable (fun m : ℕ => (3:ℝ)^(-(5/6:ℝ)*(m:ℝ))) := by
    have hg := summable_geometric_of_lt_one
      (Real.rpow_nonneg (by norm_num : 0 ≤ (3:ℝ)) (-(5/6:ℝ)))
      (Real.rpow_lt_one_of_one_lt_of_neg (by norm_num : 1 < (3:ℝ)) (by norm_num))
    apply hg.congr
    intro m
    exact (Real.rpow_mul_natCast (by norm_num : 0 ≤ (3:ℝ)) _ m).symm
  have hp := hm.mul_of_nonneg hJ (fun _ => by positivity)
    (fun J => Real.rpow_nonneg (nonzeroIdeal_norm_pos (fJ J)).le _)
  let : Finite Eisˣ := PrimaryIdealUnitReindex.finite_units
  have hu : Summable (fun _ : Eisˣ => (1:ℝ)) := Summable.of_finite
  have hall := hu.mul_of_nonneg hp (fun _ => zero_le_one) (fun p =>
    mul_nonneg (Real.rpow_nonneg (by norm_num : 0 ≤ (3:ℝ)) _)
      (Real.rpow_nonneg (nonzeroIdeal_norm_pos (fJ p.2)).le _))
  apply hall.congr
  intro p
  simp only [outerWeight, fJ, Function.comp_apply, one_mul]

def cutoffWeight (T : ℝ) (p : ReorderedIndex) : ℝ :=
  (3:ℝ)^(-(1/3:ℝ)*(p.1.2.1:ℝ)) *
    (Ideal.absNorm p.1.2.2.val:ℝ)^(-1:ℝ) *
      shortHalfTerm (T / ((3:ℝ)^p.1.2.1 * (Ideal.absNorm p.1.2.2.val:ℝ)^3))
        (squarefreeNonzero p.2)

lemma cutoffWeight_nonneg (T : ℝ) (p : ReorderedIndex) : 0 ≤ cutoffWeight T p := by
  unfold cutoffWeight shortHalfTerm
  split <;> positivity

lemma cutoff_scale (T y : ℝ) (m : ℕ) (hT : 0 < T) (hy : 0 < y) :
    (3:ℝ)^(-(1/3:ℝ)*(m:ℝ)) * y^(-1:ℝ) *
      (512*(T/((3:ℝ)^m*y^3))^(1/2:ℝ)) =
    (512*Real.sqrt T) * ((3:ℝ)^(-(5/6:ℝ)*(m:ℝ)) * y^(-(5/2):ℝ)) := by
  rw [Real.div_rpow hT.le (by positivity), Real.mul_rpow (by positivity) (by positivity),
    ← Real.rpow_natCast_mul (by norm_num : 0 ≤ (3:ℝ)),
    ← Real.rpow_natCast_mul hy.le, Real.sqrt_eq_rpow]
  simp only [div_eq_mul_inv, mul_inv_rev]
  rw [← Real.rpow_neg hy.le, ← Real.rpow_neg (by norm_num : 0 ≤ (3:ℝ))]
  calc
    _ = (512*T^(1/2:ℝ)) *
      (((3:ℝ)^(-(1/3:ℝ)*(m:ℝ))*(3:ℝ)^(-((m:ℝ)*(1/2)))) *
        (y^(-1:ℝ)*y^(-((3:ℝ)*(1/2))))) := by ring
    _ = _ := by
      rw [← Real.rpow_add (by norm_num : 0 < (3:ℝ)), ← Real.rpow_add hy]
      congr 2 <;> congr 1 <;> ring

lemma cutoff_inner (T : ℝ) (hT : 0 < T) (o : OuterIndex) :
    Summable (fun I : SquarefreeIndex => cutoffWeight T (o,I)) ∧
      (∑' I : SquarefreeIndex, cutoffWeight T (o,I)) ≤
        (512*Real.sqrt T)*outerWeight o := by
  have hy := eligible_norm_pos o.2.2.val o.2.2.property
  have hU : 0 < T/((3:ℝ)^o.2.1*(Ideal.absNorm o.2.2.val:ℝ)^3) := by positivity
  have hb := squarefree_short_half _ hU
  refine ⟨?_, ?_⟩
  · simpa only [cutoffWeight] using hb.1.mul_left
      ((3:ℝ)^(-(1/3:ℝ)*(o.2.1:ℝ))*(Ideal.absNorm o.2.2.val:ℝ)^(-1:ℝ))
  simp only [cutoffWeight, tsum_mul_left]
  calc
    _ ≤ ((3:ℝ)^(-(1/3:ℝ)*(o.2.1:ℝ))*(Ideal.absNorm o.2.2.val:ℝ)^(-1:ℝ)) *
        (512*(T/((3:ℝ)^o.2.1*(Ideal.absNorm o.2.2.val:ℝ)^3))^(1/2:ℝ)) :=
      mul_le_mul_of_nonneg_left hb.2 (by positivity)
    _ = _ := cutoff_scale T _ o.2.1 hT hy

lemma cutoff_summable (T : ℝ) (hT : 0 < T) : Summable (cutoffWeight T) := by
  apply (summable_prod_of_nonneg (cutoffWeight_nonneg T)).mpr
  refine ⟨fun o => (cutoff_inner T hT o).1, ?_⟩
  exact ((outerWeight_summable).mul_left (512*Real.sqrt T)).of_nonneg_of_le
    (fun o => tsum_nonneg (fun I => cutoffWeight_nonneg T (o,I)))
    (fun o => (cutoff_inner T hT o).2)

lemma cutoff_tsum_le (T : ℝ) (hT : 0 < T) :
    (∑' p : ReorderedIndex, cutoffWeight T p) ≤
      (512*Real.sqrt T)*(∑' o : OuterIndex, outerWeight o) := by
  have hs := cutoff_summable T hT
  rw [hs.tsum_prod]
  calc
    _ ≤ ∑' o : OuterIndex, (512*Real.sqrt T)*outerWeight o :=
      hs.prod.tsum_le_tsum (fun o => (cutoff_inner T hT o).2)
        (outerWeight_summable.mul_left _)
    _ = _ := tsum_mul_left

def radialMassTerm (j : Fin 3) (z : ℂ) (T : ℝ) (h : Eis) : ℝ :=
  if sourceCuspRadialLength h ≤ T then ‖sourceCuspRadialCoefficient j z h‖ else 0

lemma radialMassTerm_nonneg (j : Fin 3) (z : ℂ) (T : ℝ) (h : Eis) :
    0 ≤ radialMassTerm j z T h := by
  unfold radialMassTerm
  split <;> positivity

lemma indexed_mass_bound (j : Fin 3) (z : ℂ) (T : ℝ) (p : ReorderedIndex) :
    radialMassTerm j z T (frequency p) ≤
      (radialConstant j*fixedCuspCoefficientBound)*cutoffWeight T p := by
  by_cases hb : sourceCuspRadialLength (frequency p) ≤ T
  · have hy := eligible_norm_pos p.1.2.2.val p.1.2.2.property
    have hden : 0 < (3:ℝ)^p.1.2.1*(Ideal.absNorm p.1.2.2.val:ℝ)^3 := by positivity
    have hcut : idealNorm (squarefreeNonzero p.2) ≤
        T/((3:ℝ)^p.1.2.1*(Ideal.absNorm p.1.2.2.val:ℝ)^3) := by
      apply (le_div_iff₀ hden).mpr
      simpa only [frequency, full_radial_length, reorder, squarefreeNonzero,
        idealNorm, mul_assoc, mul_comm, mul_left_comm] using hb
    have hh := full_radial_weight_bound j z 0 (reorder p)
    simp only [neg_zero, Real.rpow_zero, mul_one] at hh
    rw [radialMassTerm, if_pos hb]
    calc
      _ ≤ (radialConstant j*fixedCuspCoefficientBound)*sparseWeight 0 (reorder p) := hh
      _ = _ := by
        simp only [cutoffWeight]
        rw [shortHalfTerm, if_pos hcut]
        simp only [sparseWeight, reorder, squarefreeNonzero, idealNorm]
        norm_num
        ring_nf <;> simp
  · rw [radialMassTerm, if_neg hb]
    exact mul_nonneg (mul_nonneg (radialConstant_nonneg j) fixedCuspCoefficientBound_pos.le)
      (cutoffWeight_nonneg T p)

lemma radialMassTerm_outside (j : Fin 3) (z : ℂ) (T : ℝ) (h : Eis)
    (hh : h ∉ Set.range frequency) : radialMassTerm j z T h = 0 := by
  have hc : sourceCuspRadialCoefficient j z h = 0 := by
    by_cases hz : h = 0
    · subst h; exact sourceCuspRadialCoefficient_zero j z
    · by_contra hc
      obtain ⟨p,hp⟩ := sourceCuspRadialCoefficient_full_support j z h hz hc
      apply hh
      exact ⟨((p.1,p.2.1,p.2.2.2),p.2.2.1),hp⟩
  simp only [radialMassTerm, hc, norm_zero, ite_self]

theorem sourceCuspRadialCoefficient_cumulative_mass (j : Fin 3) (z : ℂ)
    (T : ℝ) (hT : 0 < T) :
    Summable (radialMassTerm j z T) ∧
      (∑' h : Eis, radialMassTerm j z T h) ≤
        ((radialConstant j*fixedCuspCoefficientBound)*512*
          (∑' o : OuterIndex, outerWeight o))*Real.sqrt T := by
  let K := radialConstant j*fixedCuspCoefficientBound
  have hK : 0 ≤ K := mul_nonneg (radialConstant_nonneg j) fixedCuspCoefficientBound_pos.le
  have hc := cutoff_summable T hT
  have hp : Summable (fun p : ReorderedIndex => radialMassTerm j z T (frequency p)) :=
    (hc.mul_left K).of_nonneg_of_le (fun p => radialMassTerm_nonneg j z T (frequency p))
      (indexed_mass_bound j z T)
  have ha : Summable (radialMassTerm j z T) :=
    (frequency_injective.summable_iff (radialMassTerm_outside j z T)).mp hp
  refine ⟨ha, ?_⟩
  have he : (∑' h : Eis, radialMassTerm j z T h) =
      ∑' p : ReorderedIndex, radialMassTerm j z T (frequency p) :=
    (frequency_injective.tsum_eq (by
      intro h hh
      by_contra hn
      exact hh (radialMassTerm_outside j z T h hn))).symm
  rw [he]
  calc
    _ ≤ ∑' p : ReorderedIndex, K*cutoffWeight T p :=
      hp.tsum_le_tsum (indexed_mass_bound j z T) (hc.mul_left K)
    _ = K*(∑' p : ReorderedIndex, cutoffWeight T p) := tsum_mul_left
    _ ≤ K*((512*Real.sqrt T)*(∑' o : OuterIndex, outerWeight o)) :=
      mul_le_mul_of_nonneg_left (cutoff_tsum_le T hT) hK
    _ = _ := by dsimp only [K]; ring

theorem sourceCuspRadialCoefficient_cumulative_mass_uniform :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (j : Fin 3) (z : ℂ) (T : ℝ), 0 < T →
      Summable (radialMassTerm j z T) ∧
        (∑' h : Eis, radialMassTerm j z T h) ≤ C*Real.sqrt T := by
  let Cj : Fin 3 → ℝ := fun j => (radialConstant j*fixedCuspCoefficientBound)*512*
    (∑' o : OuterIndex, outerWeight o)
  have hCj : ∀ j, 0 ≤ Cj j := by
    intro j
    dsimp only [Cj]
    exact mul_nonneg (mul_nonneg (mul_nonneg (radialConstant_nonneg j)
      fixedCuspCoefficientBound_pos.le) (by norm_num)) (tsum_nonneg outerWeight_nonneg)
  refine ⟨∑ j : Fin 3, Cj j, Finset.sum_nonneg (fun j _ => hCj j), ?_⟩
  intro j z T hT
  have hb := sourceCuspRadialCoefficient_cumulative_mass j z T hT
  refine ⟨hb.1, hb.2.trans ?_⟩
  exact mul_le_mul_of_nonneg_right
    (Finset.single_le_sum (fun i _ => hCj i) (Finset.mem_univ j)) (Real.sqrt_nonneg T)

#print axioms sourceCuspRadialCoefficient_cumulative_mass
#print axioms sourceCuspRadialCoefficient_cumulative_mass_uniform
end
end QRHExperimental.RadialCumulativeMass
