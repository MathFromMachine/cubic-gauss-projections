import IdealConductorBound
import TrivialCompleted
import UniformTrivial
import IdealPowerSums

namespace QRHExperimental.CubeInverseAssembly
noncomputable section
set_option maxHeartbeats 2000000
open OAI OAI.ActualEisensteinCubic OAI.ConcreteTraceCRT
open OAI.CubicEisenstein OAI.CompletedGauss
open QRHExperimental.TrivialProjection QRHExperimental.TrivialCompleted
open QRHExperimental.IdealPowerSums
open scoped BigOperators Classical ContDiff
local notation "Eis" => OAI.ActualEisensteinCubic.O

def balancedCutoff (L R a : ℝ) : ℝ := L^(1/3:ℝ) * R^(-2*a/3)

lemma balancedCutoff_pos (L R a : ℝ) (hL : 0 < L) (hR : 0 < R) :
    0 < balancedCutoff L R a :=
  mul_pos (Real.rpow_pos_of_pos hL _) (Real.rpow_pos_of_pos hR _)

lemma balancedCutoff_ge_one (L R a : ℝ) (hL : 0 < L) (hR : 0 < R)
    (hlarge : R^(2*a) ≤ L) : 1 ≤ balancedCutoff L R a := by
  have hm := mul_le_mul_of_nonneg_right
    (Real.rpow_le_rpow (Real.rpow_nonneg hR.le _) hlarge (by norm_num : 0 ≤ (1/3:ℝ)))
    (Real.rpow_nonneg hR.le (-2*a/3))
  have he : (R^(2*a))^(1/3:ℝ)*R^(-2*a/3) = 1 := by
    rw [← Real.rpow_mul hR.le, ← Real.rpow_add hR]
    convert Real.rpow_zero R using 1 <;> congr 1 <;> ring
  simpa only [he, balancedCutoff] using hm

lemma balanced_short_power (L R a s : ℝ) (hL : 0 < L) (hR : 0 < R) :
    R^(a*(2*s+1)) * L^(-s) * (balancedCutoff L R a)^(3*s) = R^a := by
  rw [balancedCutoff, Real.mul_rpow (Real.rpow_nonneg hL.le _) (Real.rpow_nonneg hR.le _),
    ← Real.rpow_mul hL.le, ← Real.rpow_mul hR.le]
  calc
    _ = (L^(-s)*L^((1/3:ℝ)*(3*s))) *
        (R^(a*(2*s+1))*R^((-2*a/3)*(3*s))) := by ring
    _ = _ := by
      rw [← Real.rpow_add hL, ← Real.rpow_add hR,
        show -s+(1/3:ℝ)*(3*s)=0 by ring,
        show a*(2*s+1)+(-2*a/3)*(3*s)=a by ring, Real.rpow_zero, one_mul]

lemma balanced_tail_power (L R a : ℝ) (hL : 0 < L) (hR : 0 < R) :
    Real.sqrt L * (balancedCutoff L R a)^(-(3/2):ℝ) = R^a := by
  rw [Real.sqrt_eq_rpow, balancedCutoff,
    Real.mul_rpow (Real.rpow_nonneg hL.le _) (Real.rpow_nonneg hR.le _),
    ← Real.rpow_mul hL.le, ← Real.rpow_mul hR.le]
  calc
    _ = (L^(1/2:ℝ)*L^((1/3:ℝ)*(-(3/2):ℝ))) *
        R^((-2*a/3)*(-(3/2):ℝ)) := by ring
    _ = _ := by
      rw [← Real.rpow_add hL,
        show (1/2:ℝ)+(1/3:ℝ)*(-(3/2):ℝ)=0 by norm_num,
        show (-2*a/3)*(-(3/2):ℝ)=a by ring, Real.rpow_zero, one_mul]

lemma small_scale_sqrt (L R a : ℝ) (hL : 0 < L) (hR : 0 < R)
    (hsmall : L ≤ R^(2*a)) : Real.sqrt L ≤ R^a := by
  rw [Real.sqrt_eq_rpow]
  calc
    _ ≤ (R^(2*a))^(1/2:ℝ) := Real.rpow_le_rpow hL.le hsmall (by norm_num)
    _ = _ := by rw [← Real.rpow_mul hR.le]; congr 1; ring

lemma inverse_reflected_weight (L n s : ℝ) (hL : 0 < L) (hn : 0 < n) :
    n⁻¹ * (L/n^3)^(-s) = L^(-s) * n^(3*s-1) := by
  rw [Real.div_rpow hL.le (pow_nonneg hn.le _),
    ← Real.rpow_natCast_mul hn.le, div_eq_mul_inv,
    ← Real.rpow_neg hn.le, ← Real.rpow_neg_one]
  calc
    _ = L^(-s) * (n^(-1:ℝ) * n^(-((3:ℝ)*(-s)))) := by ring
    _ = _ := by rw [← Real.rpow_add hn]; congr 2 <;> ring

lemma inverse_trivial_weight (L n : ℝ) (hL : 0 < L) (hn : 0 < n) :
    n⁻¹ * Real.sqrt (L/n^3) = Real.sqrt L * n^(-(5/2):ℝ) := by
  rw [Real.sqrt_eq_rpow, Real.div_rpow hL.le (pow_nonneg hn.le _),
    ← Real.rpow_natCast_mul hn.le, div_eq_mul_inv,
    ← Real.rpow_neg hn.le, ← Real.rpow_neg_one, Real.sqrt_eq_rpow]
  calc
    _ = L^(1/2:ℝ) * (n^(-1:ℝ) * n^(-((3:ℝ)*(1/2)))) := by ring
    _ = _ := by rw [← Real.rpow_add hn]; norm_num

def inverseTerm (Ψ : Eis →* ℂ) (W : ℝ → ℂ) (L : ℝ) (H : NonzeroIdeal) : ℂ :=
  (UniqueFactorizationMonoid.moebius H.val:ℂ) * cubeWeight Ψ H.val *
    completedT Ψ W (L/(Ideal.absNorm H.val:ℝ)^3)

lemma inverseTerm_norm_le (Ψ : Eis →* ℂ) (hΨ : ∀ x, ‖Ψ x‖ ≤ 1)
    (W : ℝ → ℂ) (L : ℝ) (H : NonzeroIdeal) :
    ‖inverseTerm Ψ W L H‖ ≤ (Ideal.absNorm H.val:ℝ)⁻¹ *
      ‖completedT Ψ W (L/(Ideal.absNorm H.val:ℝ)^3)‖ := by
  rw [inverseTerm, norm_mul, norm_mul]
  apply mul_le_mul_of_nonneg_right _ (norm_nonneg _)
  calc
    _ ≤ 1 * (1/(Ideal.absNorm H.val:ℝ)) :=
      mul_le_mul (CubicEisenstein.norm_ideal_moebius_le_one H.val)
        (CanonicalRowCompletion.cubeWeight_norm_le Ψ hΨ H.val)
        (norm_nonneg _) (by norm_num)
    _ = _ := by ring

lemma actual_cube_inverse (Ψ : Eis →* ℂ) (W : ℝ → ℂ)
    (hW : HasCompactSupport W) (L : ℝ) (hL : 0 < L) :
    (Real.sqrt L:ℂ)⁻¹ * rawProjection Ψ W L = ∑' H : NonzeroIdeal, inverseTerm Ψ W L H := by
  rw [rawProjection, completed_cube_inverse Ψ W hW L hL]
  symm
  apply tsum_subtype_eq_of_support_subset
    (f := fun H : Ideal Eis => (UniqueFactorizationMonoid.moebius H:ℂ) * cubeWeight Ψ H *
      completedT Ψ W (L/(Ideal.absNorm H:ℝ)^3)) (s := {H : Ideal Eis | H ≠ 0})
  intro H hH hz
  subst H
  exact hH (by simp only [cubeWeight_zero, mul_zero, zero_mul])

lemma inverseTerm_reflected_bound (Ψ : Eis →* ℂ) (hΨ : ∀ x, ‖Ψ x‖ ≤ 1)
    (W : ℝ → ℂ) (L R a s K : ℝ) (hL : 0 < L)
    (href : ∀ y : ℝ, 0 < y →
      ‖completedT Ψ W y‖ ≤ K * R^(a*(2*s+1)) * y^(-s))
    (H : NonzeroIdeal) :
    ‖inverseTerm Ψ W L H‖ ≤
      (K * R^(a*(2*s+1)) * L^(-s)) * (Ideal.absNorm H.val:ℝ)^(3*s-1) := by
  have hn := nonzeroIdeal_norm_pos H
  calc
    _ ≤ (Ideal.absNorm H.val:ℝ)⁻¹ *
        (K * R^(a*(2*s+1)) * (L/(Ideal.absNorm H.val:ℝ)^3)^(-s)) :=
      (inverseTerm_norm_le Ψ hΨ W L H).trans
        (mul_le_mul_of_nonneg_left (href _ (div_pos hL (pow_pos hn _))) (inv_nonneg.mpr hn.le))
    _ = _ := by
      calc
        _ = (K * R^(a*(2*s+1))) *
          ((Ideal.absNorm H.val:ℝ)⁻¹ * (L/(Ideal.absNorm H.val:ℝ)^3)^(-s)) := by ring
        _ = _ := by rw [inverse_reflected_weight L _ s hL hn]; ring

lemma inverseTerm_trivial_bound (Ψ : Eis →* ℂ) (hΨ : ∀ x, ‖Ψ x‖ ≤ 1)
    (W : ℝ → ℂ) (L K : ℝ) (hL : 0 < L)
    (htriv : ∀ y : ℝ, 0 < y → ‖completedT Ψ W y‖ ≤ K * Real.sqrt y)
    (H : NonzeroIdeal) :
    ‖inverseTerm Ψ W L H‖ ≤
      (K * Real.sqrt L) * (Ideal.absNorm H.val:ℝ)^(-(5/2):ℝ) := by
  have hn := nonzeroIdeal_norm_pos H
  calc
    _ ≤ (Ideal.absNorm H.val:ℝ)⁻¹ * (K * Real.sqrt (L/(Ideal.absNorm H.val:ℝ)^3)) :=
      (inverseTerm_norm_le Ψ hΨ W L H).trans
        (mul_le_mul_of_nonneg_left (htriv _ (div_pos hL (pow_pos hn _))) (inv_nonneg.mpr hn.le))
    _ = _ := by
      calc
        _ = K * ((Ideal.absNorm H.val:ℝ)⁻¹ * Real.sqrt (L/(Ideal.absNorm H.val:ℝ)^3)) := by ring
        _ = _ := by rw [inverse_trivial_weight L _ hL hn]; ring

theorem rawProjection_bound_of_completed_bounds
    (Ψ : Eis →* ℂ) (hΨ : ∀ x, ‖Ψ x‖ ≤ 1) (W : ℝ → ℂ)
    (hW : HasCompactSupport W) (L R a s K0 K1 : ℝ)
    (hL : 0 < L) (hR : 0 < R) (hs : 1/2 ≤ s) (hK0 : 0 ≤ K0) (hK1 : 0 ≤ K1)
    (hraw : ‖rawProjection Ψ W L‖ ≤ K0 * L)
    (htriv : ∀ y : ℝ, 0 < y → ‖completedT Ψ W y‖ ≤ K0 * Real.sqrt y)
    (href : ∀ y : ℝ, 0 < y →
      ‖completedT Ψ W y‖ ≤ K1 * R^(a*(2*s+1)) * y^(-s)) :
    ‖rawProjection Ψ W L‖ ≤ (513*K0 + 128*K1) * Real.sqrt L * R^a := by
  by_cases hlarge : R^(2*a) ≤ L
  · let U := balancedCutoff L R a
    have hU : 1 ≤ U := balancedCutoff_ge_one L R a hL hR hlarge
    let A := K1 * R^(a*(2*s+1)) * L^(-s)
    let B := K0 * Real.sqrt L
    have hA : 0 ≤ A := by dsimp only [A]; positivity
    have hB : 0 ≤ B := by dsimp only [B]; positivity
    let g : NonzeroIdeal → ℝ := fun H => A*shortTerm s U H + B*tailTerm U H
    have hg : Summable g :=
      ((short_summable s U hs hU).mul_left A).add ((tail_summable U hU).mul_left B)
    have hbound : ∀ H, ‖inverseTerm Ψ W L H‖ ≤ g H := by
      intro H
      by_cases hHU : idealNorm H ≤ U
      · have hh := inverseTerm_reflected_bound Ψ hΨ W L R a s K1 hL href H
        simpa only [g, shortTerm, tailTerm, hHU, not_lt.mpr hHU,
          ite_true, ite_false, mul_zero, add_zero, A, idealNorm] using hh
      · have hh := inverseTerm_trivial_bound Ψ hΨ W L K0 hL htriv H
        simpa only [g, shortTerm, tailTerm, hHU, lt_of_not_ge hHU,
          ite_false, ite_true, mul_zero, zero_add, B, idealNorm] using hh
    have hi : Summable (fun H => ‖inverseTerm Ψ W L H‖) :=
      hg.of_nonneg_of_le (fun _ => norm_nonneg _) hbound
    have hsum : ‖∑' H, inverseTerm Ψ W L H‖ ≤ (128*K1+512*K0)*R^a := by
      calc
        _ ≤ ∑' H, ‖inverseTerm Ψ W L H‖ := norm_tsum_le_tsum_norm hi
        _ ≤ ∑' H, g H := hi.tsum_le_tsum hbound hg
        _ = A*(∑' H, shortTerm s U H) + B*(∑' H, tailTerm U H) := by
          rw [Summable.tsum_add ((short_summable s U hs hU).mul_left A)
            ((tail_summable U hU).mul_left B)]
          simp only [tsum_mul_left]
        _ ≤ A*(128*U^(3*s)) + B*(512*U^(-(3/2):ℝ)) :=
          add_le_add (mul_le_mul_of_nonneg_left (short_tsum_le s U hs hU) hA)
            (mul_le_mul_of_nonneg_left (tail_tsum_le U hU) hB)
        _ = 128*K1*(R^(a*(2*s+1))*L^(-s)*U^(3*s)) +
            512*K0*(Real.sqrt L*U^(-(3/2):ℝ)) := by dsimp only [A, B]; ring
        _ = _ := by
          rw [balanced_short_power L R a s hL hR, balanced_tail_power L R a hL hR]
          ring
    have hnormalized : (Real.sqrt L)⁻¹ * ‖rawProjection Ψ W L‖ ≤
        (128*K1+512*K0)*R^a := by
      rw [← actual_cube_inverse Ψ W hW L hL, norm_mul, norm_inv,
        Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (Real.sqrt_nonneg L)] at hsum
      exact hsum
    have hraw' : ‖rawProjection Ψ W L‖ ≤ Real.sqrt L * ((128*K1+512*K0)*R^a) :=
      (inv_mul_le_iff₀ (Real.sqrt_pos.mpr hL)).mp hnormalized
    apply hraw'.trans
    calc
      _ = (128*K1+512*K0)*Real.sqrt L*R^a := by ring
      _ ≤ _ := mul_le_mul_of_nonneg_right
        (mul_le_mul_of_nonneg_right (by linarith) (Real.sqrt_nonneg _))
        (Real.rpow_nonneg hR.le _)
  · have hsmall := small_scale_sqrt L R a hL hR (le_of_not_ge hlarge)
    calc
      _ ≤ K0*L := hraw
      _ = K0*Real.sqrt L*Real.sqrt L := by rw [mul_assoc, Real.mul_self_sqrt hL.le]
      _ ≤ K0*Real.sqrt L*R^a :=
        mul_le_mul_of_nonneg_left hsmall (mul_nonneg hK0 (Real.sqrt_nonneg _))
      _ ≤ _ := mul_le_mul_of_nonneg_right
        (mul_le_mul_of_nonneg_right (by linarith) (Real.sqrt_nonneg _))
        (Real.rpow_nonneg hR.le _)

theorem rawProjection_uniform_period_bound
    (W : ℝ → ℂ) (v0 v1 : ℝ) (hv0 : 0 < v0)
    (hWs : Function.support W ⊆ Set.Icc v0 v1) (hW : ContDiff ℝ ∞ W)
    (s : ℝ) (hs : 1/2 < s) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (Ψ : Eis →* ℂ), (∀ x, ‖Ψ x‖ ≤ 1) →
      ∀ (Q : Ideal Eis), Q ≠ 0 → CanonicalCoefficientClass.FactorsModulo Q Ψ →
      ∀ (L : ℝ), 0 < L →
      ‖rawProjection Ψ W L‖ ≤ C * Real.sqrt L *
        (Ideal.absNorm Q:ℝ)^((2*s+1/2)/(2*s+1)) := by
  obtain ⟨K0, hK0, h0⟩ := QRHExperimental.UniformTrivial.uniform_trivial_bounds
    W v0 v1 hWs hW.continuous
  obtain ⟨K1, hK1, h1⟩ := QRHExperimental.IdealConductorBound.completedT_uniform_period_bound
    W v0 v1 hv0 hWs hW s hs
  refine ⟨513*K0+128*K1, by positivity, ?_⟩
  intro Ψ hΨ Q hQ hperiod L hL
  have hden : 2*s+1 ≠ 0 := by linarith
  have he : ((2*s+1/2)/(2*s+1))*(2*s+1) = 2*s+1/2 := div_mul_cancel₀ _ hden
  apply rawProjection_bound_of_completed_bounds Ψ hΨ W
    (HasCompactSupport.of_support_subset_isCompact isCompact_Icc hWs)
    L (Ideal.absNorm Q:ℝ) ((2*s+1/2)/(2*s+1)) s K0 K1 hL
    (nonzeroIdeal_norm_pos ⟨Q,hQ⟩) hs.le hK0 hK1 (h0 Ψ hΨ L hL).1
    (fun y hy => (h0 Ψ hΨ y hy).2)
  simpa only [he] using h1 Ψ hΨ Q hQ hperiod

theorem rawProjection_three_quarters_epsilon
    (W : ℝ → ℂ) (v0 v1 : ℝ) (hv0 : 0 < v0)
    (hWs : Function.support W ⊆ Set.Icc v0 v1) (hW : ContDiff ℝ ∞ W)
    (ε : ℝ) (hε : 0 < ε) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (Ψ : Eis →* ℂ), (∀ x, ‖Ψ x‖ ≤ 1) →
      ∀ (Q : Ideal Eis), Q ≠ 0 → CanonicalCoefficientClass.FactorsModulo Q Ψ →
      ∀ (L : ℝ), 0 < L →
      ‖rawProjection Ψ W L‖ ≤ C * Real.sqrt L * (Ideal.absNorm Q:ℝ)^(3/4+ε) := by
  let s : ℝ := 1/2+4*ε
  have hs : 1/2 < s := by dsimp only [s]; linarith
  obtain ⟨C, hC, hbound⟩ := rawProjection_uniform_period_bound W v0 v1 hv0 hWs hW s hs
  refine ⟨C, hC, ?_⟩
  intro Ψ hΨ Q hQ hperiod L hL
  have ha : (2*s+1/2)/(2*s+1) ≤ 3/4+ε := by
    apply (div_le_iff₀ (by linarith : 0 < 2*s+1)).mpr
    dsimp only [s]
    nlinarith [sq_nonneg ε]
  exact (hbound Ψ hΨ Q hQ hperiod L hL).trans
    (mul_le_mul_of_nonneg_left
      (Real.rpow_le_rpow_of_exponent_le (norm_at_least_one Q hQ) ha)
      (mul_nonneg hC (Real.sqrt_nonneg L)))

#print axioms rawProjection_bound_of_completed_bounds
#print axioms rawProjection_uniform_period_bound
#print axioms rawProjection_three_quarters_epsilon

end
end QRHExperimental.CubeInverseAssembly
