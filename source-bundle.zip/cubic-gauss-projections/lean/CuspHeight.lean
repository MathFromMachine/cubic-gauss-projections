import OAI.NumberTheory.DirichletL.Eisenstein.FixedConductor
import Mathlib.Tactic.LinearCombination

/-! A uniform denominator bound for the actual reflected cusp data.
This is an arithmetic input to conductor estimates, not a projection
estimate or a new zero-free theorem. -/
namespace QRHExperimental.CuspHeight
noncomputable section
open OAI OAI.ActualEisensteinCubic OAI.ConcreteTraceCRT
open OAI.CubicEisenstein OAI.CubicKubota OAI.EisensteinCuspModThree
open scoped MatrixGroups
local notation "Eis" => OAI.ActualEisensteinCubic.O

theorem matrix_denominator_dvd (M : SL(2,Eis)) (a c : Eis)
    (hc : c ≠ 0) (hy : M 1 0 ≠ 0)
    (hp : eisEmbedding (M 0 0) / eisEmbedding (M 1 0) =
      eisEmbedding a / eisEmbedding c) :
    M 1 0 ∣ c := by
  have hcross : M 0 0 * c = a * M 1 0 := by
    apply eisEmbedding_injective
    simpa only [map_mul] using
      (div_eq_div_iff (eisEmbedding_ne_zero hy) (eisEmbedding_ne_zero hc)).mp hp
  have hd : M 0 0 * M 1 1 - M 0 1 * M 1 0 = 1 := by
    simpa only [Matrix.det_fin_two] using M.property
  refine ⟨M 1 1 * a - M 0 1 * c, ?_⟩
  calc
    c = (M 0 0 * M 1 1 - M 0 1 * M 1 0) * c := by rw [hd, one_mul]
    _ = M 1 0 * (M 1 1 * a - M 0 1 * c) := by
      linear_combination M 1 1 * hcross

theorem sourceCusp_heightScale_le (d : SourceCuspDatum) (a c : Eis)
    (hc : c ≠ 0)
    (hp : d.point = eisEmbedding a / eisEmbedding c) :
    d.heightScale ≤ (Ideal.absNorm (Ideal.span {c}) : ℝ) := by
  let M : SL(2,Eis) := (d.gamma : SL(2,Eis)) * cuspRepresentative d.index
  have hmap : integralComplexMatrix M = d.matrix := by
    dsimp only [M, SourceCuspDatum.matrix]
    rw [map_mul]
  have hy : M 1 0 ≠ 0 := by
    intro hz
    apply d.lower_ne_zero
    change d.matrix 1 0 = 0
    rw [← hmap, integralComplexMatrix_apply, hz, map_zero]
  have hp' : eisEmbedding (M 0 0) / eisEmbedding (M 1 0) =
      eisEmbedding a / eisEmbedding c := by
    change d.matrix 0 0 / d.matrix 1 0 = _ at hp
    rw [← hmap, integralComplexMatrix_apply, integralComplexMatrix_apply] at hp
    exact hp
  have hdiv : M 1 0 ∣ c := matrix_denominator_dvd M a c hc hy hp'
  calc
    d.heightScale = ‖eisEmbedding (M 1 0)‖ ^ 2 := by
      rw [SourceCuspDatum.heightScale, ← hmap, integralComplexMatrix_apply]
    _ = (Ideal.absNorm (Ideal.span {M 1 0}) : ℝ) :=
      eisEmbedding_norm_sq_eq_absNorm_span _
    _ ≤ (Ideal.absNorm (Ideal.span {c}) : ℝ) :=
      divisor_principal_norm_le (M 1 0) c hc hdiv

theorem rationalSourceCusp_heightScale_le (a c : Eis) (hc : c ≠ 0) :
    (rationalSourceCusp a c hc).heightScale ≤
      (Ideal.absNorm (Ideal.span {c}) : ℝ) :=
  sourceCusp_heightScale_le _ a c hc (rationalSourceCusp_point a c hc)

theorem finiteTwistCusp_heightScale_le (c : Eis) (hc : c ≠ 0)
    (h : Eis ⧸ Ideal.span {c}) :
    (finiteTwistCusp c hc h).heightScale ≤
      (Ideal.absNorm (Ideal.span {c}) : ℝ) :=
  rationalSourceCusp_heightScale_le (-3 * Quotient.out h) c hc

#print axioms matrix_denominator_dvd
#print axioms sourceCusp_heightScale_le
#print axioms rationalSourceCusp_heightScale_le
#print axioms finiteTwistCusp_heightScale_le
end
end QRHExperimental.CuspHeight
