import DivisorRadialMass
import EndpointProjection

/-! Uniform kernel bounds on the actual squarefree/cube model index.
The coefficient majorant is explicit. No character- or cusp adapter is
silently asserted. Prescribed ideal-divisor restrictions have one constant.
-/
namespace QRHExperimental.ModelKernelMass
noncomputable section
open OAI OAI.ActualEisensteinCubic OAI.CubicEisenstein OAI.CompletedGauss
open QRHExperimental.SparseRadialSummability
open QRHExperimental.RadialCumulativeMass QRHExperimental.DivisorRadialMass
open QRHExperimental.IdealPowerSums QRHExperimental.WeightedKernelBound
open scoped BigOperators Classical ContDiff
set_option maxHeartbeats 1500000

def indexEquiv : ReorderedIndex ≃ ThetaFullIndex where
  toFun := reorder
  invFun t := ((t.1,t.2.1,t.2.2.2),t.2.2.1)
  left_inv _ := rfl
  right_inv _ := rfl

def modelRadius (t : ThetaFullIndex) : ℝ :=
  sourceCuspRadialLength (thetaFullFrequency t)

lemma modelRadius_pos (t : ThetaFullIndex) : 0 < modelRadius t :=
  sourceCuspRadialLength_pos _

lemma cutoffWeight_eq_weight (p : ReorderedIndex) (T : ℝ)
    (h : modelRadius (reorder p) ≤ T) :
    cutoffWeight T p = sparseWeight 0 (reorder p) := by
  have hy := eligible_norm_pos p.1.2.2.val p.1.2.2.property
  have hden : 0 < (3:ℝ)^p.1.2.1*(Ideal.absNorm p.1.2.2.val:ℝ)^3 := by positivity
  have hcut : idealNorm (squarefreeNonzero p.2) ≤
      T/((3:ℝ)^p.1.2.1*(Ideal.absNorm p.1.2.2.val:ℝ)^3) := by
    apply (le_div_iff₀ hden).mpr
    simpa only [modelRadius, full_radial_length, reorder, squarefreeNonzero,
      idealNorm, mul_assoc, mul_comm, mul_left_comm] using h
  simp only [cutoffWeight]
  rw [shortHalfTerm, if_pos hcut]
  simp only [sparseWeight, reorder, squarefreeNonzero, idealNorm]
  norm_num
  ring

def modelMassConstant : ℝ := 512 * ∑' o : OuterIndex, outerWeight o

lemma modelMassConstant_nonneg : 0 ≤ modelMassConstant :=
  mul_nonneg (by norm_num) (tsum_nonneg outerWeight_nonneg)

theorem model_sqrt_mass (b : ThetaFullIndex → ℂ)
    (hb : ∀ t, ‖b t‖ ≤ sparseWeight 0 t) :
    SqrtMassBound (fun t => ‖b t‖) modelRadius modelMassConstant := by
  intro S T hT hS
  let R := S.map indexEquiv.symm.toEmbedding
  have heq : (∑ t ∈ S, ‖b t‖) = ∑ p ∈ R, ‖b (reorder p)‖ := by
    simp only [R, Finset.sum_map, Equiv.toEmbedding_apply, indexEquiv, Equiv.symm_mk]
    rfl
  have hR : ∀ p ∈ R, modelRadius (reorder p) ≤ T := by
    intro p hp
    obtain ⟨t,ht,rfl⟩ := Finset.mem_map.mp hp
    exact hS t ht
  rw [heq]
  calc
    _ ≤ ∑ p ∈ R, cutoffWeight T p := Finset.sum_le_sum (fun p hp => by
      rw [cutoffWeight_eq_weight p T (hR p hp)]
      exact hb _)
    _ ≤ ∑' p : ReorderedIndex, cutoffWeight T p :=
      (cutoff_summable T hT).sum_le_tsum R (fun p _ => cutoffWeight_nonneg T p)
    _ ≤ (512*Real.sqrt T)*(∑' o : OuterIndex, outerWeight o) := cutoff_tsum_le T hT
    _ = _ := by rw [Real.sqrt_eq_rpow]; unfold modelMassConstant; ring

def divisorModelWeight (D E : NonzeroIdeal) (t : ThetaFullIndex) : ℝ :=
  if D.val ∣ t.2.2.1.val ∧ E.val ∣ t.2.2.2.val then sparseWeight 0 t else 0

def divisorMassConstant : ℝ := 512 * ∑' o : AllOuterIndex, allOuterWeight o

lemma divisorMassConstant_nonneg : 0 ≤ divisorMassConstant :=
  mul_nonneg (by norm_num) (tsum_nonneg allOuterWeight_nonneg)

theorem model_divisor_sqrt_mass (D E : NonzeroIdeal) (b : ThetaFullIndex → ℂ)
    (hb : ∀ t, ‖b t‖ ≤ divisorModelWeight D E t) :
    SqrtMassBound (fun t => ‖b t‖) modelRadius
      (divisorMassConstant * (idealNorm D)^(-1:ℝ) * (idealNorm E)^(-(5/2):ℝ)) := by
  intro S T hT hS
  let R := S.map indexEquiv.symm.toEmbedding
  have heq : (∑ t ∈ S, ‖b t‖) = ∑ p ∈ R, ‖b (reorder p)‖ := by
    simp only [R, Finset.sum_map, Equiv.toEmbedding_apply, indexEquiv, Equiv.symm_mk]
    rfl
  have hR : ∀ p ∈ R, modelRadius (reorder p) ≤ T := by
    intro p hp
    obtain ⟨t,ht,rfl⟩ := Finset.mem_map.mp hp
    exact hS t ht
  rw [heq]
  calc
    _ ≤ ∑ p ∈ R, cutoffDivisor D E T p := by
      apply Finset.sum_le_sum
      intro p hp
      have hx := hb (reorder p)
      rw [cutoffDivisor, cutoffWeight_eq_weight p T (hR p hp)]
      exact hx
    _ ≤ ∑' p : ReorderedIndex, cutoffDivisor D E T p :=
      (cutoffDivisor_summable D E T hT).sum_le_tsum R
        (fun p _ => cutoffDivisor_nonneg D E T p)
    _ ≤ divisorMassConstant * (idealNorm D)^(-1:ℝ) *
        (idealNorm E)^(-(5/2):ℝ) * Real.sqrt T := cutoffDivisor_tsum_le D E T hT
    _ = _ := by rw [Real.sqrt_eq_rpow]

theorem model_paperKernel_bound
    (W : ℝ → ℂ) (lo hi : ℝ) (hlo : 0 < lo)
    (hsupp : Function.support W ⊆ Set.Icc lo hi) (hW : ContDiff ℝ ∞ W) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (b : ThetaFullIndex → ℂ),
      (∀ t, ‖b t‖ ≤ sparseWeight 0 t) → ∀ v : ℝ, 0 < v →
      Summable (fun t => ‖b t * CubicReflectionKernel.paperKernel (Vstar W) (v*modelRadius t)‖) ∧
      ‖∑' t, b t * CubicReflectionKernel.paperKernel (Vstar W) (v*modelRadius t)‖ ≤
        C*v^(-(1/2):ℝ) := by
  obtain ⟨D,hD,hsmall,hlarge⟩ :=
    QRHExperimental.EndpointProjection.paperKernel_two_sided_bound W lo hi hlo hsupp hW
  refine ⟨5*modelMassConstant*D, by positivity [modelMassConstant_nonneg], ?_⟩
  intro b hb v hv
  exact kernel_summable_and_bound b modelRadius modelMassConstant D
    modelMassConstant_nonneg hD modelRadius_pos (model_sqrt_mass b hb)
    _ hsmall hlarge v hv

theorem model_divisor_paperKernel_bound
    (W : ℝ → ℂ) (lo hi : ℝ) (hlo : 0 < lo)
    (hsupp : Function.support W ⊆ Set.Icc lo hi) (hW : ContDiff ℝ ∞ W) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (D E : NonzeroIdeal) (b : ThetaFullIndex → ℂ),
      (∀ t, ‖b t‖ ≤ divisorModelWeight D E t) → ∀ v : ℝ, 0 < v →
      Summable (fun t => ‖b t * CubicReflectionKernel.paperKernel (Vstar W) (v*modelRadius t)‖) ∧
      ‖∑' t, b t * CubicReflectionKernel.paperKernel (Vstar W) (v*modelRadius t)‖ ≤
        C * (idealNorm D)^(-1:ℝ) * (idealNorm E)^(-(5/2):ℝ) * v^(-(1/2):ℝ) := by
  obtain ⟨A,hA,hsmall,hlarge⟩ :=
    QRHExperimental.EndpointProjection.paperKernel_two_sided_bound W lo hi hlo hsupp hW
  refine ⟨5*divisorMassConstant*A, by positivity [divisorMassConstant_nonneg], ?_⟩
  intro D E b hb v hv
  have hc : 0 ≤ divisorMassConstant*(idealNorm D)^(-1:ℝ)*(idealNorm E)^(-(5/2):ℝ) := by
    positivity [divisorMassConstant_nonneg]
  have h := kernel_summable_and_bound b modelRadius _ A hc hA modelRadius_pos
    (model_divisor_sqrt_mass D E b hb) _ hsmall hlarge v hv
  refine ⟨h.1, h.2.trans_eq ?_⟩
  ring

#print axioms model_sqrt_mass
#print axioms model_divisor_sqrt_mass
#print axioms model_paperKernel_bound
#print axioms model_divisor_paperKernel_bound
end
end QRHExperimental.ModelKernelMass
