import TrivialProjection

/-! Actual Eisenstein ideal power sums from the linear ideal count.
The proofs use finite dyadic decompositions and then pass to nonnegative tsums. -/
namespace QRHExperimental.IdealPowerSums
noncomputable section
open OAI OAI.ActualEisensteinCubic OAI.CompletedGauss OAI.CubicEisenstein
open QRHExperimental.TrivialProjection
open scoped BigOperators Classical
set_option maxHeartbeats 1200000
local notation "Eis" => OAI.ActualEisensteinCubic.O

abbrev idealNorm (I : NonzeroIdeal) : ℝ := (Ideal.absNorm I.val : ℝ)

lemma finite_count (S : Finset NonzeroIdeal) (U : ℝ) (hU : 1 ≤ U)
    (hS : ∀ I ∈ S, idealNorm I ≤ U) : (S.card : ℝ) ≤ 128*U := by
  have h := DescentFiberCost.finite_ideal_count_real (S.image Subtype.val) U hU
    (by intro J hJ; obtain ⟨I,hI,rfl⟩ := Finset.mem_image.mp hJ; exact I.property)
    (by intro J hJ; obtain ⟨I,hI,rfl⟩ := Finset.mem_image.mp hJ; exact hS I hI)
  simpa only [Finset.card_image_of_injective S Subtype.val_injective] using h

lemma finite_positive_power (S : Finset NonzeroIdeal) (U e : ℝ)
    (hU : 1 ≤ U) (he : 0 ≤ e) (hS : ∀ I ∈ S, idealNorm I ≤ U) :
    (∑ I ∈ S, (idealNorm I)^e) ≤ 128*U^(e+1) := by
  have hU0 : 0 < U := zero_lt_one.trans_le hU
  calc
    _ ≤ ∑ _I ∈ S, U^e := Finset.sum_le_sum (fun I hI =>
      Real.rpow_le_rpow (nonzeroIdeal_norm_pos I).le (hS I hI) he)
    _ = (S.card : ℝ)*U^e := by simp
    _ ≤ (128*U)*U^e := mul_le_mul_of_nonneg_right (finite_count S U hU hS)
      (Real.rpow_nonneg hU0.le _)
    _ = 128*U^(e+1) := by rw [Real.rpow_add_one hU0.ne']; ring

def shortTerm (s U : ℝ) (I : NonzeroIdeal) : ℝ :=
  if idealNorm I ≤ U then (idealNorm I)^(3*s-1) else 0

lemma finite_short_le (s U : ℝ) (hs : 1/2 ≤ s) (hU : 1 ≤ U)
    (S : Finset NonzeroIdeal) : ∑ I ∈ S, shortTerm s U I ≤ 128*U^(3*s) := by
  have h := finite_positive_power (S.filter (fun I => idealNorm I ≤ U)) U (3*s-1)
    hU (by linarith) (fun I hI => (Finset.mem_filter.mp hI).2)
  have he : 3*s-1+1=3*s := by ring
  simpa only [he, Finset.sum_filter, shortTerm] using h

theorem short_summable (s U : ℝ) (hs : 1/2 ≤ s) (hU : 1 ≤ U) :
    Summable (shortTerm s U) := by
  apply summable_of_sum_le (c := 128*U^(3*s))
  · intro I; simp only [shortTerm]; split <;> positivity
  · exact finite_short_le s U hs hU

theorem short_tsum_le (s U : ℝ) (hs : 1/2 ≤ s) (hU : 1 ≤ U) :
    (∑' I : NonzeroIdeal, shortTerm s U I) ≤ 128*U^(3*s) := by
  apply Real.tsum_le_of_sum_le
  · intro I; simp only [shortTerm]; split <;> positivity
  · exact finite_short_le s U hs hU

lemma tail_band (S : Finset NonzeroIdeal) (U : ℝ) (hU : 1 ≤ U)
    (hlo : ∀ I ∈ S, U < idealNorm I) (hhi : ∀ I ∈ S, idealNorm I ≤ 2*U) :
    (∑ I ∈ S, (idealNorm I)^(-(5/2):ℝ)) ≤ 256*U^(-(3/2):ℝ) := by
  have hU0 : 0 < U := zero_lt_one.trans_le hU
  calc
    _ ≤ ∑ _I ∈ S, U^(-(5/2):ℝ) := Finset.sum_le_sum (fun I hI =>
      Real.rpow_le_rpow_of_nonpos hU0 (hlo I hI).le (by norm_num))
    _ = (S.card : ℝ)*U^(-(5/2):ℝ) := by simp
    _ ≤ (128*(2*U))*U^(-(5/2):ℝ) := mul_le_mul_of_nonneg_right
      (finite_count S (2*U) (by linarith) hhi) (Real.rpow_nonneg hU0.le _)
    _ = 256*U^(-(3/2):ℝ) := by
      rw [show -(3/2:ℝ)=-(5/2:ℝ)+1 by norm_num, Real.rpow_add_one hU0.ne']
      ring

lemma tail_scale (U : ℝ) (hU : 0 < U) :
    512*(2*U)^(-(3/2):ℝ) ≤ 256*U^(-(3/2):ℝ) := by
  have h2 : (2:ℝ)^(-(3/2):ℝ) ≤ 1/2 := by
    calc
      _ ≤ (2:ℝ)^(-1:ℝ) := Real.rpow_le_rpow_of_exponent_le (by norm_num) (by norm_num)
      _ = _ := by rw [Real.rpow_neg_one]; norm_num
  rw [Real.mul_rpow (by norm_num : (0:ℝ)≤2) hU.le]
  nlinarith [Real.rpow_nonneg hU.le (-(3/2):ℝ)]

private lemma finite_tail_aux (k : ℕ) :
    ∀ (U : ℝ), 1 ≤ U → ∀ S : Finset NonzeroIdeal,
      (∀ I ∈ S, U < idealNorm I) →
      (∀ I ∈ S, idealNorm I ≤ (2:ℝ)^k*U) →
      (∑ I ∈ S, (idealNorm I)^(-(5/2):ℝ)) ≤ 512*U^(-(3/2):ℝ) := by
  induction k with
  | zero =>
    intro U hU S hlo hhi
    have hS : S=∅ := Finset.eq_empty_iff_forall_notMem.mpr (by
      intro I hI
      have hh := hhi I hI
      simp only [pow_zero,one_mul] at hh
      exact (not_lt_of_ge hh) (hlo I hI))
    rw [hS,Finset.sum_empty]
    positivity
  | succ k ih =>
    intro U hU S hlo hhi
    have hb := tail_band (S.filter (fun I => idealNorm I ≤ 2*U)) U hU
      (fun I hI => hlo I (Finset.mem_filter.mp hI).1)
      (fun I hI => (Finset.mem_filter.mp hI).2)
    have ht := ih (2*U) (by linarith) (S.filter (fun I => ¬idealNorm I ≤ 2*U))
      (fun I hI => lt_of_not_ge (Finset.mem_filter.mp hI).2)
      (by
        intro I hI
        have h := hhi I (Finset.mem_filter.mp hI).1
        simpa only [pow_succ,mul_assoc,mul_comm,mul_left_comm] using h)
    rw [← Finset.sum_filter_add_sum_filter_not S (fun I => idealNorm I ≤ 2*U)]
    have hscale := tail_scale U (zero_lt_one.trans_le hU)
    linarith

lemma finite_tail_le (S : Finset NonzeroIdeal) (U : ℝ) (hU : 1 ≤ U)
    (hlo : ∀ I ∈ S, U < idealNorm I) :
    (∑ I ∈ S, (idealNorm I)^(-(5/2):ℝ)) ≤ 512*U^(-(3/2):ℝ) := by
  let k := S.sup (fun I => Ideal.absNorm I.val)
  apply finite_tail_aux k U hU S hlo
  intro I hI
  have h1 : Ideal.absNorm I.val ≤ k :=
    Finset.le_sup (f := fun J : NonzeroIdeal => Ideal.absNorm J.val) hI
  have h2 : (k:ℝ) ≤ (2:ℝ)^k := by exact_mod_cast (Nat.le_of_lt k.lt_two_pow_self)
  have h3 : (2:ℝ)^k ≤ (2:ℝ)^k*U := le_mul_of_one_le_right (by positivity) hU
  exact (by exact_mod_cast h1 : idealNorm I ≤ (k:ℝ)).trans (h2.trans h3)

def tailTerm (U : ℝ) (I : NonzeroIdeal) : ℝ :=
  if U < idealNorm I then (idealNorm I)^(-(5/2):ℝ) else 0

lemma finite_tailTerm_le (U : ℝ) (hU : 1 ≤ U) (S : Finset NonzeroIdeal) :
    ∑ I ∈ S, tailTerm U I ≤ 512*U^(-(3/2):ℝ) := by
  have h := finite_tail_le (S.filter (fun I => U < idealNorm I)) U hU
    (fun I hI => (Finset.mem_filter.mp hI).2)
  simpa only [Finset.sum_filter, tailTerm] using h

theorem tail_summable (U : ℝ) (hU : 1 ≤ U) : Summable (tailTerm U) := by
  apply summable_of_sum_le (c := 512*U^(-(3/2):ℝ))
  · intro I; simp only [tailTerm]; split <;> positivity
  · exact finite_tailTerm_le U hU

theorem tail_tsum_le (U : ℝ) (hU : 1 ≤ U) :
    (∑' I : NonzeroIdeal, tailTerm U I) ≤ 512*U^(-(3/2):ℝ) := by
  apply Real.tsum_le_of_sum_le
  · intro I; simp only [tailTerm]; split <;> positivity
  · exact finite_tailTerm_le U hU

lemma short_half_band (S : Finset NonzeroIdeal) (U : ℝ) (hU : 1 ≤ U)
    (hlo : ∀ I ∈ S, U/4 < idealNorm I) (hhi : ∀ I ∈ S, idealNorm I ≤ U) :
    (∑ I ∈ S, (idealNorm I)^(-(1/2):ℝ)) ≤ 256*U^(1/2:ℝ) := by
  have hU0 : 0 < U := zero_lt_one.trans_le hU
  have h4 : (4:ℝ)^(-(1/2):ℝ)=1/2 := by
    rw [Real.rpow_neg (by norm_num : (0:ℝ)≤4)]
    norm_num [← Real.sqrt_eq_rpow]
  calc
    _ ≤ ∑ _I ∈ S, (U/4)^(-(1/2):ℝ) := Finset.sum_le_sum (fun I hI =>
      Real.rpow_le_rpow_of_nonpos (by positivity) (hlo I hI).le (by norm_num))
    _ = (S.card : ℝ)*(U/4)^(-(1/2):ℝ) := by simp
    _ ≤ (128*U)*(U/4)^(-(1/2):ℝ) := mul_le_mul_of_nonneg_right
      (finite_count S U hU hhi) (Real.rpow_nonneg (by positivity) _)
    _ = 256*U^(1/2:ℝ) := by
      rw [Real.div_rpow hU0.le (by norm_num : (0:ℝ)≤4),h4,
        show (1/2:ℝ)=-(1/2:ℝ)+1 by norm_num, Real.rpow_add_one hU0.ne']
      ring

lemma short_half_scale (U : ℝ) (hU : 0 ≤ U) :
    512*(U/4)^(1/2:ℝ)=256*U^(1/2:ℝ) := by
  rw [Real.div_rpow hU (by norm_num : (0:ℝ)≤4)]
  have h4 : (4:ℝ)^(1/2:ℝ)=2 := by norm_num [←Real.sqrt_eq_rpow]
  rw [h4]
  ring

private lemma finite_short_half_aux (k : ℕ) :
    ∀ (U : ℝ), 0 < U → U ≤ (4:ℝ)^k → ∀ S : Finset NonzeroIdeal,
      (∀ I ∈ S, idealNorm I ≤ U) →
      (∑ I ∈ S, (idealNorm I)^(-(1/2):ℝ)) ≤ 512*U^(1/2:ℝ) := by
  induction k with
  | zero =>
    intro U hU hcap S hhi
    simp only [pow_zero] at hcap
    by_cases hU1 : 1 ≤ U
    · have he : U=1 := le_antisymm hcap hU1
      subst U
      have hc := finite_count S 1 le_rfl hhi
      have hw : (∑ I ∈ S, (idealNorm I)^(-(1/2):ℝ)) ≤ (S.card:ℝ) := by
        calc
          _ ≤ ∑ _I ∈ S, (1:ℝ) := Finset.sum_le_sum (fun I _ => by
            simpa using Real.rpow_le_rpow_of_nonpos (by norm_num : (0:ℝ)<1)
              (norm_at_least_one I.val I.property) (by norm_num : -(1/2:ℝ)≤0))
          _ = _ := by simp
      norm_num only [mul_one,Real.one_rpow] at hc ⊢
      linarith
    · have hS : S=∅ := Finset.eq_empty_iff_forall_notMem.mpr (by
        intro I hI
        exact hU1 ((norm_at_least_one I.val I.property).trans (hhi I hI)))
      rw [hS,Finset.sum_empty]
      positivity
  | succ k ih =>
    intro U hU hcap S hhi
    by_cases hU1 : 1 ≤ U
    · have hlo := ih (U/4) (by positivity) (by
        rw [pow_succ] at hcap
        nlinarith) (S.filter (fun I => idealNorm I ≤ U/4))
        (fun I hI => (Finset.mem_filter.mp hI).2)
      have hhigh := short_half_band (S.filter (fun I => ¬idealNorm I ≤ U/4)) U hU1
        (fun I hI => lt_of_not_ge (Finset.mem_filter.mp hI).2)
        (fun I hI => hhi I (Finset.mem_filter.mp hI).1)
      rw [short_half_scale U hU.le] at hlo
      rw [← Finset.sum_filter_add_sum_filter_not S (fun I => idealNorm I ≤ U/4)]
      linarith
    · have hS : S=∅ := Finset.eq_empty_iff_forall_notMem.mpr (by
        intro I hI
        exact hU1 ((norm_at_least_one I.val I.property).trans (hhi I hI)))
      rw [hS,Finset.sum_empty]
      positivity

lemma finite_short_half_le (S : Finset NonzeroIdeal) (U : ℝ) (hU : 1 ≤ U)
    (hhi : ∀ I ∈ S, idealNorm I ≤ U) :
    (∑ I ∈ S, (idealNorm I)^(-(1/2):ℝ)) ≤ 512*U^(1/2:ℝ) := by
  obtain ⟨k,_,hk⟩ := exists_nat_pow_near hU (by norm_num : (1:ℝ)<4)
  exact finite_short_half_aux (k+1) U (zero_lt_one.trans_le hU) hk.le S hhi

theorem finite_short_half_le_pos (S : Finset NonzeroIdeal) (U : ℝ) (hU : 0 < U)
    (hhi : ∀ I ∈ S, idealNorm I ≤ U) :
    (∑ I ∈ S, (idealNorm I)^(-(1/2):ℝ)) ≤ 512*U^(1/2:ℝ) := by
  by_cases hU1 : 1 ≤ U
  · exact finite_short_half_le S U hU1 hhi
  · have hS : S=∅ := Finset.eq_empty_iff_forall_notMem.mpr (by
      intro I hI
      exact hU1 ((norm_at_least_one I.val I.property).trans (hhi I hI)))
    rw [hS,Finset.sum_empty]
    positivity

def shortHalfTerm (U : ℝ) (I : NonzeroIdeal) : ℝ :=
  if idealNorm I ≤ U then (idealNorm I)^(-(1/2):ℝ) else 0

lemma finite_shortHalfTerm_le (U : ℝ) (hU : 1 ≤ U) (S : Finset NonzeroIdeal) :
    ∑ I ∈ S, shortHalfTerm U I ≤ 512*U^(1/2:ℝ) := by
  have h := finite_short_half_le (S.filter (fun I => idealNorm I ≤ U)) U hU
    (fun I hI => (Finset.mem_filter.mp hI).2)
  simpa only [Finset.sum_filter, shortHalfTerm] using h

theorem short_half_summable (U : ℝ) (hU : 1 ≤ U) : Summable (shortHalfTerm U) := by
  apply summable_of_sum_le (c := 512*U^(1/2:ℝ))
  · intro I; simp only [shortHalfTerm]; split <;> positivity
  · exact finite_shortHalfTerm_le U hU

theorem short_half_tsum_le (U : ℝ) (hU : 1 ≤ U) :
    (∑' I : NonzeroIdeal, shortHalfTerm U I) ≤ 512*U^(1/2:ℝ) := by
  apply Real.tsum_le_of_sum_le
  · intro I; simp only [shortHalfTerm]; split <;> positivity
  · exact finite_shortHalfTerm_le U hU

#print axioms short_summable
#print axioms short_tsum_le
#print axioms tail_summable
#print axioms tail_tsum_le
#print axioms short_half_summable
#print axioms short_half_tsum_le
#print axioms finite_short_half_le_pos
end
end QRHExperimental.IdealPowerSums
