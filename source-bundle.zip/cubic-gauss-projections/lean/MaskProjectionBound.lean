import MaskExtraction

/-! Analytic consequence of one global mask extraction. The projection
constant is used once, uniformly across divisors, not once per prime. -/
namespace QRHExperimental.MaskProjectionBound
noncomputable section
open OAI OAI.ActualEisensteinCubic OAI.CompletedGauss OAI.CubicEisenstein
open OAI.ConcreteTraceCRT OAI.SevenEighths IdealMobiusDivisorSum
open QRHExperimental.TrivialProjection QRHExperimental.MaskExtraction
open scoped BigOperators Classical
local notation "Eis" => OAI.ActualEisensteinCubic.O

lemma extracted_coefficient_norm_le_one
    (Ψ : Eis →* ℂ) (hΨ : ∀ x, ‖Ψ x‖ ≤ 1) (D : Ideal Eis) :
    ‖(UniqueFactorizationMonoid.moebius D:ℂ)*columnWeight Ψ D‖ ≤ 1 := by
  rw [norm_mul]
  exact (mul_le_mul (CubicEisenstein.norm_ideal_moebius_le_one D)
    (columnWeight_norm_le_one Ψ hΨ D) (norm_nonneg _) (by norm_num)).trans_eq (by ring)

theorem masked_projection_norm_le
    (Ψ : Eis →* ℂ) (hΨ : ∀ x, ‖Ψ x‖ ≤ 1)
    (M : Ideal Eis) (hM : CubicSieve.Admissible M)
    (W : ℝ → ℂ) (b L : ℝ) (hL : 0 < L)
    (hW : ∀ x, W x ≠ 0 → x ≤ b) :
    ‖rawProjection (Ψ*coprimeMask M hM) W L‖ ≤
      ∑ D : idealDivisors M,
        ‖rawProjection (Ψ*fourthTwist D.val (divisor_admissible M hM D)) W
          (L/(Ideal.absNorm D.val:ℝ))‖ := by
  rw [masked_projection_mobius Ψ M hM W b L hL hW]
  apply (norm_sum_le _ _).trans
  apply Finset.sum_le_sum
  intro D hD
  rw [norm_mul]
  exact (mul_le_mul_of_nonneg_right (extracted_coefficient_norm_le_one Ψ hΨ D.val)
    (norm_nonneg _)).trans_eq (one_mul _)

/-- An explicit common-C bound. The input family of shifted projections
may be supplied by the actual mixed-prime theorem after source reindexing. -/
theorem masked_projection_common_bound
    (Ψ : Eis →* ℂ) (hΨ : ∀ x, ‖Ψ x‖ ≤ 1)
    (M : Ideal Eis) (hM : CubicSieve.Admissible M)
    (W : ℝ → ℂ) (b L K : ℝ) (hL : 0 < L)
    (hW : ∀ x, W x ≠ 0 → x ≤ b)
    (a : idealDivisors M → ℝ)
    (hbound : ∀ D : idealDivisors M,
      ‖rawProjection (Ψ*fourthTwist D.val (divisor_admissible M hM D)) W
          (L/(Ideal.absNorm D.val:ℝ))‖ ≤
        K*Real.sqrt (L/(Ideal.absNorm D.val:ℝ))*a D) :
    ‖rawProjection (Ψ*coprimeMask M hM) W L‖ ≤
      K*Real.sqrt L*∑ D : idealDivisors M, a D/Real.sqrt (Ideal.absNorm D.val:ℝ) := by
  apply (masked_projection_norm_le Ψ hΨ M hM W b L hL hW).trans
  calc
    _ ≤ ∑ D : idealDivisors M, K*Real.sqrt (L/(Ideal.absNorm D.val:ℝ))*a D :=
      Finset.sum_le_sum (fun D _ => hbound D)
    _ = _ := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro D hD
      rw [Real.sqrt_div hL.le]
      ring

#print axioms masked_projection_norm_le
#print axioms masked_projection_common_bound
end
end QRHExperimental.MaskProjectionBound
