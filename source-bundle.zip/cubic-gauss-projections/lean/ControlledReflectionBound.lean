import ModelKernelMass
import ControlledBracketNorms
import OAI.NumberTheory.DirichletL.Eisenstein.FixedFrequencyExpansion

/-! Actual controlled-stratum reflection with a bounded COMPLETE bracket.
This theorem keeps the source amplitude, static multiplier, and kernel.
The bounded-bracket hypothesis is explicit; it is discharged separately
for nonexceptional sextic exponents, not for arbitrary fourth branches. -/
namespace QRHExperimental.ControlledReflectionBound
noncomputable section
open OAI OAI.ActualEisensteinCubic OAI.ConcreteTraceCRT
open OAI.CubicEisenstein OAI.CompletedGauss OAI.CompletedDyadic
open OAI.CubicEisenstein.ControlledStratumArithmetic
open QRHExperimental.SparseRadialSummability QRHExperimental.ModelKernelMass
open scoped BigOperators Classical ContDiff
set_option maxHeartbeats 2000000
local notation "Eis" => OAI.ActualEisensteinCubic.O

lemma inverse_denominator (t : ThetaFullIndex) :
    1 / (ramifiedScale 1 completedRamifiedStep t.2.1*
      Real.sqrt (Ideal.absNorm t.2.2.1.val:ℝ)*(Ideal.absNorm t.2.2.2.val:ℝ)) =
        sparseWeight 0 t := by
  have hI := eligible_norm_pos t.2.2.1.val t.2.2.1.property.2
  have hJ := eligible_norm_pos t.2.2.2.val t.2.2.2.property
  rw [thetaRamifiedScale_eq, Real.sqrt_eq_rpow]
  simp only [one_div, mul_inv_rev]
  rw [← Real.rpow_neg (by norm_num : 0 ≤ (3:ℝ)), ← Real.rpow_neg hI.le,
    ← Real.rpow_neg_one]
  unfold sparseWeight
  norm_num only [zero_add, mul_zero, zero_mul, neg_zero]
  rw [show -((t.2.1:ℝ)/3)=-(1/3:ℝ)*(t.2.1:ℝ) by ring]
  ring

variable {ι : Type*} [Fintype ι] {p : ι → Eis} {N a0 c0 : Eis} {mode : Bool}

noncomputable def reflectedCoefficient
    (D : ControlledStratumArithmetic p N a0 c0 mode)
    [∀ i, (Ideal.span {p i}).IsMaximal]
    (s : FixedCuspShape (fixedCusp a0 c0 mode))
    (hp : ∀ i, p i ≠ 0) (hc0 : c0 ≠ 0) (hg : ∀ i, lambda ∉ Ideal.span {p i})
    (j : ι → ℕ) (t : ThetaFullIndex) : ℂ :=
  (s.amplitude t.1 t.2.1 t.2.2.1.val t.2.2.2.val /
    ((ramifiedScale 1 completedRamifiedStep t.2.1*
      Real.sqrt (Ideal.absNorm t.2.2.1.val:ℝ)*(Ideal.absNorm t.2.2.2.val:ℝ):ℝ):ℂ))*
    ((star D.fixedFactor*ShortDraftCusp.A4BadPhase c0 hc0 (D.matrix (fun _=>1) 1 1) D.U
      (sourceCuspPhaseNumerator s.index (s.upper 0 0) (thetaFullFrequency t)))*
      D.bracketProduct hp hg j
        (sourceCuspPhaseNumerator s.index (s.upper 0 0) (thetaFullFrequency t)))

lemma reflectedCoefficient_norm_le
    (D : ControlledStratumArithmetic p N a0 c0 mode)
    [∀ i, (Ideal.span {p i}).IsMaximal]
    (s : FixedCuspShape (fixedCusp a0 c0 mode))
    (hp : ∀ i, p i ≠ 0) (hc0 : c0 ≠ 0) (hg : ∀ i, lambda ∉ Ideal.span {p i})
    (j : ι → ℕ)
    (hM : ∀ x : Eis, ‖(star D.fixedFactor*
      ShortDraftCusp.A4BadPhase c0 hc0 (D.matrix (fun _=>1) 1 1) D.U x)*
        D.bracketProduct hp hg j x‖ ≤ 1) (t : ThetaFullIndex) :
    ‖reflectedCoefficient D s hp hc0 hg j t‖ ≤ sparseWeight 0 t := by
  have hd := thetaFullIndex_denominator_pos t
  rw [reflectedCoefficient, norm_mul, norm_div, Complex.norm_real,
    Real.norm_of_nonneg hd.le]
  calc
    _ ≤ (1/(ramifiedScale 1 completedRamifiedStep t.2.1*
        Real.sqrt (Ideal.absNorm t.2.2.1.val:ℝ)*(Ideal.absNorm t.2.2.2.val:ℝ)))*1 :=
      mul_le_mul (div_le_div_of_nonneg_right
        (s.amplitude_norm t.1 t.2.1 t.2.2.1.val t.2.2.2.val) hd.le)
        (hM _) (norm_nonneg _) (by positivity)
    _ = _ := by rw [mul_one,inverse_denominator]

lemma reflectedValue_eq_kernel
    (D : ControlledStratumArithmetic p N a0 c0 mode)
    [∀ i, (Ideal.span {p i}).IsMaximal]
    (s : FixedCuspShape (fixedCusp a0 c0 mode))
    (hp : ∀ i, p i ≠ 0) (hc0 : c0 ≠ 0) (hg : ∀ i, lambda ∉ Ideal.span {p i})
    (j : ι → ℕ) (W : ℝ → ℂ) (X : ℝ) :
    D.reflectedValue s hp hc0 hg j W X =
      fixedRadialCoefficientScalar*s.stratumShapeFactor (c0*∏i,p i)*
        ∑' t : ThetaFullIndex, reflectedCoefficient D s hp hc0 hg j t*
          CubicReflectionKernel.paperKernel (Vstar W)
            ((X/(27*(sourceCuspScale s.index)^2*
              (Ideal.absNorm (Ideal.span {c0*∏i,p i}):ℝ)^2))*
                sourceCuspRadialLength (thetaFullFrequency t)) := by
  unfold ControlledStratumArithmetic.reflectedValue
  congr 1
  apply tsum_congr
  intro t
  rw [sourceCuspRadialLength_full_index,thetaRamifiedScale_cube]
  unfold reflectedCoefficient
  rw [show (X/(27*(sourceCuspScale s.index)^2*
      (Ideal.absNorm (Ideal.span {c0*∏i,p i}):ℝ)^2))*(3:ℝ)^t.2.1*
        (Ideal.absNorm t.2.2.1.val:ℝ)*(Ideal.absNorm t.2.2.2.val:ℝ)^3 =
      (X/(27*(sourceCuspScale s.index)^2*
        (Ideal.absNorm (Ideal.span {c0*∏i,p i}):ℝ)^2))*
          ((3:ℝ)^t.2.1*(Ideal.absNorm t.2.2.1.val:ℝ)*
            (Ideal.absNorm t.2.2.2.val:ℝ)^3) by ring]
  ring

/-- The common majorant constant is chosen before the finite prime family,
its controlled arithmetic data, cusp shape, and scale. -/
theorem reflectedValue_uniform_bound
    (W : ℝ → ℂ) (lo hi : ℝ) (hlo : 0 < lo)
    (hsupp : Function.support W ⊆ Set.Icc lo hi) (hW : ContDiff ℝ ∞ W) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀
      (ι : Type*) [Fintype ι] (p : ι → Eis) (N a0 c0 : Eis) (mode : Bool)
      (D : ControlledStratumArithmetic p N a0 c0 mode)
      [∀ i, (Ideal.span {p i}).IsMaximal]
      (s : FixedCuspShape (fixedCusp a0 c0 mode))
      (hp : ∀ i, p i ≠ 0) (hc0 : c0 ≠ 0) (hg : ∀ i, lambda ∉ Ideal.span {p i})
      (j : ι → ℕ),
      (∀ x : Eis, ‖(star D.fixedFactor*
        ShortDraftCusp.A4BadPhase c0 hc0 (D.matrix (fun _=>1) 1 1) D.U x)*
          D.bracketProduct hp hg j x‖ ≤ 1) →
      ∀ X : ℝ, 0 < X →
      ‖D.reflectedValue s hp hc0 hg j W X‖ ≤
        C*(X/(27*(sourceCuspScale s.index)^2*
          (Ideal.absNorm (Ideal.span {c0*∏i,p i}):ℝ)^2))^(-(1/2):ℝ) := by
  obtain ⟨M,hM,hm⟩ := model_paperKernel_bound W lo hi hlo hsupp hW
  refine ⟨‖fixedRadialCoefficientScalar‖*M, mul_nonneg (norm_nonneg _) hM, ?_⟩
  intro ι _ p N a0 c0 mode D _ s hp hc0 hg j hb X hX
  have hc : c0*∏i,p i ≠ 0 := mul_ne_zero hc0 (Finset.prod_ne_zero_iff.mpr (fun i _ => hp i))
  have hnorm : 0 < (Ideal.absNorm (Ideal.span {c0*∏i,p i}):ℝ) := by
    exact_mod_cast Nat.pos_of_ne_zero (fun hz => hc
      (Ideal.span_singleton_eq_bot.mp (Ideal.absNorm_eq_zero_iff.mp hz)))
  have hs := sourceCuspScale_pos s.index
  have hv : 0 < X/(27*(sourceCuspScale s.index)^2*
      (Ideal.absNorm (Ideal.span {c0*∏i,p i}):ℝ)^2) := by positivity
  have hk := hm (reflectedCoefficient D s hp hc0 hg j)
    (reflectedCoefficient_norm_le D s hp hc0 hg j hb) _ hv
  rw [reflectedValue_eq_kernel, norm_mul, norm_mul, s.stratumShapeFactor_norm _ hc, mul_one]
  calc
    _ ≤ ‖fixedRadialCoefficientScalar‖*
        (M*(X/(27*(sourceCuspScale s.index)^2*
          (Ideal.absNorm (Ideal.span {c0*∏i,p i}):ℝ)^2))^(-(1/2):ℝ)) :=
      mul_le_mul_of_nonneg_left hk.2 (norm_nonneg _)
    _ = _ := by ring

/-- All moving local exponents are in {1,2,3,5}; the complete finite
frequency sums are retained by the exact source reflection identity. -/
theorem smoothedValue_nonexceptional_uniform_bound
    (W : ℝ → ℂ) (lo hi : ℝ) (hlo : 0 < lo)
    (hsupp : Function.support W ⊆ Set.Icc lo hi) (hW : ContDiff ℝ ∞ W) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀
      (ι : Type*) [Fintype ι] (p : ι → Eis) (N a0 c0 : Eis) (mode : Bool)
      (D : ControlledStratumArithmetic p N a0 c0 mode)
      [∀ i, (Ideal.span {p i}).IsMaximal]
      (hN : (9:Eis)*c0 ∣ N) (hr : lambda^2 ∣ (∏i,p i)-1)
      (hbase : if mode then lambda^2 ∣ a0-1 else lambda^2 ∣ c0-1)
      (s : FixedCuspShape (fixedCusp a0 c0 mode))
      (hp : ∀ i, p i ≠ 0) (hc0 : c0 ≠ 0)
      (hcop : Pairwise (Function.onFun IsCoprime (fun i => Ideal.span {p i})))
      (hg : ∀ i, lambda ∉ Ideal.span {p i})
      (hchar : ∀ i, ringChar (Eis ⧸ Ideal.span {p i}) ≠ 2)
      (j : ι → ℕ) (hj : ∀ i, j i < 6)
      (hj0 : ∀ i, j i ≠ 0) (hj4 : ∀ i, j i ≠ 4)
      (X : ℝ), 0 < X →
      ‖D.smoothedValue hN hr hbase s hp hc0 hg j W X‖ ≤
        C*(X/(27*(sourceCuspScale s.index)^2*
          (Ideal.absNorm (Ideal.span {c0*∏i,p i}):ℝ)^2))^(-(1/2):ℝ) := by
  obtain ⟨C,hC,hb⟩ := reflectedValue_uniform_bound W lo hi hlo hsupp hW
  refine ⟨C,hC,?_⟩
  intro ι _ p N a0 c0 mode D _ hN hr hbase s hp hc0 hcop hg hchar j hj hj0 hj4 X hX
  rw [D.smoothed_eq_reflected hN hr hbase s hp hc0 hcop hg hchar j hj
    W lo hi hlo hsupp hW X hX]
  exact hb ι p N a0 c0 mode D s hp hc0 hg j
    (QRHExperimental.ControlledBracketNorms.staticMultiplier_norm_le_one_nonexceptional
      D hN hr hbase hc0 hp hg hchar j hj hj0 hj4) X hX

#print axioms inverse_denominator
#print axioms reflectedCoefficient_norm_le
#print axioms reflectedValue_uniform_bound
#print axioms smoothedValue_nonexceptional_uniform_bound
end
end QRHExperimental.ControlledReflectionBound
