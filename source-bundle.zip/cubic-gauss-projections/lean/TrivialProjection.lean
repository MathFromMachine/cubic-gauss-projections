import OAI.NumberTheory.DirichletL.CubicSieve.GaussNorm
import OAI.NumberTheory.DirichletL.Mellin.InverseContour
import OAI.NumberTheory.DirichletL.Eisenstein.SourceMellinInversion

/-! Direct absolute-value estimates for the actual smooth Gauss columns.
These are uniform in bounded twists and use no cancellation assumption. -/
namespace QRHExperimental.TrivialProjection
noncomputable section
open OAI OAI.ActualEisensteinCubic OAI.CompletedGauss
open OAI.ConcretePrimeRowBridge hiding columnWeight
open scoped BigOperators Classical
local notation "Eis" => OAI.ActualEisensteinCubic.O

theorem columnWeight_norm_le_one (Ψ : Eis →* ℂ) (hΨ : ∀ z, ‖Ψ z‖ ≤ 1)
    (I : Ideal Eis) : ‖columnWeight Ψ I‖ ≤ 1 := by
  by_cases hI : Squarefree I ∧ primaryGenerator I ≠ 0
  · rw [columnWeight_eq Ψ I hI.1 hI.2, norm_mul, norm_mul, norm_star,
      FiniteGaussPhase.norm_angularFactor _ hI.2,
      SevenEighths.CubicSieve.gaussTwo_norm_one I hI, one_mul, one_mul]
    exact hΨ _
  · simp [columnWeight, squarefreeGaussCoefficient, hI]

def idealBall (H : ℝ) : Finset (Ideal Eis) :=
  (idealsUpTo ⌈H⌉₊).filter (fun I => (Ideal.absNorm I : ℝ) ≤ H)

lemma mem_idealBall (H : ℝ) (I : Ideal Eis) :
    I ∈ idealBall H ↔ I ≠ 0 ∧ (Ideal.absNorm I : ℝ) ≤ H := by
  simp only [idealBall, Finset.mem_filter, mem_idealsUpTo]
  constructor
  · rintro ⟨⟨hpos, _⟩, hN⟩
    refine ⟨?_, hN⟩
    intro hzero
    simpa [hzero] using hpos
  · rintro ⟨hI, hN⟩
    exact ⟨⟨Nat.one_le_iff_ne_zero.mpr (Ideal.absNorm_eq_zero_iff.not.mpr hI),
      by exact_mod_cast hN.trans (Nat.le_ceil H)⟩, hN⟩

lemma idealBall_card (H : ℝ) (hH : 0 ≤ H) :
    ((idealBall H).card : ℝ) ≤ 128 * H := by
  by_cases hs : (idealBall H).Nonempty
  · obtain ⟨I, hI⟩ := hs
    have hi := (mem_idealBall H I).mp hI
    have h1 := (norm_at_least_one I hi.1).trans hi.2
    exact DescentFiberCost.finite_ideal_count_real _ H h1
      (fun J hJ => ((mem_idealBall H J).mp hJ).1)
      (fun J hJ => ((mem_idealBall H J).mp hJ).2)
  · rw [Finset.not_nonempty_iff_eq_empty.mp hs]
    simp only [Finset.card_empty, Nat.cast_zero]
    positivity

def rawProjection (Ψ : Eis →* ℂ) (W : ℝ → ℂ) (X : ℝ) : ℂ :=
  ∑' I : Ideal Eis, columnWeight Ψ I * W ((Ideal.absNorm I : ℝ) / X)

lemma rawProjection_eq_sum (Ψ : Eis →* ℂ) (W : ℝ → ℂ) (b X : ℝ)
    (hX : 0 < X) (hW : ∀ x, W x ≠ 0 → x ≤ b) :
    rawProjection Ψ W X =
      ∑ I ∈ idealBall (b*X), columnWeight Ψ I * W ((Ideal.absNorm I : ℝ)/X) := by
  apply tsum_eq_sum
  intro I hI
  by_cases hi : I = 0
  · simp [hi]
  · have hw : W ((Ideal.absNorm I : ℝ)/X) = 0 := by
      by_contra hn
      exact hI ((mem_idealBall _ _).mpr ⟨hi, (div_le_iff₀ hX).mp (hW _ hn)⟩)
    rw [hw, mul_zero]

theorem rawProjection_norm_le (Ψ : Eis →* ℂ) (hΨ : ∀ z, ‖Ψ z‖ ≤ 1)
    (W : ℝ → ℂ) (b C X : ℝ) (hb : 0 ≤ b) (hC : 0 ≤ C) (hX : 0 < X)
    (hWs : ∀ x, W x ≠ 0 → x ≤ b) (hW : ∀ x, ‖W x‖ ≤ C) :
    ‖rawProjection Ψ W X‖ ≤ (128*b*C)*X := by
  rw [rawProjection_eq_sum Ψ W b X hX hWs]
  calc
    _ ≤ ∑ I ∈ idealBall (b*X), ‖columnWeight Ψ I * W ((Ideal.absNorm I : ℝ)/X)‖ :=
      norm_sum_le _ _
    _ ≤ ∑ _I ∈ idealBall (b*X), C := by
      apply Finset.sum_le_sum
      intro I hI
      rw [norm_mul]
      exact (mul_le_mul_of_nonneg_right (columnWeight_norm_le_one Ψ hΨ I)
        (norm_nonneg _)).trans (by simpa using hW ((Ideal.absNorm I : ℝ)/X))
    _ = ((idealBall (b*X)).card : ℝ)*C := by simp
    _ ≤ (128*(b*X))*C := mul_le_mul_of_nonneg_right
      (idealBall_card (b*X) (mul_nonneg hb hX.le)) hC
    _ = _ := by ring

#print axioms columnWeight_norm_le_one
#print axioms rawProjection_norm_le
end
end QRHExperimental.TrivialProjection
