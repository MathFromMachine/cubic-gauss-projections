import OAI.NumberTheory.DirichletL.Eisenstein.FixedFrequencyExpansion
import OAI.NumberTheory.DirichletL.GaussSum.ReflectionBrackets

/-! Exact norm of the finite controlled-stratum multiplier.  This keeps
the local brackets intact and does not take a Fourier l1 majorant.
Draft pending the owning agent's coordinated compiler run. -/
namespace QRHExperimental.ControlledBracketNorms
noncomputable section
open OAI OAI.ActualEisensteinCubic OAI.ConcreteTraceCRT
open OAI.CubicEisenstein OAI.CompletedGauss OAI.LocalReflectionBrackets
open scoped BigOperators Classical
local notation "Eis" => OAI.ActualEisensteinCubic.O

noncomputable local instance bracketQuotientField (P : Ideal Eis) [P.IsMaximal] :
    Field (Eis ⧸ P) := Ideal.Quotient.field P
noncomputable local instance bracketQuotientFintype (P : Ideal Eis) [P.IsMaximal] :
    Fintype (Eis ⧸ P) := Fintype.ofFinite _

variable {ι : Type*} [Fintype ι] {p : ι → Eis}
variable {N a c : Eis} {mode : Bool}
variable [∀ i, (Ideal.span {p i}).IsMaximal]

lemma bracketProduct_norm
    (D : ControlledStratumArithmetic p N a c mode)
    (hp : ∀ i, p i ≠ 0) (hg : ∀ i, lambda ∉ Ideal.span {p i})
    (hchar : ∀ i, ringChar (Eis ⧸ Ideal.span {p i}) ≠ 2)
    (j : ι → ℕ) (hj : ∀ i, j i < 6) (x : Eis) :
    ‖D.bracketProduct hp hg j x‖ =
      ∏ i, ‖bracket (actualSextic (Ideal.span {p i}) (hg i))
        (j i) (Ideal.Quotient.mk (Ideal.span {p i}) x)‖ := by
  letI (i : ι) : Field (Eis ⧸ Ideal.span {p i}) := Ideal.Quotient.field _
  letI (i : ι) : Fintype (Eis ⧸ Ideal.span {p i}) := Fintype.ofFinite _
  unfold ControlledStratumArithmetic.bracketProduct
  rw [norm_prod]
  apply Finset.prod_congr rfl
  intro i hi
  rw [norm_mul, norm_mul, FiniteRayExpansion.norm_char_unit,
    canonical_phase_norm (Ideal.span {p i}) (hg i) (hchar i)
      (quotientTrace (p i) (hp i))
      (GeneralPrimitiveTrace.eisTraceModChar_breveE_primitive (p i) (hp i))
      (j i) (hj i) (D.epsilon i), one_mul, one_mul]

theorem bracketProduct_norm_le_one_nonexceptional
    (D : ControlledStratumArithmetic p N a c mode)
    (hp : ∀ i, p i ≠ 0) (hg : ∀ i, lambda ∉ Ideal.span {p i})
    (hchar : ∀ i, ringChar (Eis ⧸ Ideal.span {p i}) ≠ 2)
    (j : ι → ℕ) (hj : ∀ i, j i < 6)
    (hj0 : ∀ i, j i ≠ 0) (hj4 : ∀ i, j i ≠ 4) (x : Eis) :
    ‖D.bracketProduct hp hg j x‖ ≤ 1 := by
  letI (i : ι) : Field (Eis ⧸ Ideal.span {p i}) := Ideal.Quotient.field _
  letI (i : ι) : Fintype (Eis ⧸ Ideal.span {p i}) := Fintype.ofFinite _
  rw [bracketProduct_norm D hp hg hchar j hj x]
  calc
    _ ≤ ∏ _i : ι, (1 : ℝ) :=
      Finset.prod_le_prod₀ (fun _ _ => norm_nonneg _)
        (fun i _ => norm_bracket_nonexceptional_le_one _ (j i) (hj4 i) (hj0 i) _)
    _ = 1 := by simp

lemma staticMultiplier_norm_eq
    (D : ControlledStratumArithmetic p N a c mode)
    (hN : (9 : Eis)*c ∣ N) (hr : lambda^2 ∣ (∏ i, p i)-1)
    (hbase : if mode then lambda^2 ∣ a-1 else lambda^2 ∣ c-1)
    (hc : c ≠ 0) (hp : ∀ i, p i ≠ 0)
    (hg : ∀ i, lambda ∉ Ideal.span {p i}) (j : ι → ℕ) (x : Eis) :
    ‖(star D.fixedFactor *
      ShortDraftCusp.A4BadPhase c hc (D.matrix (fun _ => 1) 1 1) D.U x) *
        D.bracketProduct hp hg j x‖ = ‖D.bracketProduct hp hg j x‖ := by
  rw [norm_mul, norm_mul, norm_star, D.fixedFactor_norm hN hr hbase,
    ShortDraftCusp.A4BadPhase_norm, one_mul, one_mul]

theorem staticMultiplier_norm_le_one_nonexceptional
    (D : ControlledStratumArithmetic p N a c mode)
    (hN : (9 : Eis)*c ∣ N) (hr : lambda^2 ∣ (∏ i, p i)-1)
    (hbase : if mode then lambda^2 ∣ a-1 else lambda^2 ∣ c-1)
    (hc : c ≠ 0) (hp : ∀ i, p i ≠ 0)
    (hg : ∀ i, lambda ∉ Ideal.span {p i})
    (hchar : ∀ i, ringChar (Eis ⧸ Ideal.span {p i}) ≠ 2)
    (j : ι → ℕ) (hj : ∀ i, j i < 6)
    (hj0 : ∀ i, j i ≠ 0) (hj4 : ∀ i, j i ≠ 4) (x : Eis) :
    ‖(star D.fixedFactor *
      ShortDraftCusp.A4BadPhase c hc (D.matrix (fun _ => 1) 1 1) D.U x) *
        D.bracketProduct hp hg j x‖ ≤ 1 := by
  rw [staticMultiplier_norm_eq D hN hr hbase hc hp hg j x]
  exact bracketProduct_norm_le_one_nonexceptional D hp hg hchar j hj hj0 hj4 x

#print axioms bracketProduct_norm
#print axioms bracketProduct_norm_le_one_nonexceptional
#print axioms staticMultiplier_norm_le_one_nonexceptional
end
end QRHExperimental.ControlledBracketNorms
