import RadialCumulativeMass

/-! Prescribed-divisor mass estimates on actual nonzero Eisenstein ideals.
No primality or squarefreeness of the prescribed divisor is required. -/
namespace QRHExperimental.DivisorIdealMass
noncomputable section
open OAI OAI.ActualEisensteinCubic OAI.CompletedGauss OAI.CubicEisenstein
open QRHExperimental.IdealPowerSums QRHExperimental.RadialCumulativeMass
open scoped BigOperators Classical
set_option maxHeartbeats 1600000
local notation "Eis" => OAI.ActualEisensteinCubic.O

def multiply (D I : NonzeroIdeal) : NonzeroIdeal :=
  ⟨D.val*I.val, mul_ne_zero D.property I.property⟩

lemma multiply_injective (D : NonzeroIdeal) : Function.Injective (multiply D) := by
  intro I J h
  apply Subtype.ext
  exact mul_left_cancel₀ D.property (congrArg (fun K : NonzeroIdeal => K.val) h)

lemma norm_multiply (D I : NonzeroIdeal) :
    idealNorm (multiply D I) = idealNorm D*idealNorm I := by
  simp only [idealNorm, multiply, map_mul, Nat.cast_mul]

lemma mem_range_multiply (D I : NonzeroIdeal) :
    I ∈ Set.range (multiply D) ↔ D.val ∣ I.val := by
  constructor
  · rintro ⟨J,rfl⟩
    exact dvd_mul_right _ _
  · rintro ⟨J,hJ⟩
    have hJ0 : J ≠ 0 := by
      intro hz
      apply I.property
      rw [hJ,hz,mul_zero]
    exact ⟨⟨J,hJ0⟩,Subtype.ext hJ.symm⟩

def divisorShortHalf (D : NonzeroIdeal) (U : ℝ) (I : NonzeroIdeal) : ℝ :=
  if D.val ∣ I.val then shortHalfTerm U I else 0

lemma divisorShortHalf_nonneg (D : NonzeroIdeal) (U : ℝ) (I : NonzeroIdeal) :
    0 ≤ divisorShortHalf D U I := by
  unfold divisorShortHalf shortHalfTerm
  split <;> (try split) <;> positivity

lemma divisorShortHalf_pullback (D : NonzeroIdeal) (U : ℝ) (I : NonzeroIdeal) :
    divisorShortHalf D U (multiply D I) =
      (idealNorm D)^(-(1/2):ℝ)*shortHalfTerm (U/idealNorm D) I := by
  have hd := nonzeroIdeal_norm_pos D
  have hi := nonzeroIdeal_norm_pos I
  rw [divisorShortHalf, if_pos (show D.val ∣ (multiply D I).val from dvd_mul_right D.val I.val)]
  unfold shortHalfTerm
  rw [norm_multiply]
  have hc : idealNorm D*idealNorm I ≤ U ↔ idealNorm I ≤ U/idealNorm D := by
    rw [le_div_iff₀ hd]
    simp only [mul_comm]
  simp only [hc]
  split
  · exact Real.mul_rpow hd.le hi.le
  · simp

lemma divisorShortHalf_outside (D : NonzeroIdeal) (U : ℝ) (I : NonzeroIdeal)
    (hI : I ∉ Set.range (multiply D)) : divisorShortHalf D U I = 0 := by
  exact if_neg (fun h => hI ((mem_range_multiply D I).mpr h))

theorem divisor_short_half_summable (D : NonzeroIdeal) (U : ℝ) (hU : 0 < U) :
    Summable (divisorShortHalf D U) := by
  have hs := (short_half_all (U/idealNorm D) (div_pos hU (nonzeroIdeal_norm_pos D))).1
  apply (multiply_injective D).summable_iff (divisorShortHalf_outside D U) |>.mp
  exact (hs.mul_left ((idealNorm D)^(-(1/2):ℝ))).congr
    (fun I => (divisorShortHalf_pullback D U I).symm)

theorem divisor_short_half_tsum (D : NonzeroIdeal) (U : ℝ) :
    (∑' I : NonzeroIdeal, divisorShortHalf D U I) =
      (idealNorm D)^(-(1/2):ℝ)*(∑' I : NonzeroIdeal, shortHalfTerm (U/idealNorm D) I) := by
  calc
    _ = ∑' I : NonzeroIdeal, divisorShortHalf D U (multiply D I) :=
      ((multiply_injective D).tsum_eq (by
        intro I hI
        by_contra hn
        exact hI (divisorShortHalf_outside D U I hn))).symm
    _ = _ := by simp only [divisorShortHalf_pullback, tsum_mul_left]

theorem divisor_short_half_tsum_le (D : NonzeroIdeal) (U : ℝ) (hU : 0 < U) :
    (∑' I : NonzeroIdeal, divisorShortHalf D U I) ≤
      512*(idealNorm D)^(-1:ℝ)*U^(1/2:ℝ) := by
  have hd := nonzeroIdeal_norm_pos D
  rw [divisor_short_half_tsum]
  calc
    _ ≤ (idealNorm D)^(-(1/2):ℝ)*(512*(U/idealNorm D)^(1/2:ℝ)) :=
      mul_le_mul_of_nonneg_left (short_half_all _ (div_pos hU hd)).2 (by positivity)
    _ = _ := by
      rw [Real.div_rpow hU.le hd.le]
      simp only [div_eq_mul_inv]
      rw [← Real.rpow_neg hd.le]
      calc
        _ = 512*((idealNorm D)^(-(1/2):ℝ)*(idealNorm D)^(-(1/2):ℝ))*U^(1/2:ℝ) := by ring
        _ = _ := by rw [← Real.rpow_add hd]; norm_num

def divisorPower (D : NonzeroIdeal) (σ : ℝ) (I : NonzeroIdeal) : ℝ :=
  if D.val ∣ I.val then (idealNorm I)^(-σ) else 0

lemma divisorPower_nonneg (D : NonzeroIdeal) (σ : ℝ) (I : NonzeroIdeal) :
    0 ≤ divisorPower D σ I := by
  unfold divisorPower
  split <;> positivity

lemma divisorPower_pullback (D : NonzeroIdeal) (σ : ℝ) (I : NonzeroIdeal) :
    divisorPower D σ (multiply D I) =
      (idealNorm D)^(-σ)*(idealNorm I)^(-σ) := by
  rw [divisorPower, if_pos (show D.val ∣ (multiply D I).val from dvd_mul_right D.val I.val), norm_multiply]
  exact Real.mul_rpow (nonzeroIdeal_norm_pos D).le (nonzeroIdeal_norm_pos I).le

lemma divisorPower_outside (D : NonzeroIdeal) (σ : ℝ) (I : NonzeroIdeal)
    (hI : I ∉ Set.range (multiply D)) : divisorPower D σ I = 0 := by
  exact if_neg (fun h => hI ((mem_range_multiply D I).mpr h))

theorem divisor_power_summable (D : NonzeroIdeal) (σ : ℝ) (hσ : 1 < σ) :
    Summable (divisorPower D σ) := by
  have hs := (nonzeroIdeal_norm_rpow_summable σ hσ).mul_left ((idealNorm D)^(-σ))
  apply (multiply_injective D).summable_iff (divisorPower_outside D σ) |>.mp
  exact hs.congr (fun I => (divisorPower_pullback D σ I).symm)

theorem divisor_power_tsum (D : NonzeroIdeal) (σ : ℝ) :
    (∑' I : NonzeroIdeal, divisorPower D σ I) =
      (idealNorm D)^(-σ)*(∑' I : NonzeroIdeal, (idealNorm I)^(-σ)) := by
  calc
    _ = ∑' I : NonzeroIdeal, divisorPower D σ (multiply D I) :=
      ((multiply_injective D).tsum_eq (by
        intro I hI
        by_contra hn
        exact hI (divisorPower_outside D σ I hn))).symm
    _ = _ := by simp only [divisorPower_pullback, tsum_mul_left]

#print axioms divisor_short_half_summable
#print axioms divisor_short_half_tsum_le
#print axioms divisor_power_summable
#print axioms divisor_power_tsum
end
end QRHExperimental.DivisorIdealMass
