import DivisorIdealMass

/-! Simultaneous prescribed-divisor restrictions on the actual sparse radial
coefficients. The bound uses ONE constant, independent of both ideal divisors.
The phase-numerator / good-prime bridge is not asserted in this module. -/
namespace QRHExperimental.DivisorRadialMass
noncomputable section
open OAI OAI.ActualEisensteinCubic OAI.CompletedGauss OAI.CubicEisenstein
open QRHExperimental.IdealPowerSums QRHExperimental.SparseRadialSummability
open QRHExperimental.RadialCumulativeMass QRHExperimental.DivisorIdealMass
open scoped BigOperators Classical
set_option maxHeartbeats 2000000
local notation "Eis" => OAI.ActualEisensteinCubic.O

abbrev AllOuterIndex := Eisˣ × ℕ × NonzeroIdeal

def cubeNonzero (J : CubeIndex) : NonzeroIdeal :=
  ⟨J.val, primaryGenerator_ne_zero_ideal _ J.property⟩

lemma cubeNonzero_injective : Function.Injective cubeNonzero := by
  intro I J h
  exact Subtype.ext (congrArg (fun K : NonzeroIdeal => K.val) h)

def allOuterWeight (o : AllOuterIndex) : ℝ :=
  (3:ℝ)^(-(5/6:ℝ)*(o.2.1:ℝ))*(idealNorm o.2.2)^(-(5/2):ℝ)

lemma allOuterWeight_nonneg (o : AllOuterIndex) : 0 ≤ allOuterWeight o := by
  unfold allOuterWeight; positivity

lemma allOuterWeight_summable : Summable allOuterWeight := by
  have hm : Summable (fun m : ℕ => (3:ℝ)^(-(5/6:ℝ)*(m:ℝ))) := by
    have hg := summable_geometric_of_lt_one
      (Real.rpow_nonneg (by norm_num : 0 ≤ (3:ℝ)) (-(5/6:ℝ)))
      (Real.rpow_lt_one_of_one_lt_of_neg (by norm_num : 1 < (3:ℝ)) (by norm_num))
    apply hg.congr
    intro m
    exact (Real.rpow_mul_natCast (by norm_num : 0 ≤ (3:ℝ)) _ m).symm
  have hJ := nonzeroIdeal_norm_rpow_summable (5/2) (by norm_num)
  have hp := hm.mul_of_nonneg hJ (fun _ => by positivity)
    (fun I => Real.rpow_nonneg (nonzeroIdeal_norm_pos I).le _)
  let : Finite Eisˣ := PrimaryIdealUnitReindex.finite_units
  have hu : Summable (fun _ : Eisˣ => (1:ℝ)) := Summable.of_finite
  have hall := hu.mul_of_nonneg hp (fun _ => zero_le_one) (fun p => by positivity)
  apply hall.congr
  intro p
  simp only [allOuterWeight, one_mul]

def allOuterDivisor (E : NonzeroIdeal) (o : AllOuterIndex) : ℝ :=
  if E.val ∣ o.2.2.val then allOuterWeight o else 0

lemma allOuterDivisor_nonneg (E : NonzeroIdeal) (o : AllOuterIndex) :
    0 ≤ allOuterDivisor E o := by
  unfold allOuterDivisor; split <;> simp only [allOuterWeight_nonneg, le_refl]

lemma allOuterDivisor_summable (E : NonzeroIdeal) : Summable (allOuterDivisor E) := by
  apply allOuterWeight_summable.of_nonneg_of_le (allOuterDivisor_nonneg E)
  intro o; unfold allOuterDivisor; split <;> simp only [le_refl, allOuterWeight_nonneg]

lemma allOuterDivisor_tsum (E : NonzeroIdeal) :
    (∑' o : AllOuterIndex, allOuterDivisor E o) =
      (idealNorm E)^(-(5/2):ℝ)*(∑' o : AllOuterIndex, allOuterWeight o) := by
  have heq : ∀ o : AllOuterIndex, allOuterDivisor E o =
      (3:ℝ)^(-(5/6:ℝ)*(o.2.1:ℝ))*divisorPower E (5/2) o.2.2 := by
    intro o; unfold allOuterDivisor allOuterWeight divisorPower
    split <;> simp
  rw [(allOuterDivisor_summable E).tsum_prod, allOuterWeight_summable.tsum_prod,
    ← tsum_mul_left]
  apply tsum_congr
  intro u
  rw [((allOuterDivisor_summable E).prod_factor u).tsum_prod,
    (allOuterWeight_summable.prod_factor u).tsum_prod]
  simp_rw [heq]
  simp only [allOuterWeight, tsum_mul_left, divisor_power_tsum]
  calc
    _ = ∑' m : ℕ, (idealNorm E)^(-(5/2):ℝ)*
        ((3:ℝ)^(-(5/6:ℝ)*(m:ℝ))*(∑' I : NonzeroIdeal, (idealNorm I)^(-(5/2):ℝ))) := by
      apply tsum_congr
      intro m
      ring
    _ = _ := tsum_mul_left

def outerDivisor (E : NonzeroIdeal) (o : OuterIndex) : ℝ :=
  if E.val ∣ o.2.2.val then outerWeight o else 0

lemma outerDivisor_nonneg (E : NonzeroIdeal) (o : OuterIndex) : 0 ≤ outerDivisor E o := by
  unfold outerDivisor; split <;> simp only [outerWeight_nonneg, le_refl]

lemma outerDivisor_summable (E : NonzeroIdeal) : Summable (outerDivisor E) := by
  apply outerWeight_summable.of_nonneg_of_le (outerDivisor_nonneg E)
  intro o; unfold outerDivisor; split <;> simp only [le_refl, outerWeight_nonneg]

lemma outerDivisor_tsum_le (E : NonzeroIdeal) :
    (∑' o : OuterIndex, outerDivisor E o) ≤
      (idealNorm E)^(-(5/2):ℝ)*(∑' o : AllOuterIndex, allOuterWeight o) := by
  let f : OuterIndex → AllOuterIndex := fun o => (o.1,o.2.1,cubeNonzero o.2.2)
  have hf : Function.Injective f := by
    rintro ⟨u,m,I⟩ ⟨v,n,J⟩ h
    have hu := congrArg Prod.fst h
    have hm := congrArg (fun o : AllOuterIndex => o.2.1) h
    have hJ := cubeNonzero_injective (congrArg (fun o : AllOuterIndex => o.2.2) h)
    exact Prod.ext hu (Prod.ext hm hJ)
  rw [← allOuterDivisor_tsum]
  apply Summable.tsum_le_tsum_of_inj f hf
    (fun o _ => allOuterDivisor_nonneg E o)
    (fun o => ?_) (outerDivisor_summable E) (allOuterDivisor_summable E)
  exact le_rfl

lemma squarefree_divisor_short_half (D : NonzeroIdeal) (U : ℝ) (hU : 0 < U) :
    Summable (fun I : SquarefreeIndex => divisorShortHalf D U (squarefreeNonzero I)) ∧
      (∑' I : SquarefreeIndex, divisorShortHalf D U (squarefreeNonzero I)) ≤
        512*(idealNorm D)^(-1:ℝ)*U^(1/2:ℝ) := by
  have hall := divisor_short_half_summable D U hU
  have hs := hall.comp_injective squarefreeNonzero_injective
  refine ⟨hs, ?_⟩
  apply le_trans _ (divisor_short_half_tsum_le D U hU)
  exact Summable.tsum_le_tsum_of_inj squarefreeNonzero squarefreeNonzero_injective
    (fun I _ => divisorShortHalf_nonneg D U I) (fun _ => le_rfl) hs hall

def cutoffDivisor (D E : NonzeroIdeal) (T : ℝ) (p : ReorderedIndex) : ℝ :=
  if D.val ∣ p.2.val ∧ E.val ∣ p.1.2.2.val then cutoffWeight T p else 0

lemma cutoffDivisor_nonneg (D E : NonzeroIdeal) (T : ℝ) (p : ReorderedIndex) :
    0 ≤ cutoffDivisor D E T p := by
  unfold cutoffDivisor; split <;> simp only [cutoffWeight_nonneg, le_refl]

lemma cutoffDivisor_summable (D E : NonzeroIdeal) (T : ℝ) (hT : 0 < T) :
    Summable (cutoffDivisor D E T) := by
  apply (cutoff_summable T hT).of_nonneg_of_le (cutoffDivisor_nonneg D E T)
  intro p; unfold cutoffDivisor; split <;> simp only [le_refl, cutoffWeight_nonneg]

lemma cutoffDivisor_inner (D E : NonzeroIdeal) (T : ℝ) (hT : 0 < T) (o : OuterIndex) :
    (∑' I : SquarefreeIndex, cutoffDivisor D E T (o,I)) ≤
      ((512*Real.sqrt T)*(idealNorm D)^(-1:ℝ))*outerDivisor E o := by
  by_cases hE : E.val ∣ o.2.2.val
  · have hy := eligible_norm_pos o.2.2.val o.2.2.property
    have hU : 0 < T/((3:ℝ)^o.2.1*(Ideal.absNorm o.2.2.val:ℝ)^3) := by positivity
    have hb := squarefree_divisor_short_half D _ hU
    have heq : ∀ I : SquarefreeIndex, cutoffDivisor D E T (o,I) =
        ((3:ℝ)^(-(1/3:ℝ)*(o.2.1:ℝ))*(Ideal.absNorm o.2.2.val:ℝ)^(-1:ℝ))*
          divisorShortHalf D (T/((3:ℝ)^o.2.1*(Ideal.absNorm o.2.2.val:ℝ)^3))
            (squarefreeNonzero I) := by
      intro I
      simp only [cutoffDivisor, hE, and_true, cutoffWeight, divisorShortHalf,
        squarefreeNonzero]
      by_cases hDI : D.val ∣ I.val <;> simp only [hDI, if_true, if_false, mul_zero]
    simp_rw [heq]
    rw [tsum_mul_left, outerDivisor, if_pos hE]
    calc
      _ ≤ ((3:ℝ)^(-(1/3:ℝ)*(o.2.1:ℝ))*(Ideal.absNorm o.2.2.val:ℝ)^(-1:ℝ))*
          (512*(idealNorm D)^(-1:ℝ)*
            (T/((3:ℝ)^o.2.1*(Ideal.absNorm o.2.2.val:ℝ)^3))^(1/2:ℝ)) :=
        mul_le_mul_of_nonneg_left hb.2 (by positivity)
      _ = ((3:ℝ)^(-(1/3:ℝ)*(o.2.1:ℝ))*(Ideal.absNorm o.2.2.val:ℝ)^(-1:ℝ)*
          (512*(T/((3:ℝ)^o.2.1*(Ideal.absNorm o.2.2.val:ℝ)^3))^(1/2:ℝ)))*
            (idealNorm D)^(-1:ℝ) := by ring
      _ = _ := by rw [cutoff_scale T _ o.2.1 hT hy]; unfold outerWeight; ring
  · simp only [cutoffDivisor, hE, and_false, if_false, tsum_zero, outerDivisor, mul_zero, le_refl]

theorem cutoffDivisor_tsum_le (D E : NonzeroIdeal) (T : ℝ) (hT : 0 < T) :
    (∑' p : ReorderedIndex, cutoffDivisor D E T p) ≤
      (512*(∑' o : AllOuterIndex, allOuterWeight o))*
        (idealNorm D)^(-1:ℝ)*(idealNorm E)^(-(5/2):ℝ)*Real.sqrt T := by
  have hs := cutoffDivisor_summable D E T hT
  rw [hs.tsum_prod]
  calc
    _ ≤ ∑' o : OuterIndex, ((512*Real.sqrt T)*(idealNorm D)^(-1:ℝ))*outerDivisor E o :=
      hs.prod.tsum_le_tsum (cutoffDivisor_inner D E T hT)
        ((outerDivisor_summable E).mul_left _)
    _ = ((512*Real.sqrt T)*(idealNorm D)^(-1:ℝ))*(∑' o : OuterIndex, outerDivisor E o) :=
      tsum_mul_left
    _ ≤ ((512*Real.sqrt T)*(idealNorm D)^(-1:ℝ))*
        ((idealNorm E)^(-(5/2):ℝ)*(∑' o : AllOuterIndex, allOuterWeight o)) :=
      mul_le_mul_of_nonneg_left (outerDivisor_tsum_le E) (by positivity)
    _ = _ := by ring

def indexedDivisorMass (j : Fin 3) (z : ℂ) (D E : NonzeroIdeal) (T : ℝ)
    (p : ReorderedIndex) : ℝ :=
  if D.val ∣ p.2.val ∧ E.val ∣ p.1.2.2.val then radialMassTerm j z T (frequency p) else 0

lemma indexedDivisorMass_nonneg (j : Fin 3) (z : ℂ) (D E : NonzeroIdeal) (T : ℝ)
    (p : ReorderedIndex) : 0 ≤ indexedDivisorMass j z D E T p := by
  unfold indexedDivisorMass; split <;> simp only [radialMassTerm_nonneg, le_refl]

lemma indexedDivisorMass_bound (j : Fin 3) (z : ℂ) (D E : NonzeroIdeal) (T : ℝ)
    (p : ReorderedIndex) : indexedDivisorMass j z D E T p ≤
      (radialConstant j*fixedCuspCoefficientBound)*cutoffDivisor D E T p := by
  unfold indexedDivisorMass cutoffDivisor
  split
  · exact indexed_mass_bound j z T p
  · simp

theorem simultaneous_divisor_cumulative_mass_uniform :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (j : Fin 3) (z : ℂ) (D E : NonzeroIdeal) (T : ℝ), 0 < T →
      Summable (indexedDivisorMass j z D E T) ∧
        (∑' p : ReorderedIndex, indexedDivisorMass j z D E T p) ≤
          C*(idealNorm D)^(-1:ℝ)*(idealNorm E)^(-(5/2):ℝ)*Real.sqrt T := by
  let Cj : Fin 3 → ℝ := fun j => (radialConstant j*fixedCuspCoefficientBound)*
    (512*(∑' o : AllOuterIndex, allOuterWeight o))
  have hCj : ∀ j, 0 ≤ Cj j := by
    intro j; dsimp only [Cj]
    exact mul_nonneg (mul_nonneg (radialConstant_nonneg j) fixedCuspCoefficientBound_pos.le)
      (mul_nonneg (by norm_num) (tsum_nonneg allOuterWeight_nonneg))
  refine ⟨∑ j : Fin 3, Cj j, Finset.sum_nonneg (fun j _ => hCj j), ?_⟩
  intro j z D E T hT
  let K := radialConstant j*fixedCuspCoefficientBound
  have hK : 0 ≤ K := mul_nonneg (radialConstant_nonneg j) fixedCuspCoefficientBound_pos.le
  have hc := cutoffDivisor_summable D E T hT
  have hs := (hc.mul_left K).of_nonneg_of_le (indexedDivisorMass_nonneg j z D E T)
    (indexedDivisorMass_bound j z D E T)
  refine ⟨hs, ?_⟩
  calc
    _ ≤ ∑' p : ReorderedIndex, K*cutoffDivisor D E T p :=
      hs.tsum_le_tsum (indexedDivisorMass_bound j z D E T) (hc.mul_left K)
    _ = K*(∑' p : ReorderedIndex, cutoffDivisor D E T p) := tsum_mul_left
    _ ≤ K*((512*(∑' o : AllOuterIndex, allOuterWeight o))*
        (idealNorm D)^(-1:ℝ)*(idealNorm E)^(-(5/2):ℝ)*Real.sqrt T) :=
      mul_le_mul_of_nonneg_left (cutoffDivisor_tsum_le D E T hT) hK
    _ = Cj j*(idealNorm D)^(-1:ℝ)*(idealNorm E)^(-(5/2):ℝ)*Real.sqrt T := by
      dsimp only [Cj,K]; ring
    _ ≤ _ := mul_le_mul_of_nonneg_right
      (mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right
        (Finset.single_le_sum (fun i _ => hCj i) (Finset.mem_univ j)) (by positivity))
        (by positivity)) (Real.sqrt_nonneg T)

#print axioms cutoffDivisor_tsum_le
#print axioms simultaneous_divisor_cumulative_mass_uniform
end
end QRHExperimental.DivisorRadialMass
