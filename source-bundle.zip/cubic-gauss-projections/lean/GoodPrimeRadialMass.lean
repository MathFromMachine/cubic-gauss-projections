import PhaseNumeratorSupport

/-! Actual good-prime restricted radial mass, with the exact phase-numerator
support bridge and one uniform counting constant. Draft pending compile. -/
namespace QRHExperimental.GoodPrimeRadialMass
noncomputable section
open OAI OAI.ActualEisensteinCubic OAI.CubicEisenstein OAI.CompletedGauss
open QRHExperimental.IdealPowerSums QRHExperimental.RadialCumulativeMass
open QRHExperimental.DivisorRadialMass QRHExperimental.PhaseNumeratorSupport
open scoped Classical BigOperators
local notation "Eis" => OAI.ActualEisensteinCubic.O

def oneIdeal : NonzeroIdeal := ⟨1, one_ne_zero⟩

def goodPrimeMass (j : Fin 3) (z : ℂ) (P : NonzeroIdeal) (T : ℝ)
    (h : Eis) : ℝ := if h ∈ P.val then radialMassTerm j z T h else 0

lemma goodPrimeMass_nonneg (j : Fin 3) (z : ℂ) (P : NonzeroIdeal)
    (T : ℝ) (h : Eis) : 0 ≤ goodPrimeMass j z P T h := by
  unfold goodPrimeMass
  split <;> simp only [radialMassTerm_nonneg, le_refl]

lemma goodPrimeMass_le (j : Fin 3) (z : ℂ) (P : NonzeroIdeal)
    (T : ℝ) (h : Eis) : goodPrimeMass j z P T h ≤ radialMassTerm j z T h := by
  unfold goodPrimeMass
  split <;> simp only [le_refl, radialMassTerm_nonneg]

lemma goodPrimeMass_outside (j : Fin 3) (z : ℂ) (P : NonzeroIdeal)
    (T : ℝ) (h : Eis) (hh : h ∉ Set.range frequency) : goodPrimeMass j z P T h = 0 := by
  simp only [goodPrimeMass, radialMassTerm_outside j z T h hh, ite_self]

lemma indicator_union_le (p q : Prop) [Decidable p] [Decidable q]
    (x : ℝ) (hx : 0 ≤ x) :
    (if p ∨ q then x else 0) ≤ (if p then x else 0)+(if q then x else 0) := by
  by_cases hp : p <;> by_cases hq : q <;> simp [hp,hq,hx]

lemma indexed_goodPrimeMass_le (j : Fin 3) (z : ℂ)
    (P : NonzeroIdeal) [P.val.IsPrime] (hgood : lambda ∉ P.val)
    (T : ℝ) (p : ReorderedIndex) :
    goodPrimeMass j z P T (frequency p) ≤
      indexedDivisorMass j z P oneIdeal T p +
        indexedDivisorMass j z oneIdeal P T p := by
  have hm : frequency p ∈ P.val ↔ P.val ∣ p.2.val ∨ P.val ∣ p.1.2.2.val := by
    simpa only [frequency,reorder] using fullFrequency_mem_iff P.val hgood (reorder p)
  simpa only [goodPrimeMass,indexedDivisorMass,oneIdeal,one_dvd,and_true,true_and,hm]
    using indicator_union_le (P.val ∣ p.2.val) (P.val ∣ p.1.2.2.val)
      (radialMassTerm j z T (frequency p)) (radialMassTerm_nonneg j z T (frequency p))

theorem good_prime_cumulative_mass_uniform :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (j : Fin 3) (z : ℂ) (P : NonzeroIdeal)
      [P.val.IsPrime], lambda ∉ P.val → ∀ T : ℝ, 0 < T →
        Summable (goodPrimeMass j z P T) ∧
          (∑' h : Eis, goodPrimeMass j z P T h) ≤
            C*((idealNorm P)^(-1:ℝ)+(idealNorm P)^(-(5/2):ℝ))*Real.sqrt T := by
  obtain ⟨C,hC,hb⟩ := simultaneous_divisor_cumulative_mass_uniform
  refine ⟨C,hC,?_⟩
  intro j z P hP hgood T hT
  have ha := (sourceCuspRadialCoefficient_cumulative_mass j z T hT).1.of_nonneg_of_le
    (goodPrimeMass_nonneg j z P T) (goodPrimeMass_le j z P T)
  have hi := ha.comp_injective frequency_injective
  have hD := hb j z P oneIdeal T hT
  have hE := hb j z oneIdeal P T hT
  refine ⟨ha,?_⟩
  have he : (∑' h : Eis, goodPrimeMass j z P T h) =
      ∑' p : ReorderedIndex, goodPrimeMass j z P T (frequency p) :=
    (frequency_injective.tsum_eq (by
      intro h hh
      by_contra hn
      exact hh (goodPrimeMass_outside j z P T h hn))).symm
  rw [he]
  calc
    _ ≤ ∑' p : ReorderedIndex,
        (indexedDivisorMass j z P oneIdeal T p + indexedDivisorMass j z oneIdeal P T p) :=
      hi.tsum_le_tsum (indexed_goodPrimeMass_le j z P hgood T) (hD.1.add hE.1)
    _ = (∑' p : ReorderedIndex, indexedDivisorMass j z P oneIdeal T p) +
        (∑' p : ReorderedIndex, indexedDivisorMass j z oneIdeal P T p) :=
      hD.1.tsum_add hE.1
    _ ≤ C*(idealNorm P)^(-1:ℝ)*(idealNorm oneIdeal)^(-(5/2):ℝ)*Real.sqrt T +
        C*(idealNorm oneIdeal)^(-1:ℝ)*(idealNorm P)^(-(5/2):ℝ)*Real.sqrt T :=
      add_le_add hD.2 hE.2
    _ = _ := by simp only [oneIdeal,idealNorm,map_one,Nat.cast_one,Real.one_rpow,mul_one]; ring

def phasePrimeMass (j : Fin 3) (z : ℂ) (P : NonzeroIdeal)
    (w : Eisˣ) (T : ℝ) (h : Eis) : ℝ :=
  if sourceCuspPhaseNumerator j w.val h ∈ P.val then radialMassTerm j z T h else 0

lemma phasePrimeMass_eq (j : Fin 3) (z : ℂ) (P : NonzeroIdeal)
    [P.val.IsPrime] (hgood : lambda ∉ P.val) (w : Eisˣ) (T : ℝ) (h : Eis) :
    phasePrimeMass j z P w T h = goodPrimeMass j z P T h := by
  by_cases hc : (sourceCuspCoefficients j).value h = 0
  · have hz : radialMassTerm j z T h = 0 := by
      simp [radialMassTerm, sourceCuspRadialCoefficient, sourceCuspRadialBaseCoefficient, hc]
    simp only [phasePrimeMass,goodPrimeMass,hz,ite_self]
  · simp only [phasePrimeMass,goodPrimeMass,phaseNumerator_mem_iff P.val hgood j w h hc]

theorem phase_prime_cumulative_mass_uniform :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (j : Fin 3) (z : ℂ) (P : NonzeroIdeal)
      [P.val.IsPrime], lambda ∉ P.val → ∀ (w : Eisˣ) (T : ℝ), 0 < T →
        Summable (phasePrimeMass j z P w T) ∧
          (∑' h : Eis, phasePrimeMass j z P w T h) ≤
            C*((idealNorm P)^(-1:ℝ)+(idealNorm P)^(-(5/2):ℝ))*Real.sqrt T := by
  obtain ⟨C,hC,hb⟩ := good_prime_cumulative_mass_uniform
  refine ⟨C,hC,?_⟩
  intro j z P hP hgood w T hT
  have he : phasePrimeMass j z P w T = goodPrimeMass j z P T :=
    funext (phasePrimeMass_eq j z P hgood w T)
  rw [he]
  exact hb j z P hgood T hT

#print axioms good_prime_cumulative_mass_uniform
#print axioms phase_prime_cumulative_mass_uniform
end
end QRHExperimental.GoodPrimeRadialMass
