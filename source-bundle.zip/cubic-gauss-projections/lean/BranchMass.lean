import WeightedKernelBound

/-! Finite local branches preserve one common cumulative-mass constant.

The simultaneous branch-density estimate is an explicit hypothesis here.
This module does not assert the arithmetic density or its source adapter.
-/
namespace QRHExperimental.BranchMass
noncomputable section
open scoped BigOperators Classical
open QRHExperimental.WeightedKernelBound
set_option maxHeartbeats 1000000

theorem finite_product_mass
    {ι π κ : Type*} [Fintype π] [Fintype κ]
    (a r : ι → ℝ) (g : π → κ → ι → ℝ) (d : π → κ → ℝ) (C : ℝ)
    (hbranch : ∀ (f : π → κ),
      SqrtMassBound (fun i => a i * ∏ p, g p (f p) i) r
        (C * ∏ p, d p (f p))) :
    SqrtMassBound (fun i => a i * ∏ p, ∑ k, g p k i) r
      (C * ∏ p, ∑ k, d p k) := by
  intro S T hT hS
  calc
    _ = ∑ i ∈ S, ∑ f : π → κ, a i * ∏ p, g p (f p) i := by
      apply Finset.sum_congr rfl
      intro i hi
      dsimp only
      rw [Fintype.prod_sum, Finset.mul_sum]
    _ = ∑ f : π → κ, ∑ i ∈ S, a i * ∏ p, g p (f p) i :=
      Finset.sum_comm
    _ ≤ ∑ f : π → κ, (C * ∏ p, d p (f p)) * T^(1/2:ℝ) :=
      Finset.sum_le_sum (fun f _ => hbranch f S T hT hS)
    _ = C * (∑ f : π → κ, ∏ p, d p (f p)) * T^(1/2:ℝ) := by
      rw [← Finset.sum_mul, ← Finset.mul_sum]
    _ = _ := by rw [← Fintype.prod_sum]

theorem dominated_product_mass
    {ι π κ : Type*} [Fintype π] [Fintype κ]
    (b : ι → ℂ) (a r : ι → ℝ)
    (g : π → κ → ι → ℝ) (d : π → κ → ℝ) (C : ℝ)
    (hbranch : ∀ (f : π → κ),
      SqrtMassBound (fun i => a i * ∏ p, g p (f p) i) r
        (C * ∏ p, d p (f p)))
    (hdom : ∀ i, ‖b i‖ ≤ a i * ∏ p, ∑ k, g p k i) :
    SqrtMassBound (fun i => ‖b i‖) r (C * ∏ p, ∑ k, d p k) := by
  intro S T hT hS
  exact (Finset.sum_le_sum (fun i _ => hdom i)).trans
    (finite_product_mass a r g d C hbranch S T hT hS)

theorem product_kernel_summable_and_bound
    {ι π κ : Type*} [Fintype π] [Fintype κ]
    (b : ι → ℂ) (a r : ι → ℝ)
    (g : π → κ → ι → ℝ) (d : π → κ → ℝ) (C D : ℝ)
    (hC : 0 ≤ C) (hD : 0 ≤ D) (hd : ∀ p k, 0 ≤ d p k)
    (hr : ∀ i, 0 < r i)
    (hbranch : ∀ (f : π → κ),
      SqrtMassBound (fun i => a i * ∏ p, g p (f p) i) r
        (C * ∏ p, d p (f p)))
    (hdom : ∀ i, ‖b i‖ ≤ a i * ∏ p, ∑ k, g p k i)
    (K : ℝ → ℂ)
    (hsmall : ∀ t, 0 < t → t ≤ 1 → ‖K t‖ ≤ D)
    (hlarge : ∀ t, 1 ≤ t → ‖K t‖ ≤ D/t)
    (v : ℝ) (hv : 0 < v) :
    Summable (fun i => ‖b i * K (v*r i)‖) ∧
      ‖∑' i, b i * K (v*r i)‖ ≤
        5 * (C * ∏ p, ∑ k, d p k) * D * v^(-(1/2):ℝ) := by
  have hmass := dominated_product_mass b a r g d C hbranch hdom
  have hcost : 0 ≤ C * ∏ p, ∑ k, d p k :=
    mul_nonneg hC (Finset.prod_nonneg (fun p _ =>
      Finset.sum_nonneg (fun k _ => hd p k)))
  exact kernel_summable_and_bound b r _ D hcost hD hr hmass K hsmall hlarge v hv

#print axioms finite_product_mass
#print axioms dominated_product_mass
#print axioms product_kernel_summable_and_bound
end
end QRHExperimental.BranchMass
