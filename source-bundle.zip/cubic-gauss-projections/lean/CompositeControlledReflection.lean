import CompositeBracketDomination

/-! Uniform actual controlled reflection for arbitrary finite mixtures of
sextic exponents. Simultaneous divisor densities preserve one common
constant, independent of the size of the prime family. -/
namespace QRHExperimental.CompositeControlledReflection
noncomputable section
open OAI OAI.ActualEisensteinCubic OAI.ConcreteTraceCRT
open OAI.CubicEisenstein OAI.CompletedGauss OAI.CompletedDyadic
open OAI.CubicEisenstein.ControlledStratumArithmetic
open QRHExperimental.IdealPowerSums QRHExperimental.SparseRadialSummability
open QRHExperimental.ModelKernelMass QRHExperimental.ControlledReflectionBound
open QRHExperimental.CompositeModelKernel QRHExperimental.CompositeBracketDomination
open scoped BigOperators Classical ContDiff
set_option maxHeartbeats 2000000
local notation "Eis" => OAI.ActualEisensteinCubic.O

theorem reflectedValue_composite_uniform_bound
    (W : ℝ → ℂ) (lo hi : ℝ) (hlo : 0 < lo)
    (hsupp : Function.support W ⊆ Set.Icc lo hi) (hW : ContDiff ℝ ∞ W) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀
      (ι : Type*) [Fintype ι] (p : ι → Eis) (N a0 c0 : Eis) (mode : Bool)
      (D : ControlledStratumArithmetic p N a0 c0 mode)
      [∀ i, (Ideal.span {p i}).IsMaximal]
      (hN : (9:Eis)*c0 ∣ N) (hr : lambda^2 ∣ (∏i,p i)-1)
      (hbase : if mode then lambda^2 ∣ a0-1 else lambda^2 ∣ c0-1)
      (s : FixedCuspShape (fixedCusp a0 c0 mode))
      (hp : ∀ i, p i ≠ 0) (hc0 : c0 ≠ 0)
      (hcop : Pairwise (Function.onFun IsCoprime (fun i : ι => Ideal.span {p i})))
      (hg : ∀ i, lambda ∉ Ideal.span {p i})
      (hchar : ∀ i, ringChar (Eis ⧸ Ideal.span {p i}) ≠ 2)
      (j : ι → ℕ) (hj : ∀ i, j i < 6) (X : ℝ), 0 < X →
      ‖D.reflectedValue s hp hc0 hg j W X‖ ≤
        C*(∏ i, localReflectionCost (Ideal.absNorm (Ideal.span {p i}):ℝ) (j i))*
          (X/(27*(sourceCuspScale s.index)^2*
            (Ideal.absNorm (Ideal.span {c0*∏i,p i}):ℝ)^2))^(-(1/2):ℝ) := by
  obtain ⟨M,hM,hm⟩ := composite_model_paperKernel_bound W lo hi hlo hsupp hW
  refine ⟨‖fixedRadialCoefficientScalar‖*M,mul_nonneg (norm_nonneg _) hM,?_⟩
  intro ι _ p N a0 c0 mode D _ hN hr hbase s hp hc0 hcop hg hchar j hj X hX
  have hc : c0*∏i,p i ≠ 0 := mul_ne_zero hc0 (Finset.prod_ne_zero_iff.mpr (fun i _ => hp i))
  have hnorm : 0 < (Ideal.absNorm (Ideal.span {c0*∏i,p i}):ℝ) := by
    exact_mod_cast Nat.pos_of_ne_zero (fun hz => hc
      (Ideal.span_singleton_eq_bot.mp (Ideal.absNorm_eq_zero_iff.mp hz)))
  have hs := sourceCuspScale_pos s.index
  have hv : 0 < X/(27*(sourceCuspScale s.index)^2*
      (Ideal.absNorm (Ideal.span {c0*∏i,p i}):ℝ)^2) := by positivity
  have hcop' : Pairwise (fun i k => IsCoprime (primeIdeal hp i).val (primeIdeal hp k).val) := hcop
  have hk := hm ι (primeIdeal hp) hcop'
    (fun i => bracketWeights (primeIdeal hp i) (j i))
    (fun i k => bracketWeights_nonneg _ _ _)
    (reflectedCoefficient D s hp hc0 hg j)
    (reflectedCoefficient_composite_norm_le D s hp hc0 hg hchar hN hr hbase j hj) _ hv
  simp only [bracketWeights_localTotal,primeIdeal,idealNorm] at hk
  rw [reflectedValue_eq_kernel,norm_mul,norm_mul,s.stratumShapeFactor_norm _ hc,mul_one]
  calc
    _ ≤ ‖fixedRadialCoefficientScalar‖*(M*
        (∏ i, localReflectionCost (Ideal.absNorm (Ideal.span {p i}):ℝ) (j i))*
          (X/(27*(sourceCuspScale s.index)^2*
            (Ideal.absNorm (Ideal.span {c0*∏i,p i}):ℝ)^2))^(-(1/2):ℝ)) :=
      mul_le_mul_of_nonneg_left hk.2 (norm_nonneg _)
    _ = _ := by ring

theorem smoothedValue_composite_uniform_bound
    (W : ℝ → ℂ) (lo hi : ℝ) (hlo : 0 < lo)
    (hsupp : Function.support W ⊆ Set.Icc lo hi) (hW : ContDiff ℝ ∞ W) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀
      (ι : Type*) [Fintype ι] (p : ι → Eis) (N a0 c0 : Eis) (mode : Bool)
      (D : ControlledStratumArithmetic p N a0 c0 mode)
      [∀ i, (Ideal.span {p i}).IsMaximal]
      (hN : (9:Eis)*c0 ∣ N) (hr : lambda^2 ∣ (∏i,p i)-1)
      (hbase : if mode then lambda^2 ∣ a0-1 else lambda^2 ∣ c0-1)
      (s : FixedCuspShape (fixedCusp a0 c0 mode))
      (hp : ∀ i, p i ≠ 0) (hc0 : c0 ≠ 0)
      (hcop : Pairwise (Function.onFun IsCoprime (fun i : ι => Ideal.span {p i})))
      (hg : ∀ i, lambda ∉ Ideal.span {p i})
      (hchar : ∀ i, ringChar (Eis ⧸ Ideal.span {p i}) ≠ 2)
      (j : ι → ℕ) (hj : ∀ i, j i < 6) (X : ℝ), 0 < X →
      ‖D.smoothedValue hN hr hbase s hp hc0 hg j W X‖ ≤
        C*(∏ i, localReflectionCost (Ideal.absNorm (Ideal.span {p i}):ℝ) (j i))*
          (X/(27*(sourceCuspScale s.index)^2*
            (Ideal.absNorm (Ideal.span {c0*∏i,p i}):ℝ)^2))^(-(1/2):ℝ) := by
  obtain ⟨C,hC,hb⟩ := reflectedValue_composite_uniform_bound W lo hi hlo hsupp hW
  refine ⟨C,hC,?_⟩
  intro ι _ p N a0 c0 mode D _ hN hr hbase s hp hc0 hcop hg hchar j hj X hX
  rw [D.smoothed_eq_reflected hN hr hbase s hp hc0 hcop hg hchar j hj
    W lo hi hlo hsupp hW X hX]
  exact hb ι p N a0 c0 mode D hN hr hbase s hp hc0 hcop hg hchar j hj X hX

#print axioms reflectedValue_composite_uniform_bound
#print axioms smoothedValue_composite_uniform_bound
end
end QRHExperimental.CompositeControlledReflection
