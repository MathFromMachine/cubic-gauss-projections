import OAI.NumberTheory.DirichletL.GaussSum.ResidualEquivalence
import OAI.NumberTheory.DirichletL.GaussSum.ActiveReindexing

/-! Exact finite active/inactive stratum bookkeeping. Exponent zero retains
its principal-character inactive term. For all nonzero exponents only the
fully active stratum remains. -/
namespace QRHExperimental.ActiveStratumSum
noncomputable section
open OAI OAI.ActualEisensteinCubic OAI.ConcreteTraceCRT
open OAI.CubicEisenstein OAI.CompletedGauss
open scoped BigOperators Classical
local notation "Eis" => OAI.ActualEisensteinCubic.O
variable {ι : Type*} [Fintype ι] (p : ι → Eis)
variable [∀ i, (Ideal.span {p i}).IsMaximal]
variable (hp : ∀ i, p i ≠ 0) (hg : ∀ i, lambda ∉ Ideal.span {p i})
variable (hchar : ∀ i, ringChar (Eis ⧸ Ideal.span {p i}) ≠ 2)
variable (j : ι → ℕ) (hj : ∀ i, j i < 6)
include hchar hj

lemma inactive_weight_formula (A : Finset ι) :
    primeInactiveFourierWeight p hp hg j A =
      ∏ i ∈ (Finset.univ : Finset ι) \ A,
        (if j i = 0 then 1-(Ideal.absNorm (Ideal.span {p i}):ℂ)⁻¹ else 0) := by
  unfold primeInactiveFourierWeight
  apply Finset.prod_congr rfl
  intro i hi
  exact prime_zeroFourier_norm_formula (p i) (hp i) (hg i) (hchar i) (j i) (hj i)

omit hchar hj in
lemma inactive_weight_univ :
    primeInactiveFourierWeight p hp hg j Finset.univ = 1 := by
  simp [primeInactiveFourierWeight]

theorem inactive_weight_zero_of_missing (A : Finset ι) (i : ι)
    (hi : i ∉ A) (hj0 : j i ≠ 0) :
    primeInactiveFourierWeight p hp hg j A = 0 := by
  rw [inactive_weight_formula p hp hg hchar j hj A]
  apply Finset.prod_eq_zero (Finset.mem_sdiff.mpr ⟨Finset.mem_univ i, hi⟩)
  exact if_neg hj0

theorem nonzero_exponents_collapse (hj0 : ∀ i, j i ≠ 0)
    (f : Finset ι → ℂ) :
    (∑ A : Finset ι, primeInactiveFourierWeight p hp hg j A * f A) =
      f Finset.univ := by
  rw [Finset.sum_eq_single Finset.univ]
  · rw [inactive_weight_univ, one_mul]
  · intro A hA hne
    have hex : ∃ i, i ∉ A := by
      by_contra! h
      exact hne (Finset.eq_univ_of_forall h)
    obtain ⟨i,hi⟩ := hex
    rw [inactive_weight_zero_of_missing p hp hg hchar j hj A i hi (hj0 i), zero_mul]
  · intro h
    exact (h (Finset.mem_univ _)).elim

theorem weighted_active_sum_product (a : ι → ℂ) :
    (∑ A : Finset ι, primeInactiveFourierWeight p hp hg j A * ∏ i ∈ A, a i) =
      ∏ i, (a i + if j i = 0 then 1-(Ideal.absNorm (Ideal.span {p i}):ℂ)⁻¹ else 0) := by
  simp_rw [inactive_weight_formula p hp hg hchar j hj]
  have h := Finset.prod_add a
    (fun i => if j i = 0 then 1-(Ideal.absNorm (Ideal.span {p i}):ℂ)⁻¹ else 0)
    (Finset.univ : Finset ι)
  have hpow : (Finset.univ : Finset ι).powerset = Finset.univ := by ext A; simp
  rw [hpow] at h
  rw [h]
  apply Finset.sum_congr rfl
  intro A hA
  exact mul_comm _ _

#print axioms inactive_weight_zero_of_missing
#print axioms nonzero_exponents_collapse
#print axioms weighted_active_sum_product
end
end QRHExperimental.ActiveStratumSum
