import MaskProjectionBound
import CompositeProjectionCosts
import OAI.NumberTheory.DirichletL.Arithmetic.SquarefreeDivisors

/-! Exact divisor expansion for squarefree ideal masks. -/
namespace QRHExperimental.MaskEulerProduct
noncomputable section
open OAI OAI.ActualEisensteinCubic OAI.CubicEisenstein
open OAI.ConcreteTraceCRT OAI.SevenEighths IdealMobiusDivisorSum
open QRHExperimental.CompositeProjectionCosts
open scoped BigOperators Classical
local notation "Eis" => OAI.ActualEisensteinCubic.O

theorem squarefree_divisor_euler_product (M : Ideal Eis) (hM : Squarefree M)
    (u : Ideal Eis → ℝ) :
    (∑ D : idealDivisors M, ∏ P ∈ primeSupport D.val, u P) =
      ∏ P ∈ primeSupport M, (1+u P) := by
  rw [Finset.sum_coe_sort (idealDivisors M) (fun D : Ideal Eis => ∏ P ∈ primeSupport D, u P)]
  have hf : (idealDivisors M).filter Squarefree = idealDivisors M := by
    apply Finset.filter_eq_self.mpr
    intro D hD
    intro x hx
    exact hM x (dvd_trans hx ((mem_idealDivisors hM.ne_zero).mp hD))
  rw [←hf,squarefree_divisors_eq_image M hM.ne_zero,Finset.sum_image]
  · have he : (∑ S ∈ (primeSupport M).powerset,
          ∏ P ∈ primeSupport (∏ R ∈ S, R), u P) =
        ∑ S ∈ (primeSupport M).powerset, ∏ P ∈ S, u P := by
      apply Finset.sum_congr rfl
      intro S hS
      have hs : primeSupport (∏ R ∈ S, R) = S := by
        rw [primeSupport,factors_support_product (Finset.mem_powerset.mp hS)]
        simp
      rw [hs]
    rw [he]
    have hp := Finset.prod_add u (fun _ : Ideal Eis => (1:ℝ)) (primeSupport M)
    simpa only [Finset.prod_const_one,mul_one,add_comm] using hp.symm
  · intro S hS T hT hST
    exact support_product_injective (Finset.mem_powerset.mp hS)
      (Finset.mem_powerset.mp hT) hST

def extractedPrimeCost (q : ℝ) : ℝ := Real.sqrt (2*q^(-(1/2):ℝ)+q^(-2:ℝ))

lemma extractedPrimeCost_eq (q : ℝ) (hq : 0 < q) :
    Real.sqrt (primeCost q 4)/Real.sqrt q = extractedPrimeCost q := by
  rw [←Real.sqrt_div (by
    simp only [primeCost,show (4:ℕ)≠0 by decide,ite_false,ite_true]
    positivity)]
  congr 1
  simp only [primeCost,show (4:ℕ)≠0 by decide,ite_false,ite_true]
  have hp := mul_neg_half q hq
  have h2 := mul_neg_two q hq
  apply (div_eq_iff hq.ne').mpr
  nlinarith

lemma sqrt_finset_prod {α : Type*} (S : Finset α) (f : α → ℝ)
    (hf : ∀ i ∈ S, 0 ≤ f i) :
    Real.sqrt (∏ i ∈ S, f i) = ∏ i ∈ S, Real.sqrt (f i) := by
  simp only [Real.sqrt_eq_rpow]
  exact (Real.finsetProd_rpow S f hf (1/2)).symm

lemma squarefree_norm_product (D : Ideal Eis) (hD : Squarefree D) :
    (Ideal.absNorm D : ℝ) = ∏ P ∈ primeSupport D, (Ideal.absNorm P : ℝ) := by
  conv_lhs => rw [←squarefree_support_product_self hD]
  simp only [map_prod,Nat.cast_prod]

lemma support_norm_pos (D P : Ideal Eis) (hP : P ∈ primeSupport D) :
    0 < (Ideal.absNorm P : ℝ) := by
  have hp := support_prime hP
  exact_mod_cast (Nat.pos_iff_ne_zero.mpr
    (fun hz => hp.ne_zero (Ideal.absNorm_eq_zero_iff.mp hz)))

lemma squarefree_extracted_cost (D : Ideal Eis) (hD : Squarefree D) :
    Real.sqrt (∏ P ∈ primeSupport D, primeCost (Ideal.absNorm P:ℝ) 4) /
        Real.sqrt (Ideal.absNorm D:ℝ) =
      ∏ P ∈ primeSupport D, extractedPrimeCost (Ideal.absNorm P:ℝ) := by
  rw [sqrt_finset_prod _ _ (by
    intro P hP
    simp only [primeCost,show (4:ℕ)≠0 by decide,ite_false,ite_true]
    positivity)]
  rw [squarefree_norm_product D hD,sqrt_finset_prod _ _ (by intros; positivity),
    ←Finset.prod_div_distrib]
  apply Finset.prod_congr rfl
  intro P hP
  exact extractedPrimeCost_eq _ (support_norm_pos D P hP)

theorem mask_divisor_cost_product (M : Ideal Eis) (hM : Squarefree M) :
    (∑ D : idealDivisors M,
      Real.sqrt (∏ P ∈ primeSupport D.val, primeCost (Ideal.absNorm P:ℝ) 4) /
        Real.sqrt (Ideal.absNorm D.val:ℝ)) =
      ∏ P ∈ primeSupport M, (1+extractedPrimeCost (Ideal.absNorm P:ℝ)) := by
  calc
    _ = ∑ D : idealDivisors M,
        ∏ P ∈ primeSupport D.val, extractedPrimeCost (Ideal.absNorm P:ℝ) := by
      apply Finset.sum_congr rfl
      intro D hD
      apply squarefree_extracted_cost D.val
      intro x hx
      exact hM x (dvd_trans hx ((mem_idealDivisors hM.ne_zero).mp D.property))
    _ = _ := squarefree_divisor_euler_product M hM _

lemma extractedPrimeCost_le_three (q : ℝ) (hq : 1 ≤ q) :
    extractedPrimeCost q ≤ 3 := by
  have h1 := Real.rpow_le_one_of_one_le_of_nonpos hq (show (-(1/2):ℝ) ≤ 0 by norm_num)
  have h2 := Real.rpow_le_one_of_one_le_of_nonpos hq (show (-2:ℝ) ≤ 0 by norm_num)
  apply Real.sqrt_le_iff.mpr
  exact ⟨by norm_num,by nlinarith⟩

theorem mask_prime_product_subpower (ε : ℝ) (hε : 0 < ε) :
    ∃ C : ℝ, 0 < C ∧ ∀ M : Ideal Eis, M ≠ ⊥ →
      (∏ P ∈ primeSupport M, (1+extractedPrimeCost (Ideal.absNorm P:ℝ))) ≤
        C*(Ideal.absNorm M:ℝ)^ε := by
  obtain ⟨C,hC,h⟩ := OAI.SquarefreeDivisorBound.prime_support_subsets_bound
    (ε/2) (by positivity)
  refine ⟨C^2,by positivity,?_⟩
  intro M hM
  have hp : (∏ P ∈ primeSupport M, (1+extractedPrimeCost (Ideal.absNorm P:ℝ))) ≤
      (4:ℝ)^(primeSupport M).card := by
    calc
      _ ≤ ∏ P ∈ primeSupport M, (4:ℝ) := by
        apply Finset.prod_le_prod₀
        · intro P hP
          exact add_nonneg (by norm_num) (Real.sqrt_nonneg _)
        · intro P hP
          have hNP : 1 ≤ (Ideal.absNorm P:ℝ) := by
            exact_mod_cast (Nat.succ_le_of_lt (by
              exact_mod_cast support_norm_pos M P hP : 0 < Ideal.absNorm P))
          linarith [extractedPrimeCost_le_three _ hNP]
      _ = _ := by simp
  have hn : 0 ≤ (Ideal.absNorm M:ℝ) := by positivity
  calc
    _ ≤ (4:ℝ)^(primeSupport M).card := hp
    _ = ((2:ℝ)^(primeSupport M).card)^2 := by rw [←pow_mul, mul_comm, pow_mul]; norm_num
    _ ≤ (C*(Ideal.absNorm M:ℝ)^(ε/2))^2 := by
      exact pow_le_pow_left₀ (by positivity) (h M hM) 2
    _ = C^2*(Ideal.absNorm M:ℝ)^ε := by
      have he : ((Ideal.absNorm M:ℝ)^(ε/2))^2 = (Ideal.absNorm M:ℝ)^ε := by
        rw [←Real.rpow_natCast,←Real.rpow_mul hn]
        congr 1
        norm_num
      rw [mul_pow,he]

#print axioms squarefree_divisor_euler_product
#print axioms extractedPrimeCost_eq
#print axioms mask_divisor_cost_product
#print axioms mask_prime_product_subpower
end
end QRHExperimental.MaskEulerProduct
