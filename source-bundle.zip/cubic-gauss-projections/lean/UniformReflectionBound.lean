import SparseRadialSummability
import CuspHeight
import FiniteFourierMass

/-! Uniform bounds for the actual smoothed reflected cusp kernel.
The profile remains fixed, while the cusp datum and its height may vary. -/
namespace QRHExperimental.UniformReflectionBound
noncomputable section
set_option maxHeartbeats 2000000
open OAI OAI.ActualEisensteinCubic OAI.ConcreteTraceCRT
open OAI.CubicEisenstein OAI.CompletedGauss
open QRHExperimental.SparseRadialSummability
open scoped BigOperators Classical ContDiff
local notation "Eis" => OAI.ActualEisensteinCubic.O

lemma kernel_argument_power (B H X r s : ℝ)
    (hB : 0 < B) (hH : 0 < H) (hX : 0 < X) (hr : 0 < r) :
    (X*r/(B*H^2))^(-s) = B^s * H^(2*s) * X^(-s) * r^(-s) := by
  rw [Real.div_rpow (by positivity) (by positivity),
    Real.rpow_neg (by positivity : 0 ≤ B*H^2), div_inv_eq_mul,
    Real.mul_rpow hX.le hr.le, Real.mul_rpow hB.le (sq_nonneg H),
    ← Real.rpow_natCast_mul hH.le]
  norm_num only [Nat.cast_ofNat]
  ring

theorem smoothedKernel_uniform_height_bound
    (W : ℝ → ℂ) (v0 v1 : ℝ) (hv0 : 0 < v0)
    (hWs : Function.support W ⊆ Set.Icc v0 v1) (hW : ContDiff ℝ ∞ W)
    (s : ℝ) (hs : 1/2 < s) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (d : SourceCuspDatum) (X : ℝ), 0 < X →
      ‖d.smoothedKernel W X‖ ≤ C * d.heightScale^(2*s) * X^(-s) := by
  obtain ⟨A, hA⟩ := exists_nat_ge s
  obtain ⟨K, hK, hk⟩ := CubicReflectionKernel.paperKernel_euler_decay_at_line
    (Vstar W) v0 v1 hv0 (Vstar_support W v0 v1 hWs)
    (Vstar_contDiff W v0 v1 hv0 hWs hW) A 0 s ⟨by linarith, hA⟩
  have hk' : ∀ x : ℝ, 0 < x →
      ‖CubicReflectionKernel.paperKernel (Vstar W) x‖ ≤ K*x^(-s) := by
    intro x hx
    simpa only [LocalLogFourier.eulerDeriv, iteratedDeriv_zero,
      Real.exp_zero, mul_one] using hk x hx
  obtain ⟨M, hM, hm⟩ := sourceCuspRadialCoefficient_weighted_mass_uniform s hs
  let b : Fin 3 → ℝ := fun j => (27*(sourceCuspScale j)^2)^s
  have hb : ∀ j, 0 ≤ b j := fun j => Real.rpow_nonneg (by positivity) _
  let B : ℝ := ∑ j : Fin 3, b j
  have hB : 0 ≤ B := Finset.sum_nonneg (fun j _ => hb j)
  have hbB : ∀ j, b j ≤ B := fun j =>
    Finset.single_le_sum (fun i _ => hb i) (Finset.mem_univ j)
  refine ⟨9*K*B*M, by positivity, ?_⟩
  intro d X hX
  let a : Eis → ℂ := sourceCuspRadialCoefficient d.index d.dualPoint
  let r : Eis → ℝ := sourceCuspRadialLength
  let D : ℝ := K * b d.index * d.heightScale^(2*s) * X^(-s)
  have hD : 0 ≤ D := mul_nonneg
    (mul_nonneg (mul_nonneg hK.le (hb d.index))
      (Real.rpow_nonneg d.heightScale_pos.le _)) (Real.rpow_nonneg hX.le _)
  have hg : Summable (fun n : Eis => ‖a n‖ * (r n)^(-s)) := (hm d.index d.dualPoint).1
  have hmass : (∑' n : Eis, ‖a n‖ * (r n)^(-s)) ≤ M := (hm d.index d.dualPoint).2
  let term : Eis → ℂ := fun n => a n * CubicReflectionKernel.paperKernel (Vstar W)
    (X*r n/(27*(sourceCuspScale d.index)^2*d.heightScale^2))
  have hterm : ∀ n, ‖term n‖ ≤ D * (‖a n‖ * (r n)^(-s)) := by
    intro n
    have hr : 0 < r n := sourceCuspRadialLength_pos n
    have hscale : 0 < 27*(sourceCuspScale d.index)^2 := by
      have := sourceCuspScale_pos d.index
      positivity
    dsimp only [term]
    rw [norm_mul]
    calc
      _ ≤ ‖a n‖ * (K * (X*r n/(27*(sourceCuspScale d.index)^2*
          d.heightScale^2))^(-s)) :=
        mul_le_mul_of_nonneg_left (hk' _
          (div_pos (mul_pos hX hr) (mul_pos hscale (sq_pos_of_pos d.heightScale_pos))))
          (norm_nonneg _)
      _ = _ := by
        rw [kernel_argument_power _ _ _ _ _ hscale d.heightScale_pos hX hr]
        dsimp only [D, b]
        ring
  have ht : Summable (fun n => ‖term n‖) :=
    (hg.mul_left D).of_nonneg_of_le (fun _ => norm_nonneg _) hterm
  have hseries : ‖∑' n, term n‖ ≤ D*M := by
    calc
      _ ≤ ∑' n, ‖term n‖ := norm_tsum_le_tsum_norm ht
      _ ≤ ∑' n, D*(‖a n‖*(r n)^(-s)) := ht.tsum_le_tsum hterm (hg.mul_left D)
      _ = D * ∑' n, ‖a n‖*(r n)^(-s) := tsum_mul_left
      _ ≤ D*M := mul_le_mul_of_nonneg_left hmass hD
  rw [d.smoothedKernel_eq, norm_mul]
  calc
    _ ≤ 9 * (D*M) := mul_le_mul d.smoothedKernel_prefactor_norm_le hseries
      (norm_nonneg _) (by norm_num)
    _ ≤ 9 * (K * B * d.heightScale^(2*s) * X^(-s) * M) := by
      exact mul_le_mul_of_nonneg_left
        (mul_le_mul_of_nonneg_right
          (mul_le_mul_of_nonneg_right
            (mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left (hbB d.index) hK.le)
              (Real.rpow_nonneg d.heightScale_pos.le _))
            (Real.rpow_nonneg hX.le _)) hM) (by norm_num)
    _ = _ := by ring

#print axioms smoothedKernel_uniform_height_bound
end
end QRHExperimental.UniformReflectionBound
