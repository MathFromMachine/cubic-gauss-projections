import MaskSourceAdapter
import MaskEulerProduct

/-! The actual mixed-prime projection with inexpensive disjoint coprimality masks.
One projection constant is used before the full divisor expansion. -/
namespace QRHExperimental.MaskedCompositeProjection
noncomputable section
open OAI OAI.ActualEisensteinCubic OAI.ConcreteTraceCRT
open OAI.CubicEisenstein OAI.CompletedGauss OAI.CanonicalRowCompletion
open OAI.CanonicalQuadraticSieve OAI.SevenEighths
open QRHExperimental.TrivialProjection QRHExperimental.CompositeProjection
open QRHExperimental.CompositeProjectionCosts QRHExperimental.MaskExtraction
open QRHExperimental.MaskSourceAdapter QRHExperimental.MaskEulerProduct
open QRHExperimental.MaskProjectionBound
open scoped BigOperators Classical ContDiff
set_option maxHeartbeats 1500000
local notation "Eis" => OAI.ActualEisensteinCubic.O
local notation "support" => OAI.IdealMobiusDivisorSum.primeSupport
open OAI.IdealMobiusDivisorSum

lemma supported_divisor {M D : Ideal Eis} (hM : Supported M) (hd : D ∣ M) :
    Supported D := by
  obtain ⟨J,rfl⟩ := hd
  exact ((supported_mul_iff D J).mp hM).1

/-- Exact local product, with the constant chosen before every ideal and character. -/
theorem rawProjection_masked_composite
    (W : ℝ → ℂ) (lo hi : ℝ) (hlo : 0 < lo)
    (hsupp : Function.support W ⊆ Set.Icc lo hi) (hW : ContDiff ℝ ∞ W) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (I M Q : Ideal Eis) (hI : Supported I)
      (hM : Supported M) (hMa : CubicSieve.Admissible M),
      Q ≠ 0 → IsCoprime I M → IsCoprime Q M →
      ∀ (φ : Eis →* ℂ), CanonicalCoefficientClass.FactorsModulo Q φ →
      (∀ n, ‖φ n‖ ≤ 1) → ∀ L : ℝ, 0 < L →
      ‖rawProjection ((φ*freePrimeRow I hI Q)*coprimeMask M hMa) W L‖ ≤
        C*Real.sqrt L*(Ideal.absNorm Q:ℝ)^(3/4:ℝ)*(sourceCost I Q)^(1/2:ℝ)*
          ∏ P ∈ support M, (1+extractedPrimeCost (Ideal.absNorm P:ℝ)) := by
  obtain ⟨C,hC,hb⟩ := rawProjection_composite W lo hi hlo hsupp hW
  refine ⟨C,hC,?_⟩
  intro I M Q hI hM hMa hQ hIM hQM φ hφ hφn L hL
  let Ψ := φ*freePrimeRow I hI Q
  let K := C*(Ideal.absNorm Q:ℝ)^(3/4:ℝ)*Real.sqrt (sourceCost I Q)
  let a : idealDivisors M → ℝ := fun D =>
    Real.sqrt (∏ P ∈ support D.val, primeCost (Ideal.absNorm P:ℝ) 4)
  have hbound (D : idealDivisors M) :
      ‖rawProjection (Ψ*fourthTwist D.val (divisor_admissible M hMa D)) W
          (L/(Ideal.absNorm D.val:ℝ))‖ ≤
        K*Real.sqrt (L/(Ideal.absNorm D.val:ℝ))*a D := by
    have hd : D.val ∣ M := (mem_idealDivisors hM.1).mp D.property
    have hD := supported_divisor hM hd
    have hDa := divisor_admissible M hMa D
    have hID := hIM.of_isCoprime_of_dvd_right hd
    have hQD := hQM.of_isCoprime_of_dvd_right hd
    have hnorm : 0 < (Ideal.absNorm D.val:ℝ) := by
      exact_mod_cast (Nat.pos_iff_ne_zero.mpr
        (fun hz => hD.1 (Ideal.absNorm_eq_zero_iff.mp hz)))
    have hrow : Ψ*fourthTwist D.val hDa =
        φ*freePrimeRow (I*D.val^4)
          ((supported_mul_iff _ _).mpr ⟨hI,supported_pow hD 4⟩) Q := by
      rw [freePrimeRow_mul_fourth I D.val Q hI hD hDa hQD]
      exact mul_assoc _ _ _
    rw [hrow]
    have he := hb (I*D.val^4) Q
      ((supported_mul_iff _ _).mpr ⟨hI,supported_pow hD 4⟩)
      hQ φ hφ hφn (L/(Ideal.absNorm D.val:ℝ)) (div_pos hL hnorm)
    have hc : sourceCost (I*D.val^4) Q = sourceCost I Q *
        ∏ P ∈ support D.val, primeCost (Ideal.absNorm P:ℝ) 4 := by
      simpa only [OAI.IdealMobiusDivisorSum.primeSupport,primeCost,
        show (4:ℕ)≠0 by decide,ite_false,ite_true] using
        sourceCost_mul_fourth I D.val Q hI hD hDa.1 hID hQD
    rw [hc,←Real.sqrt_eq_rpow,Real.sqrt_mul (sourceCost_pos I Q hI).le] at he
    exact he.trans_eq (by dsimp [K,a]; ring)
  have h := masked_projection_common_bound Ψ (fixedFreeRow_norm I hI Q φ hφn)
    M hMa W hi L K hL (fun x hx => (hsupp hx).2) a hbound
  change ‖rawProjection (Ψ*coprimeMask M hMa) W L‖ ≤ _
  have he : (∑ D : idealDivisors M, a D/Real.sqrt (Ideal.absNorm D.val:ℝ)) =
      ∏ P ∈ support M, (1+extractedPrimeCost (Ideal.absNorm P:ℝ)) :=
    mask_divisor_cost_product M hMa.1
  rw [he] at h
  exact h.trans_eq (by dsimp [K]; rw [Real.sqrt_eq_rpow]; ring)

/-- Each separate mask costs an arbitrarily small norm power, uniformly in all ideals. -/
theorem rawProjection_masked_composite_subpower
    (W : ℝ → ℂ) (lo hi : ℝ) (hlo : 0 < lo)
    (hsupp : Function.support W ⊆ Set.Icc lo hi) (hW : ContDiff ℝ ∞ W)
    (ε : ℝ) (hε : 0 < ε) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (I M Q : Ideal Eis) (hI : Supported I)
      (hM : Supported M) (hMa : CubicSieve.Admissible M),
      Q ≠ 0 → IsCoprime I M → IsCoprime Q M →
      ∀ (φ : Eis →* ℂ), CanonicalCoefficientClass.FactorsModulo Q φ →
      (∀ n, ‖φ n‖ ≤ 1) → ∀ L : ℝ, 0 < L →
      ‖rawProjection ((φ*freePrimeRow I hI Q)*coprimeMask M hMa) W L‖ ≤
        C*Real.sqrt L*(Ideal.absNorm Q:ℝ)^(3/4:ℝ)*(sourceCost I Q)^(1/2:ℝ)*
          (Ideal.absNorm M:ℝ)^ε := by
  obtain ⟨C,hC,hb⟩ := rawProjection_masked_composite W lo hi hlo hsupp hW
  obtain ⟨D,hD,hd⟩ := mask_prime_product_subpower ε hε
  refine ⟨C*D,by positivity,?_⟩
  intro I M Q hI hM hMa hQ hIM hQM φ hφ hφn L hL
  apply (hb I M Q hI hM hMa hQ hIM hQM φ hφ hφn L hL).trans
  calc
    _ ≤ C*Real.sqrt L*(Ideal.absNorm Q:ℝ)^(3/4:ℝ)*(sourceCost I Q)^(1/2:ℝ)*
        (D*(Ideal.absNorm M:ℝ)^ε) := by
      apply mul_le_mul_of_nonneg_left (hd M hM.1)
      exact mul_nonneg (by positivity) (Real.rpow_nonneg (sourceCost_pos I Q hI).le _)
    _ = _ := by ring

#print axioms rawProjection_masked_composite
#print axioms rawProjection_masked_composite_subpower
end
end QRHExperimental.MaskedCompositeProjection
