import TrivialCompleted

namespace QRHExperimental.UniformTrivial
noncomputable section
open OAI OAI.ActualEisensteinCubic OAI.CompletedGauss OAI.CubicEisenstein
open QRHExperimental.TrivialProjection QRHExperimental.TrivialCompleted
open scoped BigOperators Classical ContDiff
local notation "Eis" => OAI.ActualEisensteinCubic.O

theorem uniform_trivial_bounds (W : ℝ → ℂ) (a b : ℝ)
    (hWs : Function.support W ⊆ Set.Icc a b) (hW : Continuous W) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (Ψ : Eis →* ℂ), (∀ z, ‖Ψ z‖ ≤ 1) →
      ∀ X : ℝ, 0 < X →
        ‖rawProjection Ψ W X‖ ≤ C*X ∧
        ‖completedT Ψ W X‖ ≤ C*Real.sqrt X := by
  have hc : HasCompactSupport W :=
    HasCompactSupport.of_support_subset_isCompact isCompact_Icc hWs
  obtain ⟨B, hB⟩ := hc.exists_bound_of_continuous hW
  have hB0 : 0 ≤ B := (norm_nonneg (W 0)).trans (hB 0)
  let b0 : ℝ := max b 0
  have hb0 : 0 ≤ b0 := le_max_right _ _
  have hw : ∀ x, W x ≠ 0 → x ≤ b0 :=
    fun x hx => (hWs hx).2.trans (le_max_left _ _)
  let K : ℝ := 128*b0*B
  let S : ℝ := ∑' J : NonzeroIdeal, (Ideal.absNorm J.val:ℝ)^(-(5/2):ℝ)
  have hK : 0 ≤ K := by dsimp [K]; positivity
  have hS : 0 ≤ S := tsum_nonneg (fun _ => Real.rpow_nonneg (Nat.cast_nonneg _) _)
  refine ⟨K+K*S, by positivity, ?_⟩
  intro Ψ hΨ X hX
  constructor
  · exact (rawProjection_norm_le Ψ hΨ W b0 B X hb0 hB0 hX hw hB).trans
      (mul_le_mul_of_nonneg_right (by dsimp [K]; nlinarith) hX.le)
  · exact (completedT_trivial_bound Ψ hΨ W hc b0 B X hb0 hB0 hX hw hB).trans
      (mul_le_mul_of_nonneg_right (by dsimp only [K, S]; linarith [hK]) (Real.sqrt_nonneg X))

#print axioms uniform_trivial_bounds
end
end QRHExperimental.UniformTrivial
