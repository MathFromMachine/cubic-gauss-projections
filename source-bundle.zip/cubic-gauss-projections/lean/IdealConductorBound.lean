import CompletedReflectionBound

namespace QRHExperimental.IdealConductorBound
noncomputable section
set_option maxHeartbeats 2000000
open OAI OAI.ActualEisensteinCubic OAI.ConcreteTraceCRT
open OAI.CubicEisenstein OAI.CompletedGauss
open scoped BigOperators Classical ContDiff
local notation "Eis" => OAI.ActualEisensteinCubic.O

lemma nine_principal_norm : (Ideal.absNorm (Ideal.span {(9:Eis)}):ℝ) = 81 := by
  rw [← eisEmbedding_norm_sq_eq_absNorm_span, map_ofNat]
  norm_num

lemma period_generator (Q : Ideal Eis) (hQ : Q ≠ 0) :
    ∃ c : Eis, c ≠ 0 ∧ Ideal.span {c} = Ideal.span {(9:Eis)}*Q ∧
      (Ideal.absNorm (Ideal.span {c}):ℝ) = 81*(Ideal.absNorm Q:ℝ) := by
  let q : Eis := Submodule.IsPrincipal.generator Q
  have hspan : Ideal.span {q} = Q := Ideal.span_singleton_generator Q
  have hq : q ≠ 0 := by
    intro hz
    apply hQ
    rw [← hspan, hz, Ideal.span_singleton_zero]
    rfl
  refine ⟨9*q, mul_ne_zero (by norm_num) hq, ?_, ?_⟩
  · rw [← Ideal.span_singleton_mul_span_singleton, hspan]
  · rw [← Ideal.span_singleton_mul_span_singleton, hspan, map_mul, Nat.cast_mul,
      nine_principal_norm]

theorem completedT_uniform_period_bound
    (W : ℝ → ℂ) (v0 v1 : ℝ) (hv0 : 0 < v0)
    (hWs : Function.support W ⊆ Set.Icc v0 v1) (hW : ContDiff ℝ ∞ W)
    (s : ℝ) (hs : 1/2 < s) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (Ψ : Eis →* ℂ), (∀ x, ‖Ψ x‖ ≤ 1) →
      ∀ (Q : Ideal Eis), Q ≠ 0 → CanonicalCoefficientClass.FactorsModulo Q Ψ →
      ∀ (X : ℝ), 0 < X →
      ‖completedT Ψ W X‖ ≤ C * (Ideal.absNorm Q:ℝ)^(2*s+1/2) * X^(-s) := by
  obtain ⟨K, hK, hk⟩ := QRHExperimental.CompletedReflectionBound.completedT_uniform_reflected_bound
    W v0 v1 hv0 hWs hW s hs
  refine ⟨K * (81:ℝ)^(2*s+1/2), by positivity, ?_⟩
  intro Ψ hΨ Q hQ hperiod X hX
  obtain ⟨c, hc, heq, hnorm⟩ := period_generator Q hQ
  have hb := hk Ψ hΨ Q hperiod c hc heq.le X hX
  rw [hnorm, Real.mul_rpow (by norm_num) (Nat.cast_nonneg _)] at hb
  exact hb.trans_eq (by ring)

#print axioms period_generator
#print axioms completedT_uniform_period_bound
end
end QRHExperimental.IdealConductorBound
