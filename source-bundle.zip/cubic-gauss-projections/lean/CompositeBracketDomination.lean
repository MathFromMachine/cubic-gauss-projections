import CompositeModelKernel
import FourthBracketDomination

/-! Actual finite-family sextic bracket domination. A common sparse-series
constant is retained by expanding simultaneous ideal-divisor branches. -/
namespace QRHExperimental.CompositeBracketDomination
noncomputable section
open OAI OAI.ActualEisensteinCubic OAI.ConcreteTraceCRT
open OAI.CubicEisenstein OAI.CompletedGauss OAI.CompletedDyadic
open OAI.CubicEisenstein.ControlledStratumArithmetic OAI.LocalReflectionBrackets
open QRHExperimental.IdealPowerSums QRHExperimental.SparseRadialSummability
open QRHExperimental.ModelKernelMass QRHExperimental.FourthModelKernel
open QRHExperimental.ControlledReflectionBound QRHExperimental.ControlledBracketNorms
open QRHExperimental.FourthBracketDomination QRHExperimental.PhaseNumeratorSupport
open QRHExperimental.CompositeModelKernel
open scoped BigOperators Classical ContDiff
local notation "Eis" => OAI.ActualEisensteinCubic.O
set_option maxHeartbeats 2000000

noncomputable local instance quotientField (P : Ideal Eis) [P.IsMaximal] :
    Field (Eis ⧸ P) := Ideal.Quotient.field P
noncomputable local instance quotientFintype (P : Ideal Eis) [P.IsMaximal] :
    Fintype (Eis ⧸ P) := Fintype.ofFinite _

def localReflectionCost (q : ℝ) (j : ℕ) : ℝ :=
  if j = 0 then q^(-(1/2):ℝ) else
    if j = 4 then 2*q^(-(1/2):ℝ)+q^(-2:ℝ) else 1

lemma localReflectionCost_pos (q : ℝ) (hq : 0 < q) (j : ℕ) :
    0 < localReflectionCost q j := by
  unfold localReflectionCost
  split_ifs <;> positivity

lemma localReflectionCost_nonneg (q : ℝ) (hq : 0 < q) (j : ℕ) :
    0 ≤ localReflectionCost q j := (localReflectionCost_pos q hq j).le

def bracketWeights (P : NonzeroIdeal) (j : ℕ) (k : Fin 3) : ℝ :=
  if j = 0 then (if k = 0 then (idealNorm P)^(-(1/2):ℝ) else 0) else
    if j = 4 then (if k = 0 then (idealNorm P)^(-(1/2):ℝ) else (idealNorm P)^(1/2:ℝ))
    else if k = 0 then 1 else 0

lemma bracketWeights_nonneg (P : NonzeroIdeal) (j : ℕ) (k : Fin 3) :
    0 ≤ bracketWeights P j k := by
  have hq := nonzeroIdeal_norm_pos P
  unfold bracketWeights
  split_ifs <;> positivity

lemma bracketWeights_localTotal (P : NonzeroIdeal) (j : ℕ) :
    localTotal P (bracketWeights P j) = localReflectionCost (idealNorm P) j := by
  have hq := nonzeroIdeal_norm_pos P
  by_cases h0 : j = 0
  · simp [localTotal,bracketWeights,localReflectionCost,h0]
  by_cases h4 : j = 4
  · simp only [localTotal,bracketWeights,localReflectionCost,if_neg h0,if_pos h4]
    norm_num only
    exact fourthCost_eq (idealNorm P) hq
  · simp [localTotal,bracketWeights,localReflectionCost,h0,h4]

lemma bracketBranches_nonneg (P : NonzeroIdeal) (j : ℕ) (t : ThetaFullIndex) :
    0 ≤ ∑ k, localBranch P (bracketWeights P j) k t := by
  apply Finset.sum_nonneg
  intro k hk
  unfold localBranch
  split_ifs
  · exact bracketWeights_nonneg P j k
  · exact le_rfl

variable {ι : Type*} [Fintype ι] {p : ι → Eis}
variable {N a0 c0 : Eis} {mode : Bool}
variable [∀ i, (Ideal.span {p i}).IsMaximal]

def primeIdeal (hp : ∀ i, p i ≠ 0) (i : ι) : NonzeroIdeal :=
  ⟨Ideal.span {p i}, Ideal.span_singleton_eq_bot.not.mpr (hp i)⟩

lemma prime_rootCard (hp : ∀ i, p i ≠ 0) (i : ι) :
    rootCard (Eis ⧸ Ideal.span {p i}) = (idealNorm (primeIdeal hp i))^(1/2:ℝ) := by
  have hcard : (Fintype.card (Eis ⧸ Ideal.span {p i}):ℝ) = idealNorm (primeIdeal hp i) := by
    congr 1
    rw [← Nat.card_eq_fintype_card, ← Submodule.cardQuot_apply, ← Ideal.absNorm_apply]
    rfl
  rw [rootCard,hcard,Real.sqrt_eq_rpow]

lemma actual_bracket_le_branches
    (s : FixedCuspShape (fixedCusp a0 c0 mode))
    (hp : ∀ i, p i ≠ 0) (hg : ∀ i, lambda ∉ Ideal.span {p i})
    (i : ι) (j : ℕ) (t : ThetaFullIndex)
    (ha : s.amplitude t.1 t.2.1 t.2.2.1.val t.2.2.2.val ≠ 0) :
    ‖bracket (actualSextic (Ideal.span {p i}) (hg i)) j
      (Ideal.Quotient.mk (Ideal.span {p i})
        (sourceCuspPhaseNumerator s.index (s.upper 0 0) (thetaFullFrequency t)))‖ ≤
      ∑ k, localBranch (primeIdeal hp i) (bracketWeights (primeIdeal hp i) j) k t := by
  let P := primeIdeal hp i
  have hq := nonzeroIdeal_norm_pos P
  let x := sourceCuspPhaseNumerator s.index (s.upper 0 0) (thetaFullFrequency t)
  have hm : x ∈ Ideal.span {p i} ↔ P.val ∣ t.2.2.1.val ∨ P.val ∣ t.2.2.2.val := by
    rcases s.upper_unit with ⟨u,hu⟩
    simpa only [x, ← hu,P,primeIdeal] using
      phaseNumerator_fullFrequency_mem_iff (Ideal.span {p i}) (hg i) s.index u t
        (amplitude_ne_zero_source s t ha)
  change ‖bracket (actualSextic (Ideal.span {p i}) (hg i)) j
      (Ideal.Quotient.mk (Ideal.span {p i}) x)‖ ≤
      ∑ k, localBranch P (bracketWeights P j) k t
  rw [localBranch_sum]
  by_cases h0 : j = 0
  · subst j
    simp only [bracketWeights,ite_true,show (1:Fin 3) ≠ 0 by decide,
      show (2:Fin 3) ≠ 0 by decide,ite_false,ite_self,add_zero]
    have hh := norm_bracket_zero_le (actualSextic (Ideal.span {p i}) (hg i))
      (Ideal.Quotient.mk (Ideal.span {p i}) x)
    rw [prime_rootCard hp i, ← Real.rpow_neg hq.le] at hh
    exact hh
  by_cases h4 : j = 4
  · subst j
    simp only [bracketWeights,show (4:ℕ) ≠ 0 by decide,ite_false,ite_true,
      show (1:Fin 3) ≠ 0 by decide,show (2:Fin 3) ≠ 0 by decide]
    have hh := norm_fourth_bracket_le (actualSextic (Ideal.span {p i}) (hg i))
      (Ideal.Quotient.mk (Ideal.span {p i}) x)
    rw [prime_rootCard hp i, ← Real.rpow_neg hq.le] at hh
    simp only [Ideal.Quotient.eq_zero_iff_mem,hm] at hh
    apply hh.trans
    change (idealNorm P)^(-(1/2):ℝ)+(idealNorm P)^(1/2:ℝ)*
      (if P.val ∣ t.2.2.1.val ∨ P.val ∣ t.2.2.2.val then 1 else 0) ≤ _
    by_cases hI : P.val ∣ t.2.2.1.val <;> by_cases hJ : P.val ∣ t.2.2.2.val <;>
      simp only [hI,hJ,or_true,true_or,false_or,or_false,ite_true,ite_false,mul_zero,mul_one] <;>
      nlinarith [Real.rpow_nonneg hq.le (1/2:ℝ)]
  · simpa [bracketWeights,h0,h4] using
      norm_bracket_nonexceptional_le_one (actualSextic (Ideal.span {p i}) (hg i)) j h4 h0
        (Ideal.Quotient.mk (Ideal.span {p i}) x)

theorem reflectedCoefficient_composite_norm_le
    (D : ControlledStratumArithmetic p N a0 c0 mode)
    (s : FixedCuspShape (fixedCusp a0 c0 mode))
    (hp : ∀ i, p i ≠ 0) (hc0 : c0 ≠ 0)
    (hg : ∀ i, lambda ∉ Ideal.span {p i})
    (hchar : ∀ i, ringChar (Eis ⧸ Ideal.span {p i}) ≠ 2)
    (hN : (9:Eis)*c0 ∣ N) (hr : lambda^2 ∣ (∏i,p i)-1)
    (hbase : if mode then lambda^2 ∣ a0-1 else lambda^2 ∣ c0-1)
    (j : ι → ℕ) (hj : ∀ i, j i < 6) (t : ThetaFullIndex) :
    ‖reflectedCoefficient D s hp hc0 hg j t‖ ≤
      sparseWeight 0 t * ∏ i, ∑ k,
        localBranch (primeIdeal hp i) (bracketWeights (primeIdeal hp i) (j i)) k t := by
  have hbranches : 0 ≤ ∏ i, ∑ k,
      localBranch (primeIdeal hp i) (bracketWeights (primeIdeal hp i) (j i)) k t :=
    Finset.prod_nonneg (fun i _ => bracketBranches_nonneg _ _ _)
  by_cases ha : s.amplitude t.1 t.2.1 t.2.2.1.val t.2.2.2.val = 0
  · simp only [reflectedCoefficient,ha,zero_div,zero_mul,norm_zero]
    exact mul_nonneg (by unfold sparseWeight; positivity) hbranches
  let x := sourceCuspPhaseNumerator s.index (s.upper 0 0) (thetaFullFrequency t)
  have hb : ‖(star D.fixedFactor*
      ShortDraftCusp.A4BadPhase c0 hc0 (D.matrix (fun _=>1) 1 1) D.U x)*
        D.bracketProduct hp hg j x‖ ≤ ∏ i, ∑ k,
          localBranch (primeIdeal hp i) (bracketWeights (primeIdeal hp i) (j i)) k t := by
    rw [staticMultiplier_norm_eq D hN hr hbase hc0 hp hg,
      bracketProduct_norm D hp hg hchar j hj x]
    apply Finset.prod_le_prod₀ (fun _ _ => norm_nonneg _)
    intro i hi
    exact actual_bracket_le_branches s hp hg i (j i) t ha
  have hd := thetaFullIndex_denominator_pos t
  rw [reflectedCoefficient,norm_mul,norm_div,Complex.norm_real,Real.norm_of_nonneg hd.le]
  calc
    _ ≤ (1/(ramifiedScale 1 completedRamifiedStep t.2.1*
        Real.sqrt (Ideal.absNorm t.2.2.1.val:ℝ)*(Ideal.absNorm t.2.2.2.val:ℝ)))*
          (∏ i, ∑ k, localBranch (primeIdeal hp i)
            (bracketWeights (primeIdeal hp i) (j i)) k t) :=
      mul_le_mul (div_le_div_of_nonneg_right
        (s.amplitude_norm t.1 t.2.1 t.2.2.1.val t.2.2.2.val) hd.le)
        hb (norm_nonneg _) (by positivity)
    _ = _ := by rw [inverse_denominator]

#print axioms localReflectionCost_pos
#print axioms bracketWeights_localTotal
#print axioms reflectedCoefficient_composite_norm_le
end
end QRHExperimental.CompositeBracketDomination
