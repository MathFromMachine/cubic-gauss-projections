import OAI.NumberTheory.DirichletL.Eisenstein.FixedCuspArrays
import OAI.NumberTheory.DirichletL.Eisenstein.SourceMellinInversion

/-! The actual three cusp radial coefficients are summable against r^(-s)
for every s > 1/2.  This uses the existing squarefree/cube support and
coefficient formula, rather than a new analytic assumption. -/
namespace QRHExperimental.SparseRadialSummability
noncomputable section
set_option maxHeartbeats 2000000
open OAI OAI.ActualEisensteinCubic OAI.ConcreteTraceCRT
open OAI.CubicEisenstein OAI.CompletedGauss
open scoped BigOperators Classical
local notation "Eis" => OAI.ActualEisensteinCubic.O

lemma full_radial_length (p : ThetaFullIndex) :
    sourceCuspRadialLength (thetaFullFrequency p) =
      (3:ℝ)^p.2.1 * (Ideal.absNorm p.2.2.1.val:ℝ) *
        (Ideal.absNorm p.2.2.2.val:ℝ)^3 := by
  rw [sourceCuspRadialLength, ite_eq_right (thetaFullFrequency_ne_zero p),
    eisEmbedding_norm_sq_eq_absNorm_span, thetaFullFrequency_span]
  simp only [map_mul, map_pow, thetaPrimaryProduct, ramifiedIdeal_absNorm,
    Nat.cast_mul, Nat.cast_pow, Nat.cast_ofNat]
  ring

lemma sqrt_inverse_weight (r s : ℝ) (hr : 0 < r) :
    Real.sqrt r / r * r^(-s) = r^(-(s+1/2)) := by
  rw [Real.sqrt_eq_rpow, div_eq_mul_inv, ← Real.rpow_neg_one,
    ← Real.rpow_add hr, ← Real.rpow_add hr]
  congr 1
  ring

def radialConstant (j : Fin 3) : ℝ :=
  ‖(-2*Real.pi*Complex.I)/(sourceCuspScale j:ℂ)^2‖ * thetaBesselScale

lemma radialConstant_nonneg (j : Fin 3) : 0 ≤ radialConstant j :=
  mul_nonneg (norm_nonneg _) thetaBesselScale_pos.le

lemma radial_weight_identity (j : Fin 3) (z : ℂ) (h : Eis) (hh : h ≠ 0) (s : ℝ) :
    ‖sourceCuspRadialCoefficient j z h‖ * (sourceCuspRadialLength h)^(-s) =
      radialConstant j * ‖(sourceCuspCoefficients j).value h‖ *
        (sourceCuspRadialLength h)^(-(s+1/2)) := by
  have he : sourceCuspRadialBaseCoefficient j h =
      ((-2*Real.pi*Complex.I)/(sourceCuspScale j:ℂ)^2) *
      cuspFrequency h * star ((sourceCuspCoefficients j).value h) /
      (sourceCuspRadialLength h:ℂ) := by
    unfold sourceCuspRadialBaseCoefficient
    simp only [div_eq_mul_inv, mul_inv_rev]
    ring
  rw [sourceCuspRadialCoefficient_norm, he, norm_div, norm_mul, norm_mul,
    norm_star, Complex.norm_real, Real.norm_eq_abs,
    abs_of_pos (sourceCuspRadialLength_pos h), sourceCuspRadialLength_frequency h hh]
  calc
    _ = radialConstant j * ‖(sourceCuspCoefficients j).value h‖ *
        (Real.sqrt (sourceCuspRadialLength h) / sourceCuspRadialLength h *
          (sourceCuspRadialLength h)^(-s)) := by unfold radialConstant; ring
    _ = _ := by rw [sqrt_inverse_weight _ _ (sourceCuspRadialLength_pos h)]

lemma weight_factorization (m : ℕ) (x y s : ℝ) (hx : 0 < x) (hy : 0 < y) :
    (3:ℝ)^((m:ℝ)/6) * Real.sqrt y * ((3:ℝ)^m*x*y^3)^(-(s+1/2)) =
      (3:ℝ)^(-(s+1/3)*(m:ℝ)) * x^(-(s+1/2)) * y^(-(3*s+1)) := by
  rw [Real.mul_rpow (by positivity) (by positivity),
    Real.mul_rpow (by positivity) hx.le,
    ← Real.rpow_natCast_mul (by norm_num : 0 ≤ (3:ℝ)),
    ← Real.rpow_natCast_mul hy.le, Real.sqrt_eq_rpow]
  calc
    _ = ((3:ℝ)^((m:ℝ)/6) * (3:ℝ)^((m:ℝ)*(-(s+1/2)))) *
        x^(-(s+1/2)) * (y^(1/2:ℝ)*y^((3:ℝ)*(-(s+1/2)))) := by ring
    _ = _ := by
      rw [← Real.rpow_add (by norm_num : 0 < (3:ℝ)), ← Real.rpow_add hy]
      congr 2 <;> congr 1 <;> ring

def sparseWeight (s : ℝ) (p : ThetaFullIndex) : ℝ :=
  (3:ℝ)^(-(s+1/3)*(p.2.1:ℝ)) *
    (Ideal.absNorm p.2.2.1.val:ℝ)^(-(s+1/2)) *
    (Ideal.absNorm p.2.2.2.val:ℝ)^(-(3*s+1))

lemma eligible_norm_pos (I : Ideal Eis) (hI : primaryGenerator I ≠ 0) :
    0 < (Ideal.absNorm I:ℝ) :=
  nonzeroIdeal_norm_pos ⟨I, primaryGenerator_ne_zero_ideal I hI⟩

lemma full_radial_weight_bound (j : Fin 3) (z : ℂ) (s : ℝ) (p : ThetaFullIndex) :
    ‖sourceCuspRadialCoefficient j z (thetaFullFrequency p)‖ *
      (sourceCuspRadialLength (thetaFullFrequency p))^(-s) ≤
        (radialConstant j * fixedCuspCoefficientBound) * sparseWeight s p := by
  rw [radial_weight_identity _ _ _ (thetaFullFrequency_ne_zero p)]
  have hb := sourceCuspCoefficients_squarefree_cube_bound j p.1 p.2.1
    p.2.2.1.val p.2.2.2.val ⟨p.2.2.1.property.1, p.2.2.1.property.2,
      p.2.2.2.property⟩
  change ‖(sourceCuspCoefficients j).value (thetaFullFrequency p)‖ ≤ _ at hb
  calc
    _ ≤ radialConstant j * (fixedCuspCoefficientBound * fixedCuspArrayWeight p.2.1
          p.2.2.2.val) * (sourceCuspRadialLength (thetaFullFrequency p))^(-(s+1/2)) :=
      mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left hb (radialConstant_nonneg j))
        (Real.rpow_nonneg (sourceCuspRadialLength_pos _).le _)
    _ = _ := by
      rw [full_radial_length]
      unfold fixedCuspArrayWeight sparseWeight
      have he := weight_factorization p.2.1 (Ideal.absNorm p.2.2.1.val:ℝ)
        (Ideal.absNorm p.2.2.2.val:ℝ) s
        (eligible_norm_pos _ p.2.2.1.property.2) (eligible_norm_pos _ p.2.2.2.property)
      calc
        _ = (radialConstant j * fixedCuspCoefficientBound) *
          ((3:ℝ)^((p.2.1:ℝ)/6) * Real.sqrt (Ideal.absNorm p.2.2.2.val:ℝ) *
            ((3:ℝ)^p.2.1 * (Ideal.absNorm p.2.2.1.val:ℝ) *
              (Ideal.absNorm p.2.2.2.val:ℝ)^3)^(-(s+1/2))) := by ring
        _ = _ := by rw [he]

lemma sparseWeight_summable (s : ℝ) (hs : 1/2 < s) : Summable (sparseWeight s) := by
  let fI : {I : Ideal Eis // Squarefree I ∧ primaryGenerator I ≠ 0} → NonzeroIdeal :=
    fun I => ⟨I.val, primaryGenerator_ne_zero_ideal _ I.property.2⟩
  let fJ : {J : Ideal Eis // primaryGenerator J ≠ 0} → NonzeroIdeal :=
    fun J => ⟨J.val, primaryGenerator_ne_zero_ideal _ J.property⟩
  have hIi : Function.Injective fI := by
    intro I J h
    exact Subtype.ext (congrArg (fun K : NonzeroIdeal => K.val) h)
  have hJi : Function.Injective fJ := by
    intro I J h
    exact Subtype.ext (congrArg (fun K : NonzeroIdeal => K.val) h)
  have hI := (nonzeroIdeal_norm_rpow_summable (s+1/2) (by linarith)).comp_injective hIi
  have hJ := (nonzeroIdeal_norm_rpow_summable (3*s+1) (by linarith)).comp_injective hJi
  have hp := hI.mul_of_nonneg hJ
    (fun I => Real.rpow_nonneg (nonzeroIdeal_norm_pos (fI I)).le _)
    (fun J => Real.rpow_nonneg (nonzeroIdeal_norm_pos (fJ J)).le _)
  have hm : Summable (fun m : ℕ => (3:ℝ)^(-(s+1/3)*(m:ℝ))) := by
    have hg := summable_geometric_of_lt_one
      (Real.rpow_nonneg (by norm_num : 0 ≤ (3:ℝ)) (-(s+1/3)))
      (Real.rpow_lt_one_of_one_lt_of_neg (by norm_num : 1 < (3:ℝ)) (by linarith))
    apply hg.congr
    intro m
    exact (Real.rpow_mul_natCast (by norm_num : 0 ≤ (3:ℝ)) _ m).symm
  have hmp := hm.mul_of_nonneg hp (fun m => Real.rpow_nonneg (by norm_num) _)
    (fun p => mul_nonneg (Real.rpow_nonneg (nonzeroIdeal_norm_pos (fI p.1)).le _)
      (Real.rpow_nonneg (nonzeroIdeal_norm_pos (fJ p.2)).le _))
  let : Finite Eisˣ := PrimaryIdealUnitReindex.finite_units
  have hu : Summable (fun _ : Eisˣ => (1:ℝ)) := Summable.of_finite
  have hall := hu.mul_of_nonneg hmp (fun _ => zero_le_one)
    (fun p => mul_nonneg (Real.rpow_nonneg (by norm_num) _)
      (mul_nonneg (Real.rpow_nonneg (nonzeroIdeal_norm_pos (fI p.2.1)).le _)
        (Real.rpow_nonneg (nonzeroIdeal_norm_pos (fJ p.2.2)).le _)))
  apply hall.congr
  intro p
  simp only [sparseWeight, fI, fJ, Function.comp_apply, one_mul]
  ring

theorem sourceCuspRadialCoefficient_weighted_summable_gt_half
    (j : Fin 3) (z : ℂ) (s : ℝ) (hs : 1/2 < s) :
    Summable (fun h : Eis => ‖sourceCuspRadialCoefficient j z h‖ *
      (sourceCuspRadialLength h)^(-s)) := by
  have hp : Summable (fun p : ThetaFullIndex =>
      ‖sourceCuspRadialCoefficient j z (thetaFullFrequency p)‖ *
        (sourceCuspRadialLength (thetaFullFrequency p))^(-s)) :=
    ((sparseWeight_summable s hs).mul_left (radialConstant j * fixedCuspCoefficientBound)).of_nonneg_of_le
      (fun p => mul_nonneg (norm_nonneg _)
        (Real.rpow_nonneg (sourceCuspRadialLength_pos _).le _))
      (full_radial_weight_bound j z s)
  apply (thetaFullFrequency_injective.summable_iff
    (f := fun h : Eis => ‖sourceCuspRadialCoefficient j z h‖ *
      (sourceCuspRadialLength h)^(-s)) ?_).mp hp
  intro h hh
  by_cases hz : h = 0
  · subst h; simp only [sourceCuspRadialCoefficient_zero, norm_zero, zero_mul]
  · have hc : sourceCuspRadialCoefficient j z h = 0 := by
      by_contra hc
      exact hh (sourceCuspRadialCoefficient_full_support j z h hz hc)
    rw [hc, norm_zero, zero_mul]

theorem sourceCuspRadialCoefficient_weighted_mass_uniform
    (s : ℝ) (hs : 1/2 < s) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (j : Fin 3) (z : ℂ),
      Summable (fun h : Eis => ‖sourceCuspRadialCoefficient j z h‖ *
        (sourceCuspRadialLength h)^(-s)) ∧
      (∑' h : Eis, ‖sourceCuspRadialCoefficient j z h‖ *
        (sourceCuspRadialLength h)^(-s)) ≤ C := by
  let mass : Fin 3 → ℝ := fun j =>
    ∑' h : Eis, ‖sourceCuspRadialCoefficient j 0 h‖ * (sourceCuspRadialLength h)^(-s)
  have hmass : ∀ j, 0 ≤ mass j := fun j => tsum_nonneg (fun h =>
    mul_nonneg (norm_nonneg _) (Real.rpow_nonneg (sourceCuspRadialLength_pos h).le _))
  refine ⟨∑ j : Fin 3, mass j, Finset.sum_nonneg (fun j _ => hmass j), ?_⟩
  intro j z
  refine ⟨sourceCuspRadialCoefficient_weighted_summable_gt_half j z s hs, ?_⟩
  have he : (∑' h : Eis, ‖sourceCuspRadialCoefficient j z h‖ *
      (sourceCuspRadialLength h)^(-s)) = mass j := by
    apply tsum_congr
    intro h
    simp only [sourceCuspRadialCoefficient_norm]
  rw [he]
  exact Finset.single_le_sum (fun i _ => hmass i) (Finset.mem_univ j)

#print axioms sourceCuspRadialCoefficient_weighted_summable_gt_half
#print axioms sourceCuspRadialCoefficient_weighted_mass_uniform
end
end QRHExperimental.SparseRadialSummability
