import DivisorRadialMass
import OAI.NumberTheory.DirichletL.ChineseRemainder.FrequencyLifts

/-! Good-prime membership of the actual cusp phase numerator and the
actual sparse radial frequency. No norm-divisibility surrogate is used.
The ramified quotient is used only on actual nonzero coefficient support. -/
namespace QRHExperimental.PhaseNumeratorSupport
noncomputable section
open OAI OAI.ActualEisensteinCubic OAI.ConcreteTraceCRT
open OAI.CubicEisenstein OAI.CompletedGauss
open scoped Classical
local notation "Eis" => OAI.ActualEisensteinCubic.O

lemma traceLambda_not_mem (P : Ideal Eis) [P.IsPrime]
    (hgood : lambda ∉ P) : ramifiedTraceLambda ∉ P := by
  change paperLambda ∉ P
  rw [paperLambda_eq]
  intro h
  rcases (inferInstance : P.IsPrime).mem_or_mem h with hu | hl
  · exact (Ideal.notMem_of_isUnit P paperLambdaUnit.isUnit) hu
  · exact hgood hl

theorem phaseNumerator_mem_iff (P : Ideal Eis) [P.IsPrime]
    (hgood : lambda ∉ P) (j : Fin 3) (w : Eisˣ) (h : Eis)
    (hcoeff : (sourceCuspCoefficients j).value h ≠ 0) :
    sourceCuspPhaseNumerator j w.val h ∈ P ↔ h ∈ P := by
  have hl := traceLambda_not_mem P hgood
  have hw : w.val ^ 2 ∉ P :=
    Ideal.notMem_of_isUnit P (w.isUnit.pow 2)
  by_cases hj : j = 0
  · have hp : ramifiedTraceLambda * w.val ^ 2 ∉ P := by
      intro hp
      rcases (inferInstance : P.IsPrime).mem_or_mem hp with hp | hp
      · exact hl hp
      · exact hw hp
    simp only [sourceCuspPhaseNumerator, if_pos hj]
    exact Ideal.IsPrime.mul_mem_left_iff hp
  · have hn : -(w.val ^ 2) ∉ P :=
      Ideal.notMem_of_isUnit P (w.isUnit.pow 2).neg
    have hd := sourceCuspCoefficients_ramified_divisibility j hj h hcoeff
    simp only [sourceCuspPhaseNumerator, if_neg hj]
    rw [Ideal.IsPrime.mul_mem_left_iff hn]
    calc
      paperLambdaQuotient h ∈ P ↔
          ramifiedTraceLambda * paperLambdaQuotient h ∈ P :=
        (Ideal.IsPrime.mul_mem_left_iff hl).symm
      _ ↔ h ∈ P := by rw [paperLambdaQuotient_mul h hd]

lemma primaryGenerator_mem_iff_dvd (P I : Ideal Eis)
    (hI : primaryGenerator I ≠ 0) : primaryGenerator I ∈ P ↔ P ∣ I := by
  calc
    primaryGenerator I ∈ P ↔ Ideal.span {primaryGenerator I} ≤ P :=
      (Ideal.span_le.trans Set.singleton_subset_iff).symm
    _ ↔ I ≤ P := by rw [(primaryGenerator_spec I hI).1]
    _ ↔ P ∣ I := Ideal.dvd_iff_le.symm

theorem fullFrequency_mem_iff (P : Ideal Eis) [P.IsPrime]
    (hgood : lambda ∉ P) (p : ThetaFullIndex) :
    thetaFullFrequency p ∈ P ↔ P ∣ p.2.2.1.val ∨ P ∣ p.2.2.2.val := by
  have hu : p.1.val ∉ P := Ideal.notMem_of_isUnit P p.1.isUnit
  have hl : lambda ^ p.2.1 ∉ P := by
    intro h
    exact hgood ((inferInstance : P.IsPrime).mem_of_pow_mem p.2.1 h)
  have hup : p.1.val * lambda ^ p.2.1 ∉ P := by
    intro h
    rcases (inferInstance : P.IsPrime).mem_or_mem h with h | h
    · exact hu h
    · exact hl h
  rw [thetaFullFrequency,
    (inferInstance : P.IsPrime).mul_mem_iff_mem_or_mem,
    Ideal.IsPrime.mul_mem_left_iff hup,
    (inferInstance : P.IsPrime).pow_mem_iff_mem 3 (by decide),
    primaryGenerator_mem_iff_dvd P _ p.2.2.1.property.2,
    primaryGenerator_mem_iff_dvd P _ p.2.2.2.property]

theorem phaseNumerator_fullFrequency_mem_iff (P : Ideal Eis) [P.IsPrime]
    (hgood : lambda ∉ P) (j : Fin 3) (w : Eisˣ) (p : ThetaFullIndex)
    (hcoeff : (sourceCuspCoefficients j).value (thetaFullFrequency p) ≠ 0) :
    sourceCuspPhaseNumerator j w.val (thetaFullFrequency p) ∈ P ↔
      P ∣ p.2.2.1.val ∨ P ∣ p.2.2.2.val := by
  rw [phaseNumerator_mem_iff P hgood j w _ hcoeff,
    fullFrequency_mem_iff P hgood p]

#print axioms phaseNumerator_mem_iff
#print axioms fullFrequency_mem_iff
#print axioms phaseNumerator_fullFrequency_mem_iff
end
end QRHExperimental.PhaseNumeratorSupport
