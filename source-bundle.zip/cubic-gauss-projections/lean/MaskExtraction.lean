import CompositeProjection
import OAI.NumberTheory.DirichletL.Detector.CubicGaussCRT

/-! Exact extraction of squarefree Gauss columns. The identity retains all
shared-factor zeros and allows arbitrary multiplicative coefficient twists. -/
namespace QRHExperimental.MaskExtraction
noncomputable section
open OAI OAI.ActualEisensteinCubic OAI.CompletedGauss OAI.CubicEisenstein
open OAI.ConcreteTraceCRT OAI.SevenEighths
open QRHExperimental.TrivialProjection
open scoped BigOperators Classical
set_option maxHeartbeats 2500000
local notation "Eis" => OAI.ActualEisensteinCubic.O

def cubicTwist (D : Ideal Eis) (hD : CubicSieve.Admissible D) : Eis →* ℂ :=
  (CubicSieve.cubicQuotientCharacter D hD).toMonoidHom.comp (Ideal.Quotient.mk D).toMonoidHom

def fourthTwist (D : Ideal Eis) (hD : CubicSieve.Admissible D) : Eis →* ℂ := cubicTwist D hD ^ 2

def coprimeMask (D : Ideal Eis) (hD : CubicSieve.Admissible D) : Eis →* ℂ := cubicTwist D hD ^ 3

@[simp] lemma cubicTwist_apply (D : Ideal Eis) (hD : CubicSieve.Admissible D) (x : Eis) :
    cubicTwist D hD x = CubicSieve.cubicRow D x :=
  CubicSieve.cubicQuotientCharacter_mk D hD x

@[simp] lemma fourthTwist_apply (D : Ideal Eis) (hD : CubicSieve.Admissible D) (x : Eis) :
    fourthTwist D hD x = CubicSieve.cubicRow D x ^ 2 := by
  simp [fourthTwist]

lemma coprimeMask_apply (D : Ideal Eis) (hD : CubicSieve.Admissible D) (x : Eis) :
    coprimeMask D hD x = if IsCoprime D (Ideal.span {x}) then 1 else 0 := by
  simp only [coprimeMask,MonoidHom.pow_apply,cubicTwist_apply]
  exact CubicSieve.idealSymbol_cube_mask D x hD.2

lemma squarefree_product_coprime (D J : Ideal Eis) (h : Squarefree (D*J)) :
    IsCoprime D J := by
  apply Ideal.isCoprime_iff_gcd.mpr
  have hu := (squarefree_mul_iff.mp h).1 (gcd_dvd_left D J) (gcd_dvd_right D J)
  simpa only [Ideal.one_eq_top] using Ideal.isUnit_iff.mp hu

lemma gamma_coprime_product (D J : Ideal Eis)
    (hD : CubicSieve.Admissible D) (hJ : CubicSieve.Admissible J)
    (hc : IsCoprime D J) :
    squarefreeGaussCoefficient (D*J) = squarefreeGaussCoefficient D *
      squarefreeGaussCoefficient J * CubicSieve.cubicRow D (primaryGenerator J)^2 := by
  have hDJ : CubicSieve.Admissible (D*J) :=
    ⟨squarefree_mul_iff.mpr ⟨hc.isRelPrime,hD.1,hJ.1⟩,
      by rw [primaryGenerator_mul]; exact mul_ne_zero hD.2 hJ.2⟩
  have hrec : CubicSieve.cubicRow J (primaryGenerator D) =
      CubicSieve.cubicRow D (primaryGenerator J) :=
    CubicSieve.idealKernel_reciprocity J D hJ.2 hD.2
  rw [squarefreeGaussCoefficient_eq _ hDJ.1 hDJ.2,
    squarefreeGaussCoefficient_eq _ hD.1 hD.2,squarefreeGaussCoefficient_eq _ hJ.1 hJ.2,
    ProbePhysical.gaussTwo_coprime_product D J hD hJ hDJ hc,
    primaryGenerator_mul,angularFactor_mul,star_mul,hrec]
  ring

/-- Shared factors and inadmissible cofactors vanish on both sides. -/
theorem gamma_product_all (D J : Ideal Eis) (hD : CubicSieve.Admissible D) :
    squarefreeGaussCoefficient (D*J) = squarefreeGaussCoefficient D *
      squarefreeGaussCoefficient J * fourthTwist D hD (primaryGenerator J) := by
  by_cases hJ : CubicSieve.Admissible J
  · by_cases hc : IsCoprime D J
    · simpa only [fourthTwist_apply] using gamma_coprime_product D J hD hJ hc
    · have hns : ¬Squarefree (D*J) := fun h => hc (squarefree_product_coprime D J h)
      have hz : CubicSieve.cubicRow D (primaryGenerator J)=0 := by
        have hm := CubicSieve.idealSymbol_cube_mask D (primaryGenerator J) hD.2
        rw [(primaryGenerator_spec J hJ.2).1,if_neg hc] at hm
        exact eq_zero_of_pow_eq_zero hm
      simp only [squarefreeGaussCoefficient,not_and_of_not_left _ hns,dite_false,
        fourthTwist_apply,hz,zero_pow (by decide : (2:ℕ)≠0),mul_zero]
  · have hnDJ : ¬CubicSieve.Admissible (D*J) := by
      intro h
      exact hJ (CubicSieve.cubic_admissible_of_dvd h (dvd_mul_left J D))
    simp only [CubicSieve.Admissible] at hJ hnDJ
    simp only [squarefreeGaussCoefficient,dif_neg hnDJ,dif_neg hJ,mul_zero,zero_mul]

theorem columnWeight_product_all (Ψ : Eis →* ℂ) (D J : Ideal Eis)
    (hD : CubicSieve.Admissible D) :
    columnWeight Ψ (D*J) = columnWeight Ψ D * columnWeight (Ψ*fourthTwist D hD) J := by
  simp only [columnWeight,gamma_product_all D J hD,primaryGenerator_mul,map_mul,
    MonoidHom.mul_apply]
  ring

/-- Exact rescaling of the D-divisible portion of the actual projection.
No periodicity, coprimality, or size hypothesis on Ψ is imposed. -/
theorem divisor_projection (Ψ : Eis →* ℂ) (D : Ideal Eis) (hD : CubicSieve.Admissible D)
    (W : ℝ → ℂ) (L : ℝ) :
    (∑' I : Ideal Eis, if D ∣ I then columnWeight Ψ I * W ((Ideal.absNorm I:ℝ)/L) else 0) =
      columnWeight Ψ D * rawProjection (Ψ*fourthTwist D hD) W (L/(Ideal.absNorm D:ℝ)) := by
  have hD0 := primaryGenerator_ne_zero_ideal D hD.2
  have hi : Function.Injective (fun J : Ideal Eis => D*J) := by
    intro J K h
    exact mul_left_cancel₀ hD0 h
  have he := hi.tsum_eq (f := fun I : Ideal Eis =>
    if D ∣ I then columnWeight Ψ I * W ((Ideal.absNorm I:ℝ)/L) else 0) (by
      intro I hI
      by_contra hn
      apply hI
      exact if_neg (fun hd => hn (by rcases hd with ⟨J,hJ⟩; exact ⟨J,hJ.symm⟩)))
  rw [← he]
  calc
    _ = ∑' J : Ideal Eis, columnWeight Ψ D *
        (columnWeight (Ψ*fourthTwist D hD) J * W ((Ideal.absNorm J:ℝ)/(L/(Ideal.absNorm D:ℝ)))) := by
      apply tsum_congr
      intro J
      rw [if_pos (dvd_mul_right D J),columnWeight_product_all Ψ D J hD,map_mul,Nat.cast_mul]
      have hn : (Ideal.absNorm D:ℝ)*(Ideal.absNorm J:ℝ)/L =
          (Ideal.absNorm J:ℝ)/(L/(Ideal.absNorm D:ℝ)) := by
        simp only [div_eq_mul_inv,mul_inv_rev,inv_inv]
        ring
      rw [hn]
      ring
    _ = _ := by rw [tsum_mul_left]; rfl

open IdealMobiusDivisorSum

lemma divisor_admissible (M : Ideal Eis) (hM : CubicSieve.Admissible M)
    (D : idealDivisors M) : CubicSieve.Admissible D.val :=
  CubicSieve.cubic_admissible_of_dvd hM
    ((mem_idealDivisors (primaryGenerator_ne_zero_ideal M hM.2)).mp D.property)

/-- One global finite Möbius expansion. This exact identity allows arbitrary
base and moving-twist overlaps; bounds can simplify those overlaps later. -/
theorem masked_projection_mobius
    (Ψ : Eis →* ℂ) (M : Ideal Eis) (hM : CubicSieve.Admissible M)
    (W : ℝ → ℂ) (b L : ℝ) (hL : 0 < L)
    (hW : ∀ x, W x ≠ 0 → x ≤ b) :
    rawProjection (Ψ*coprimeMask M hM) W L =
      ∑ D : idealDivisors M, (UniqueFactorizationMonoid.moebius D.val : ℂ)*
        columnWeight Ψ D.val *
        rawProjection (Ψ*fourthTwist D.val (divisor_admissible M hM D)) W
          (L/(Ideal.absNorm D.val:ℝ)) := by
  have hM0 := primaryGenerator_ne_zero_ideal M hM.2
  let f : Ideal Eis → ℂ := fun I => columnWeight Ψ I * W ((Ideal.absNorm I:ℝ)/L)
  have houtside (I : Ideal Eis) (hI : I ∉ idealBall (b*L)) : f I = 0 := by
    by_cases hi : I = 0
    · simp [f,hi]
    have hw : W ((Ideal.absNorm I:ℝ)/L)=0 := by
      by_contra hn
      exact hI ((mem_idealBall _ _).mpr ⟨hi,(div_le_iff₀ hL).mp (hW _ hn)⟩)
    simp [f,hw]
  have hs (D : idealDivisors M) :
      Summable (fun I : Ideal Eis => (UniqueFactorizationMonoid.moebius D.val:ℂ)*
        (if D.val ∣ I then f I else 0)) := by
    apply summable_of_ne_finset_zero (s := idealBall (b*L))
    intro I hI
    rw [houtside I hI]
    simp
  have hp (I : Ideal Eis) :
      columnWeight (Ψ*coprimeMask M hM) I * W ((Ideal.absNorm I:ℝ)/L) =
        ∑ D : idealDivisors M, (UniqueFactorizationMonoid.moebius D.val:ℂ)*
          (if D.val ∣ I then f I else 0) := by
    by_cases hi : primaryGenerator I=0
    · have hz : squarefreeGaussCoefficient I=0 := by simp [squarefreeGaussCoefficient,hi]
      simp only [columnWeight,hz,zero_mul,f,ite_self,Finset.sum_const_zero,mul_zero]
    have he := SevenEighths.InverseMoment.ideal_coprime_mobius M I hM0
    rw [←Finset.sum_coe_sort] at he
    simp only [columnWeight,MonoidHom.mul_apply,coprimeMask_apply,
      (primaryGenerator_spec I hi).1]
    rw [he]
    simp only [Finset.mul_sum,Finset.sum_mul]
    apply Finset.sum_congr rfl
    intro D hD
    by_cases hd : D.val ∣ I <;> simp [hd,f,columnWeight] <;> ring
  unfold rawProjection
  simp_rw [hp]
  rw [Summable.tsum_finsetSum (fun D _ => hs D)]
  apply Finset.sum_congr rfl
  intro D hD
  rw [tsum_mul_left]
  have he := divisor_projection Ψ D.val (divisor_admissible M hM D) W L
  change (UniqueFactorizationMonoid.moebius D.val:ℂ)*
      (∑' I : Ideal Eis, if D.val ∣ I then columnWeight Ψ I * W ((Ideal.absNorm I:ℝ)/L) else 0) = _
  rw [he]
  simp only [rawProjection]
  ring

#print axioms gamma_product_all
#print axioms columnWeight_product_all
#print axioms divisor_projection
#print axioms masked_projection_mobius
end
end QRHExperimental.MaskExtraction
