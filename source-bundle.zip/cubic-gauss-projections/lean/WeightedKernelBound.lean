import TrivialProjection

/-! An endpoint kernel estimate from cumulative coefficient mass.
The square-root mass condition is explicit; no cancellation is assumed. -/
namespace QRHExperimental.WeightedKernelBound
noncomputable section
open scoped BigOperators Classical
set_option maxHeartbeats 1500000

def SqrtMassBound {ι : Type*} (a r : ι → ℝ) (C : ℝ) : Prop :=
  ∀ (S : Finset ι) (T : ℝ), 0 < T → (∀ i ∈ S, r i ≤ T) →
    (∑ i ∈ S, a i) ≤ C*T^(1/2:ℝ)

lemma sqrt_four (U : ℝ) (hU : 0 ≤ U) :
    (4*U)^(1/2:ℝ) = 2*U^(1/2:ℝ) := by
  rw [Real.mul_rpow (by norm_num : (0:ℝ)≤4) hU]
  norm_num [← Real.sqrt_eq_rpow]

lemma tail_four (U : ℝ) (hU : 0 < U) :
    (4*U)^(-(1/2):ℝ) = (1/2)*U^(-(1/2):ℝ) := by
  rw [Real.mul_rpow (by norm_num : (0:ℝ)≤4) hU.le,
    Real.rpow_neg (by norm_num : (0:ℝ)≤4)]
  norm_num [← Real.sqrt_eq_rpow]

lemma half_div (U : ℝ) (hU : 0 < U) :
    U^(1/2:ℝ)/U = U^(-(1/2):ℝ) := by
  rw [div_eq_mul_inv, ← Real.rpow_neg_one, ← Real.rpow_add hU]
  norm_num

lemma weighted_tail_band {ι : Type*} (a r : ι → ℝ) (C : ℝ)
    (ha : ∀ i, 0 ≤ a i) (hc : SqrtMassBound a r C)
    (S : Finset ι) (U : ℝ) (hU : 0 < U)
    (hlo : ∀ i ∈ S, U < r i) (hhi : ∀ i ∈ S, r i ≤ 4*U) :
    (∑ i ∈ S, a i/r i) ≤ 2*C*U^(-(1/2):ℝ) := by
  calc
    _ ≤ ∑ i ∈ S, a i/U := Finset.sum_le_sum (fun i hi =>
      div_le_div_of_nonneg_left (ha i) hU (hlo i hi).le)
    _ = (∑ i ∈ S, a i)/U := (Finset.sum_div _ _ _).symm
    _ ≤ (C*(4*U)^(1/2:ℝ))/U :=
      div_le_div_of_nonneg_right (hc S (4*U) (by positivity) hhi) hU.le
    _ = 2*C*(U^(1/2:ℝ)/U) := by rw [sqrt_four U hU.le]; ring
    _ = _ := by rw [half_div U hU]

private lemma weighted_tail_aux {ι : Type*} (a r : ι → ℝ) (C : ℝ)
    (hC : 0 ≤ C) (ha : ∀ i, 0 ≤ a i) (hc : SqrtMassBound a r C) (k : ℕ) :
    ∀ (U : ℝ), 0 < U → ∀ S : Finset ι,
      (∀ i ∈ S, U < r i) → (∀ i ∈ S, r i ≤ (4:ℝ)^k*U) →
      (∑ i ∈ S, a i/r i) ≤ 4*C*U^(-(1/2):ℝ) := by
  induction k with
  | zero =>
    intro U hU S hlo hhi
    have he : S=∅ := Finset.eq_empty_iff_forall_notMem.mpr (by
      intro i hi
      have hh := hhi i hi
      simp only [pow_zero, one_mul] at hh
      exact (not_lt_of_ge hh) (hlo i hi))
    rw [he, Finset.sum_empty]
    positivity
  | succ k ih =>
    intro U hU S hlo hhi
    have hb := weighted_tail_band a r C ha hc (S.filter (fun i => r i ≤ 4*U)) U hU
      (fun i hi => hlo i (Finset.mem_filter.mp hi).1)
      (fun i hi => (Finset.mem_filter.mp hi).2)
    have ht := ih (4*U) (by positivity) (S.filter (fun i => ¬r i ≤ 4*U))
      (fun i hi => lt_of_not_ge (Finset.mem_filter.mp hi).2) (by
        intro i hi
        have hh := hhi i (Finset.mem_filter.mp hi).1
        convert hh using 1 <;> ring)
    rw [tail_four U hU] at ht
    rw [← Finset.sum_filter_add_sum_filter_not S (fun i => r i ≤ 4*U)]
    linarith

theorem weighted_tail {ι : Type*} (a r : ι → ℝ) (C : ℝ)
    (hC : 0 ≤ C) (ha : ∀ i, 0 ≤ a i) (hc : SqrtMassBound a r C)
    (S : Finset ι) (U : ℝ) (hU : 0 < U) (hlo : ∀ i ∈ S, U < r i) :
    (∑ i ∈ S, a i/r i) ≤ 4*C*U^(-(1/2):ℝ) := by
  let k : ℕ := S.sup (fun i => ⌈r i/U⌉₊)
  apply weighted_tail_aux a r C hC ha hc k U hU S hlo
  intro i hi
  have h1 : (r i/U) ≤ (k:ℝ) :=
    (Nat.le_ceil _).trans (Nat.cast_le.mpr (Finset.le_sup (f := fun i => ⌈r i/U⌉₊) hi))
  have h2 : (k:ℝ) ≤ (4:ℝ)^k := by
    calc
      _ ≤ (2:ℝ)^k := by exact_mod_cast Nat.le_of_lt k.lt_two_pow_self
      _ ≤ _ := by gcongr <;> norm_num
  exact (div_le_iff₀ hU).mp (h1.trans h2)

lemma inverse_half (v : ℝ) (hv : 0 < v) :
    (v⁻¹)^(1/2:ℝ) = v^(-(1/2):ℝ) := by
  rw [Real.inv_rpow hv.le, Real.rpow_neg hv.le]

theorem kernel_finite_bound {ι : Type*} (b : ι → ℂ) (r : ι → ℝ) (C D : ℝ)
    (hC : 0 ≤ C) (hD : 0 ≤ D) (hr : ∀ i, 0 < r i)
    (hc : SqrtMassBound (fun i => ‖b i‖) r C)
    (K : ℝ → ℂ)
    (hsmall : ∀ t, 0 < t → t ≤ 1 → ‖K t‖ ≤ D)
    (hlarge : ∀ t, 1 ≤ t → ‖K t‖ ≤ D/t)
    (v : ℝ) (hv : 0 < v) (S : Finset ι) :
    (∑ i ∈ S, ‖b i*K (v*r i)‖) ≤ 5*C*D*v^(-(1/2):ℝ) := by
  let U : ℝ := v⁻¹
  have hU : 0 < U := inv_pos.mpr hv
  have hlow : (∑ i ∈ S.filter (fun i => r i ≤ U), ‖b i*K (v*r i)‖) ≤
      D*(C*U^(1/2:ℝ)) := by
    calc
      _ ≤ ∑ i ∈ S.filter (fun i => r i ≤ U), D*‖b i‖ := by
        apply Finset.sum_le_sum
        intro i hi
        rw [norm_mul, mul_comm D]
        apply mul_le_mul_of_nonneg_left _ (norm_nonneg _)
        apply hsmall _ (mul_pos hv (hr i))
        have hh := mul_le_mul_of_nonneg_left (Finset.mem_filter.mp hi).2 hv.le
        simpa only [U, mul_inv_cancel₀ hv.ne'] using hh
      _ = D*(∑ i ∈ S.filter (fun i => r i ≤ U), ‖b i‖) := (Finset.mul_sum _ _ _).symm
      _ ≤ _ := mul_le_mul_of_nonneg_left
        (hc _ U hU (fun i hi => (Finset.mem_filter.mp hi).2)) hD
  have hhigh : (∑ i ∈ S.filter (fun i => ¬r i ≤ U), ‖b i*K (v*r i)‖) ≤
      4*C*D*U^(1/2:ℝ) := by
    have ht := weighted_tail (fun i => ‖b i‖) r C hC (fun _ => norm_nonneg _) hc
      (S.filter (fun i => ¬r i ≤ U)) U hU
      (fun i hi => lt_of_not_ge (Finset.mem_filter.mp hi).2)
    calc
      _ ≤ ∑ i ∈ S.filter (fun i => ¬r i ≤ U), (D/v)*(‖b i‖/r i) := by
        apply Finset.sum_le_sum
        intro i hi
        have hh := mul_le_mul_of_nonneg_left
          (lt_of_not_ge (Finset.mem_filter.mp hi).2).le hv.le
        have hvr : 1 ≤ v*r i := by simpa only [U, mul_inv_cancel₀ hv.ne'] using hh
        rw [norm_mul]
        calc
          _ ≤ ‖b i‖*(D/(v*r i)) := mul_le_mul_of_nonneg_left (hlarge _ hvr) (norm_nonneg _)
          _ = _ := by ring
      _ = (D/v)*(∑ i ∈ S.filter (fun i => ¬r i ≤ U), ‖b i‖/r i) :=
        (Finset.mul_sum _ _ _).symm
      _ ≤ (D/v)*(4*C*U^(-(1/2):ℝ)) := mul_le_mul_of_nonneg_left ht (div_nonneg hD hv.le)
      _ = 4*C*D*(U^(-(1/2):ℝ)*U) := by dsimp [U]; ring
      _ = _ := by rw [←Real.rpow_add_one hU.ne']; norm_num
  rw [← Finset.sum_filter_add_sum_filter_not S (fun i => r i ≤ U)]
  have he : U^(1/2:ℝ) = v^(-(1/2):ℝ) := inverse_half v hv
  rw [he] at hlow hhigh
  linarith

theorem kernel_summable_and_bound {ι : Type*} (b : ι → ℂ) (r : ι → ℝ) (C D : ℝ)
    (hC : 0 ≤ C) (hD : 0 ≤ D) (hr : ∀ i, 0 < r i)
    (hc : SqrtMassBound (fun i => ‖b i‖) r C)
    (K : ℝ → ℂ)
    (hsmall : ∀ t, 0 < t → t ≤ 1 → ‖K t‖ ≤ D)
    (hlarge : ∀ t, 1 ≤ t → ‖K t‖ ≤ D/t)
    (v : ℝ) (hv : 0 < v) :
    Summable (fun i => ‖b i*K (v*r i)‖) ∧
      ‖∑' i, b i*K (v*r i)‖ ≤ 5*C*D*v^(-(1/2):ℝ) := by
  have hs : Summable (fun i => ‖b i*K (v*r i)‖) := by
    apply summable_of_sum_le (c := 5*C*D*v^(-(1/2):ℝ))
    · intro i; exact norm_nonneg _
    · exact kernel_finite_bound b r C D hC hD hr hc K hsmall hlarge v hv
  refine ⟨hs, (norm_tsum_le_tsum_norm hs).trans ?_⟩
  apply Real.tsum_le_of_sum_le
  · intro i; exact norm_nonneg _
  · exact kernel_finite_bound b r C D hC hD hr hc K hsmall hlarge v hv

#print axioms weighted_tail
#print axioms kernel_summable_and_bound
end
end QRHExperimental.WeightedKernelBound
