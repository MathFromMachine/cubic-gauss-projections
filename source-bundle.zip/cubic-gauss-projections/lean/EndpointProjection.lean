import CubeInverseAssembly
import RadialCumulativeMass
import WeightedKernelBound

/-! Exact exponent 3/4 from cumulative radial mass and the actual kernel.
The divergent bare endpoint weighted series is never asserted summable. -/
namespace QRHExperimental.EndpointProjection
noncomputable section
set_option maxHeartbeats 2000000
open OAI OAI.ActualEisensteinCubic OAI.ConcreteTraceCRT
open OAI.CubicEisenstein OAI.CompletedGauss
open QRHExperimental.RadialCumulativeMass QRHExperimental.WeightedKernelBound
open QRHExperimental.TrivialProjection QRHExperimental.CubeInverseAssembly
open scoped BigOperators Classical ContDiff
local notation "Eis" => OAI.ActualEisensteinCubic.O

lemma radial_sqrt_mass_uniform :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (j : Fin 3) (z : ℂ),
      SqrtMassBound (fun n : Eis => ‖sourceCuspRadialCoefficient j z n‖)
        sourceCuspRadialLength C := by
  obtain ⟨C, hC, hb⟩ := sourceCuspRadialCoefficient_cumulative_mass_uniform
  refine ⟨C, hC, ?_⟩
  intro j z S T hT hS
  have hm := hb j z T hT
  calc
    _ = ∑ n ∈ S, radialMassTerm j z T n := by
      apply Finset.sum_congr rfl
      intro n hn
      simp only [radialMassTerm, ite_eq_left (hS n hn)]
    _ ≤ ∑' n : Eis, radialMassTerm j z T n :=
      hm.1.sum_le_tsum S (fun n _ => radialMassTerm_nonneg j z T n)
    _ ≤ C*Real.sqrt T := hm.2
    _ = _ := by rw [Real.sqrt_eq_rpow]

lemma paperKernel_two_sided_bound
    (W : ℝ → ℂ) (v0 v1 : ℝ) (hv0 : 0 < v0)
    (hWs : Function.support W ⊆ Set.Icc v0 v1) (hW : ContDiff ℝ ∞ W) :
    ∃ D : ℝ, 0 ≤ D ∧
      (∀ t : ℝ, 0 < t → t ≤ 1 → ‖CubicReflectionKernel.paperKernel (Vstar W) t‖ ≤ D) ∧
      (∀ t : ℝ, 1 ≤ t → ‖CubicReflectionKernel.paperKernel (Vstar W) t‖ ≤ D/t) := by
  have hvstar := Vstar_contDiff W v0 v1 hv0 hWs hW
  have hsupp := Vstar_support W v0 v1 hWs
  obtain ⟨D0, hD0, hb0⟩ := CubicReflectionKernel.paperKernel_euler_decay_at_line
    (Vstar W) v0 v1 hv0 hsupp hvstar 1 0 0 (by norm_num)
  obtain ⟨D1, hD1, hb1⟩ := CubicReflectionKernel.paperKernel_euler_decay_at_line
    (Vstar W) v0 v1 hv0 hsupp hvstar 1 0 1 (by norm_num)
  have h0 (t : ℝ) (ht : 0 < t) : ‖CubicReflectionKernel.paperKernel (Vstar W) t‖ ≤ D0 := by
    simpa only [LocalLogFourier.eulerDeriv, iteratedDeriv_zero, Real.exp_zero,
      mul_one, neg_zero, Real.rpow_zero] using hb0 t ht
  have h1 (t : ℝ) (ht : 0 < t) : ‖CubicReflectionKernel.paperKernel (Vstar W) t‖ ≤ D1/t := by
    simpa only [LocalLogFourier.eulerDeriv, iteratedDeriv_zero, Real.exp_zero,
      mul_one, Real.rpow_neg_one, div_eq_mul_inv] using hb1 t ht
  refine ⟨max D0 D1, hD0.le.trans (le_max_left _ _), ?_, ?_⟩
  · intro t ht _
    exact (h0 t ht).trans (le_max_left _ _)
  · intro t ht
    exact (h1 t (zero_lt_one.trans_le ht)).trans
      (div_le_div_of_nonneg_right (le_max_right _ _) (zero_le_one.trans ht))

theorem smoothedKernel_endpoint_bound
    (W : ℝ → ℂ) (v0 v1 : ℝ) (hv0 : 0 < v0)
    (hWs : Function.support W ⊆ Set.Icc v0 v1) (hW : ContDiff ℝ ∞ W) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (d : SourceCuspDatum) (X : ℝ), 0 < X →
      ‖d.smoothedKernel W X‖ ≤ C * d.heightScale * X^(-(1/2):ℝ) := by
  obtain ⟨M, hM, hm⟩ := radial_sqrt_mass_uniform
  obtain ⟨D, hD, hsmall, hlarge⟩ := paperKernel_two_sided_bound W v0 v1 hv0 hWs hW
  let b : Fin 3 → ℝ := fun j => (27*(sourceCuspScale j)^2)^(1/2:ℝ)
  have hb : ∀ j, 0 ≤ b j := fun j => Real.rpow_nonneg (by positivity) _
  let B : ℝ := ∑ j : Fin 3, b j
  have hB : 0 ≤ B := Finset.sum_nonneg (fun j _ => hb j)
  have hbB : ∀ j, b j ≤ B := fun j =>
    Finset.single_le_sum (fun i _ => hb i) (Finset.mem_univ j)
  refine ⟨45*M*D*B, by positivity, ?_⟩
  intro d X hX
  have hscale : 0 < 27*(sourceCuspScale d.index)^2 := by
    have := sourceCuspScale_pos d.index
    positivity
  let v : ℝ := X/(27*(sourceCuspScale d.index)^2*d.heightScale^2)
  have hv : 0 < v := div_pos hX (mul_pos hscale (sq_pos_of_pos d.heightScale_pos))
  have hseries := kernel_summable_and_bound
    (sourceCuspRadialCoefficient d.index d.dualPoint) sourceCuspRadialLength M D hM hD
    sourceCuspRadialLength_pos (hm d.index d.dualPoint)
    (CubicReflectionKernel.paperKernel (Vstar W)) hsmall hlarge v hv
  have he : v^(-(1/2):ℝ) = b d.index * d.heightScale * X^(-(1/2):ℝ) := by
    have h := QRHExperimental.UniformReflectionBound.kernel_argument_power
      (27*(sourceCuspScale d.index)^2) d.heightScale X 1 (1/2) hscale
      d.heightScale_pos hX (by norm_num)
    norm_num only [mul_one, Real.one_rpow, show (2:ℝ)*(1/2)=1 by norm_num,
      Real.rpow_one] at h
    exact h
  have hs : ‖∑' n : Eis, sourceCuspRadialCoefficient d.index d.dualPoint n *
      CubicReflectionKernel.paperKernel (Vstar W)
        (X*sourceCuspRadialLength n/(27*(sourceCuspScale d.index)^2*d.heightScale^2))‖ ≤
      5*M*D*(b d.index*d.heightScale*X^(-(1/2):ℝ)) := by
    simpa only [he, v, div_mul_eq_mul_div] using hseries.2
  rw [d.smoothedKernel_eq, norm_mul]
  calc
    _ ≤ 9 * (5*M*D*(b d.index*d.heightScale*X^(-(1/2):ℝ))) :=
      mul_le_mul d.smoothedKernel_prefactor_norm_le hs (norm_nonneg _) (by norm_num)
    _ ≤ 9 * (5*M*D*(B*d.heightScale*X^(-(1/2):ℝ))) := by
      apply mul_le_mul_of_nonneg_left _ (by norm_num)
      apply mul_le_mul_of_nonneg_left _ (by positivity)
      exact mul_le_mul_of_nonneg_right
        (mul_le_mul_of_nonneg_right (hbB d.index) d.heightScale_pos.le)
        (Real.rpow_nonneg hX.le _)
    _ = _ := by ring

theorem completedT_endpoint_reflected_bound
    (W : ℝ → ℂ) (v0 v1 : ℝ) (hv0 : 0 < v0)
    (hWs : Function.support W ⊆ Set.Icc v0 v1) (hW : ContDiff ℝ ∞ W) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (Ψ : Eis →* ℂ), (∀ x, ‖Ψ x‖ ≤ 1) →
      ∀ (Q : Ideal Eis), CanonicalCoefficientClass.FactorsModulo Q Ψ →
      ∀ (c : Eis), c ≠ 0 → Ideal.span {c} ≤ Ideal.span {(9:Eis)}*Q →
      ∀ (X : ℝ), 0 < X →
      ‖completedT Ψ W X‖ ≤ C * (Ideal.absNorm (Ideal.span {c}):ℝ)^(3/2:ℝ) * X^(-(1/2):ℝ) := by
  obtain ⟨K, hK, hk⟩ := smoothedKernel_endpoint_bound W v0 v1 hv0 hWs hW
  refine ⟨‖thetaDerivativeScalar⁻¹‖*K, mul_nonneg (norm_nonneg _) hK, ?_⟩
  intro Ψ hΨ Q hperiod c hc hcQ X hX
  let : Finite (Eis ⧸ Ideal.span {c}) := finite_quotient_span hc
  let : Fintype (Eis ⧸ Ideal.span {c}) := Fintype.ofFinite _
  let R : ℝ := (Ideal.absNorm (Ideal.span {c}):ℝ)
  have hcard : (Fintype.card (Eis ⧸ Ideal.span {c}):ℝ) = R := by
    congr 1
    rw [← Nat.card_eq_fintype_card, ← Submodule.cardQuot_apply, ← Ideal.absNorm_apply]
  have hR : 0 < R := by
    rw [← hcard]
    exact_mod_cast Fintype.card_pos (α := Eis ⧸ Ideal.span {c})
  let a : (Eis ⧸ Ideal.span {c}) → ℂ :=
    finiteAdditiveFourierCoeff (quotientTrace c hc) (fixedThetaQuotient Ψ c)
  have hparseval : (∑ h, ‖a h‖)^2 ≤ R := by
    rw [← hcard]
    exact QRHExperimental.FiniteFourierMass.normalized_fourier_l1_sq_le_card
      (quotientTrace c hc) (GeneralPrimitiveTrace.eisTraceModChar_breveE_primitive c hc)
      (fixedThetaQuotient Ψ c) (fixedThetaQuotient_norm_le_one Ψ hΨ c)
  have hl1 : (∑ h, ‖a h‖) ≤ Real.sqrt R := by
    have hn : 0 ≤ ∑ h, ‖a h‖ := Finset.sum_nonneg (fun _ _ => norm_nonneg _)
    have hr := Real.sq_sqrt hR.le
    have hr0 := Real.sqrt_nonneg R
    nlinarith
  have hkernel (h : Eis ⧸ Ideal.span {c}) :
      ‖(finiteTwistCusp c hc h).smoothedKernel W X‖ ≤ K*R*X^(-(1/2):ℝ) := by
    apply (hk (finiteTwistCusp c hc h) X hX).trans
    exact mul_le_mul_of_nonneg_right
      (mul_le_mul_of_nonneg_left
        (QRHExperimental.CuspHeight.finiteTwistCusp_heightScale_le c hc h) hK)
      (Real.rpow_nonneg hX.le _)
  have hsum : ‖∑ h, a h * (finiteTwistCusp c hc h).smoothedKernel W X‖ ≤
      K*R^(3/2:ℝ)*X^(-(1/2):ℝ) := by
    calc
      _ ≤ ∑ h, ‖a h * (finiteTwistCusp c hc h).smoothedKernel W X‖ := norm_sum_le _ _
      _ ≤ ∑ h, ‖a h‖*(K*R*X^(-(1/2):ℝ)) := by
        apply Finset.sum_le_sum
        intro h hh
        rw [norm_mul]
        exact mul_le_mul_of_nonneg_left (hkernel h) (norm_nonneg _)
      _ = (∑ h, ‖a h‖)*(K*R*X^(-(1/2):ℝ)) := (Finset.sum_mul _ _ _).symm
      _ ≤ Real.sqrt R*(K*R*X^(-(1/2):ℝ)) :=
        mul_le_mul_of_nonneg_right hl1 (by positivity)
      _ = _ := by
        rw [Real.sqrt_eq_rpow, show (3/2:ℝ)=(1/2:ℝ)+1 by norm_num,
          Real.rpow_add_one hR.ne']
        ring
  rw [completedT_canonical_smoothed_reflection Ψ hΨ Q hperiod c hc hcQ
    W v0 v1 hv0 hWs hW X hX, norm_mul]
  exact (mul_le_mul_of_nonneg_left hsum (norm_nonneg _)).trans_eq (by ring)

theorem completedT_endpoint_period_bound
    (W : ℝ → ℂ) (v0 v1 : ℝ) (hv0 : 0 < v0)
    (hWs : Function.support W ⊆ Set.Icc v0 v1) (hW : ContDiff ℝ ∞ W) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (Ψ : Eis →* ℂ), (∀ x, ‖Ψ x‖ ≤ 1) →
      ∀ (Q : Ideal Eis), Q ≠ 0 → CanonicalCoefficientClass.FactorsModulo Q Ψ →
      ∀ (X : ℝ), 0 < X →
      ‖completedT Ψ W X‖ ≤ C * (Ideal.absNorm Q:ℝ)^(3/2:ℝ) * X^(-(1/2):ℝ) := by
  obtain ⟨K, hK, hk⟩ := completedT_endpoint_reflected_bound W v0 v1 hv0 hWs hW
  refine ⟨K*(81:ℝ)^(3/2:ℝ), by positivity, ?_⟩
  intro Ψ hΨ Q hQ hperiod X hX
  obtain ⟨c, hc, heq, hnorm⟩ := QRHExperimental.IdealConductorBound.period_generator Q hQ
  have hb := hk Ψ hΨ Q hperiod c hc heq.le X hX
  rw [hnorm, Real.mul_rpow (by norm_num) (Nat.cast_nonneg _)] at hb
  exact hb.trans_eq (by ring)

theorem rawProjection_three_quarters
    (W : ℝ → ℂ) (v0 v1 : ℝ) (hv0 : 0 < v0)
    (hWs : Function.support W ⊆ Set.Icc v0 v1) (hW : ContDiff ℝ ∞ W) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (Ψ : Eis →* ℂ), (∀ x, ‖Ψ x‖ ≤ 1) →
      ∀ (Q : Ideal Eis), Q ≠ 0 → CanonicalCoefficientClass.FactorsModulo Q Ψ →
      ∀ (L : ℝ), 0 < L →
      ‖rawProjection Ψ W L‖ ≤ C * Real.sqrt L * (Ideal.absNorm Q:ℝ)^(3/4:ℝ) := by
  obtain ⟨K0, hK0, h0⟩ := QRHExperimental.UniformTrivial.uniform_trivial_bounds
    W v0 v1 hWs hW.continuous
  obtain ⟨K1, hK1, h1⟩ := completedT_endpoint_period_bound W v0 v1 hv0 hWs hW
  refine ⟨513*K0+128*K1, by positivity, ?_⟩
  intro Ψ hΨ Q hQ hperiod L hL
  apply rawProjection_bound_of_completed_bounds Ψ hΨ W
    (HasCompactSupport.of_support_subset_isCompact isCompact_Icc hWs)
    L (Ideal.absNorm Q:ℝ) (3/4) (1/2) K0 K1 hL
    (nonzeroIdeal_norm_pos ⟨Q,hQ⟩) (by norm_num) hK0 hK1 (h0 Ψ hΨ L hL).1
    (fun y hy => (h0 Ψ hΨ y hy).2)
  simpa only [show (3/4:ℝ)*(2*(1/2)+1)=3/2 by norm_num] using h1 Ψ hΨ Q hQ hperiod

#print axioms smoothedKernel_endpoint_bound
#print axioms completedT_endpoint_period_bound
#print axioms rawProjection_three_quarters
end
end QRHExperimental.EndpointProjection
