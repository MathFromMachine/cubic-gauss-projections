import FiniteFourierMass
import UniformReflectionBound
import OAI.NumberTheory.DirichletL.Eisenstein.FixedFrequencyExpansion
import OAI.NumberTheory.DirichletL.Eisenstein.FixedThetaTwists

/-! Quantitative fixed-base costs for the actual finite Fourier assembly. -/
namespace QRHExperimental.FiniteBaseBounds
noncomputable section
open OAI OAI.ActualEisensteinCubic OAI.ConcreteTraceCRT
open OAI.CubicEisenstein OAI.CompletedGauss OAI.CanonicalRowCompletion
open scoped BigOperators Classical
local notation "Eis" => OAI.ActualEisensteinCubic.O
set_option maxHeartbeats 1500000

lemma principal_norm_pos (c : Eis) (hc : c ≠ 0) :
    0 < (Ideal.absNorm (Ideal.span {c}):ℝ) := by
  exact_mod_cast Nat.pos_of_ne_zero (fun hz => hc
    (Ideal.span_singleton_eq_bot.mp (Ideal.absNorm_eq_zero_iff.mp hz)))

theorem fixed_fourier_l1_bound (c : Eis) (hc : c ≠ 0)
    [Fintype (Eis ⧸ Ideal.span {c})] (φ : Eis →* ℂ) (hφ : ∀ n, ‖φ n‖ ≤ 1) :
    (∑ h, ‖fixedThetaRowCoeff c hc φ h‖) ≤
      Real.sqrt (Ideal.absNorm (Ideal.span {c}):ℝ) := by
  have hcard : (Fintype.card (Eis ⧸ Ideal.span {c}):ℝ) =
      (Ideal.absNorm (Ideal.span {c}):ℝ) := by
    congr 1
    rw [← Nat.card_eq_fintype_card, ← Submodule.cardQuot_apply, ← Ideal.absNorm_apply]
  have h := QRHExperimental.FiniteFourierMass.normalized_fourier_l1_sq_le_card
    (quotientTrace c hc) (GeneralPrimitiveTrace.eisTraceModChar_breveE_primitive c hc)
    (fixedThetaQuotient φ c) (fixedThetaQuotient_norm_le_one φ hφ c)
  change (∑ h, ‖fixedThetaRowCoeff c hc φ h‖)^2 ≤ _ at h
  rw [hcard] at h
  have hn : 0 ≤ ∑ h, ‖fixedThetaRowCoeff c hc φ h‖ :=
    Finset.sum_nonneg (fun _ _ => norm_nonneg _)
  have hs := Real.sq_sqrt (principal_norm_pos c hc).le
  have hs0 := Real.sqrt_nonneg (Ideal.absNorm (Ideal.span {c}):ℝ)
  nlinarith

theorem cusp_scale_power_le (j : Fin 3) (c0 c z : Eis)
    (hc0 : c0 ≠ 0) (hc : c ≠ 0) (hz : z ≠ 0) (hdiv : c0 ∣ c)
    (X : ℝ) (hX : 0 < X) :
    (X/(27*(sourceCuspScale j)^2*
      (Ideal.absNorm (Ideal.span {c0*z}):ℝ)^2))^(-(1/2):ℝ) ≤
        16*(Ideal.absNorm (Ideal.span {c}):ℝ)*
          (Ideal.absNorm (Ideal.span {z}):ℝ)*X^(-(1/2):ℝ) := by
  have hcprod := principal_norm_pos (c0*z) (mul_ne_zero hc0 hz)
  have hscale : 0 < 27*(sourceCuspScale j)^2 := by
    have := sourceCuspScale_pos j
    positivity
  have he := QRHExperimental.UniformReflectionBound.kernel_argument_power
    (27*(sourceCuspScale j)^2) (Ideal.absNorm (Ideal.span {c0*z}):ℝ) X
    1 (1/2) hscale hcprod hX (by norm_num)
  norm_num only [mul_one, Real.one_rpow, show (2:ℝ)*(1/2)=1 by norm_num,
    Real.rpow_one] at he
  have hb : (27*(sourceCuspScale j)^2)^(1/2:ℝ) ≤ 16 := by
    rw [← Real.sqrt_eq_rpow]
    apply (Real.sqrt_le_iff).mpr
    constructor
    · norm_num
    · have hs : (sourceCuspScale j)^2 ≤ 9 := by
        fin_cases j <;> norm_num [sourceCuspScale]
      nlinarith
  have hn : (Ideal.absNorm (Ideal.span {c0*z}):ℝ) =
      (Ideal.absNorm (Ideal.span {c0}):ℝ)*(Ideal.absNorm (Ideal.span {z}):ℝ) := by
    rw [← Ideal.span_singleton_mul_span_singleton, map_mul, Nat.cast_mul]
  have hd := divisor_principal_norm_le c0 c hc hdiv
  rw [he,hn]
  calc
    _ ≤ 16*((Ideal.absNorm (Ideal.span {c0}):ℝ)*
          (Ideal.absNorm (Ideal.span {z}):ℝ))*X^(-(1/2):ℝ) := by gcongr
    _ ≤ 16*((Ideal.absNorm (Ideal.span {c}):ℝ)*
          (Ideal.absNorm (Ideal.span {z}):ℝ))*X^(-(1/2):ℝ) := by gcongr
    _ = _ := by ring

theorem fixed_base_sum_bound (c : Eis) (hc : c ≠ 0)
    [Fintype (Eis ⧸ Ideal.span {c})] (φ : Eis →* ℂ) (hφ : ∀ n, ‖φ n‖ ≤ 1)
    (f : (Eis ⧸ Ideal.span {c}) → ℂ) (K Q X : ℝ)
    (hK : 0 ≤ K) (hQ : 0 ≤ Q) (hX : 0 < X)
    (hf : ∀ h, ‖f h‖ ≤ K*(Ideal.absNorm (Ideal.span {c}):ℝ)*Q*X^(-(1/2):ℝ)) :
    ‖thetaDerivativeScalar⁻¹ * ∑ h, fixedThetaRowCoeff c hc φ h * f h‖ ≤
      (‖thetaDerivativeScalar⁻¹‖*K)*(Ideal.absNorm (Ideal.span {c}):ℝ)^(3/2:ℝ)*
        Q*X^(-(1/2):ℝ) := by
  have hR := principal_norm_pos c hc
  rw [norm_mul]
  apply (mul_le_mul_of_nonneg_left (norm_sum_le _ _) (norm_nonneg _)).trans
  calc
    _ ≤ ‖thetaDerivativeScalar⁻¹‖ *
      ∑ h, ‖fixedThetaRowCoeff c hc φ h‖ *
        (K*(Ideal.absNorm (Ideal.span {c}):ℝ)*Q*X^(-(1/2):ℝ)) := by
      apply mul_le_mul_of_nonneg_left _ (norm_nonneg _)
      exact Finset.sum_le_sum (fun h _ => by
        rw [norm_mul]
        exact mul_le_mul_of_nonneg_left (hf h) (norm_nonneg _))
    _ = ‖thetaDerivativeScalar⁻¹‖ * (∑ h, ‖fixedThetaRowCoeff c hc φ h‖) *
        (K*(Ideal.absNorm (Ideal.span {c}):ℝ)*Q*X^(-(1/2):ℝ)) := by
      rw [← Finset.sum_mul]; ring
    _ ≤ ‖thetaDerivativeScalar⁻¹‖ * Real.sqrt (Ideal.absNorm (Ideal.span {c}):ℝ) *
        (K*(Ideal.absNorm (Ideal.span {c}):ℝ)*Q*X^(-(1/2):ℝ)) := by
      gcongr
      exact fixed_fourier_l1_bound c hc φ hφ
    _ = _ := by
      rw [Real.sqrt_eq_rpow, show (3/2:ℝ)=(1/2:ℝ)+1 by norm_num,
        Real.rpow_add_one hR.ne']
      ring

#print axioms fixed_fourier_l1_bound
#print axioms cusp_scale_power_le
#print axioms fixed_base_sum_bound
end
end QRHExperimental.FiniteBaseBounds
