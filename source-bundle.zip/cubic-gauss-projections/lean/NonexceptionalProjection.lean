import ControlledReflectionBound
import ActiveStratumSum
import FiniteBaseBounds
import CubeInverseAssembly

/-! Complete nonexceptional moving-prime projection. The exact active
strata and fixed Fourier coefficients precede every norm estimate. -/
namespace QRHExperimental.NonexceptionalProjection
noncomputable section
open OAI OAI.ActualEisensteinCubic OAI.ConcreteTraceCRT
open OAI.CubicEisenstein OAI.CompletedGauss OAI.CanonicalRowCompletion
open OAI.CanonicalQuadraticSieve
open QRHExperimental.TrivialProjection QRHExperimental.CubeInverseAssembly
open QRHExperimental.FiniteBaseBounds
open scoped BigOperators Classical ContDiff
set_option maxHeartbeats 3000000
local notation "Eis" => OAI.ActualEisensteinCubic.O

def movingRadical (I Q : Ideal Eis) : Ideal Eis :=
  ∏ P : FreePrimeIndex I Q, P.val.val

def movingNorm (I Q : Ideal Eis) : ℝ := Ideal.absNorm (movingRadical I Q)

def freeExponent (I Q : Ideal Eis) (P : FreePrimeIndex I Q) : ℕ :=
  (UniqueFactorizationMonoid.normalizedFactors I).count P.val.val % 6

lemma movingNorm_pos (I Q : Ideal Eis) : 0 < movingNorm I Q := by
  unfold movingNorm movingRadical
  exact_mod_cast Nat.pos_of_ne_zero (fun hz =>
    (finite_prime_product_ne_bot (fun P : FreePrimeIndex I Q => P.val.val))
      (Ideal.absNorm_eq_zero_iff.mp hz))

lemma freeExponent_lt (I Q : Ideal Eis) (P : FreePrimeIndex I Q) :
    freeExponent I Q P < 6 := Nat.mod_lt _ (by decide)

/-- Uniformity includes the ideal family and both moduli. Exponents zero
and four are excluded explicitly; all zero-extension masks remain. -/
theorem completedT_nonexceptional_reflected_bound
    (W : ℝ → ℂ) (lo hi : ℝ) (hlo : 0 < lo)
    (hsupp : Function.support W ⊆ Set.Icc lo hi) (hW : ContDiff ℝ ∞ W) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (I Q : Ideal Eis) (hI : Supported I),
      Q ≠ 0 →
      (∀ P : FreePrimeIndex I Q, freeExponent I Q P ≠ 0) →
      (∀ P : FreePrimeIndex I Q, freeExponent I Q P ≠ 4) →
      ∀ (c : Eis), c ≠ 0 → Ideal.span {c} = Ideal.span {(9:Eis)}*Q →
      ∀ (φ : Eis →* ℂ), CanonicalCoefficientClass.FactorsModulo Q φ →
      (∀ n, ‖φ n‖ ≤ 1) → ∀ X : ℝ, 0 < X →
      ‖completedT (φ*freePrimeRow I hI Q) W X‖ ≤
        C*(Ideal.absNorm (Ideal.span {c}):ℝ)^(3/2:ℝ)*movingNorm I Q*
          X^(-(1/2):ℝ) := by
  obtain ⟨K,hK,hbound⟩ :=
    QRHExperimental.ControlledReflectionBound.smoothedValue_nonexceptional_uniform_bound
      W lo hi hlo hsupp hW
  refine ⟨‖thetaDerivativeScalar⁻¹‖*(K*16), by positivity, ?_⟩
  intro I Q hI hQ hj0 hj4 c hc hcQ φ hφ hφn X hX
  letI : Finite (Eis ⧸ Ideal.span {c}) := finite_quotient_span hc
  letI : Fintype (Eis ⧸ Ideal.span {c}) := Fintype.ofFinite _
  letI : ∀ P : FreePrimeIndex I Q,
      (Ideal.span {freePrimaryPrime I Q P}:Ideal Eis).IsMaximal :=
    freePrimaryPrime_maximal I Q hI
  let G : ∀ h : Eis ⧸ Ideal.span {c}, FixedFourierGeometry c h :=
    fixedFourierGeometry c hc
  let f : (Eis ⧸ Ideal.span {c}) → Finset (FreePrimeIndex I Q) → ℂ := fun h A =>
    (freePrimaryControlledStratum I Q hI c hcQ h (G h) A).smoothedValue
      (mul_dvd_mul_left 9 (G h).denominator_dvd)
      (primary_finset_product Finset.univ (fun P:A => freePrimaryPrime I Q P.val)
        (fun P _ => freePrimaryPrime_primary I Q hI P.val))
      (G h).primary (G h).shape (fun P => freePrimaryPrime_ne_zero I Q hI P.val)
      (G h).denominator_ne_zero (fun P => freePrimaryPrime_good I Q hI P.val)
      (fun P => freeExponent I Q P.val) W X
  have hf (h : Eis ⧸ Ideal.span {c}) :
      ‖f h Finset.univ‖ ≤ (K*16)*(Ideal.absNorm (Ideal.span {c}):ℝ)*
        movingNorm I Q*X^(-(1/2):ℝ) := by
    let A : Finset (FreePrimeIndex I Q) := Finset.univ
    let z : Eis := ∏ P : A, freePrimaryPrime I Q P.val
    have hz : z ≠ 0 := Finset.prod_ne_zero_iff.mpr
      (fun P _ => freePrimaryPrime_ne_zero I Q hI P.val)
    have hzspan : (Ideal.span {z}:Ideal Eis) = movingRadical I Q := by
      have he : z = ∏ P : FreePrimeIndex I Q, freePrimaryPrime I Q P := by
        simp [z,A]
      rw [he,freePrimaryPrime_product_span I Q hI]
      rfl
    have hcop : Pairwise (Function.onFun IsCoprime
        (fun P : A => (Ideal.span {freePrimaryPrime I Q P.val}:Ideal Eis))) := by
      intro P R hPR
      exact freePrimaryPrime_coprime I Q hI (fun he => hPR (Subtype.ext he))
    have hb := hbound A (fun P : A => freePrimaryPrime I Q P.val)
      (9*c) (G h).a0 (G h).c0 (G h).mode
      (freePrimaryControlledStratum I Q hI c hcQ h (G h) A)
      (mul_dvd_mul_left 9 (G h).denominator_dvd)
      (primary_finset_product Finset.univ (fun P:A => freePrimaryPrime I Q P.val)
        (fun P _ => freePrimaryPrime_primary I Q hI P.val))
      (G h).primary (G h).shape (fun P => freePrimaryPrime_ne_zero I Q hI P.val)
      (G h).denominator_ne_zero hcop (fun P => freePrimaryPrime_good I Q hI P.val)
      (fun P => freePrimaryPrime_odd I Q hI P.val)
      (fun P => freeExponent I Q P.val) (fun P => freeExponent_lt I Q P.val)
      (fun P => hj0 P.val) (fun P => hj4 P.val) X hX
    have hs := cusp_scale_power_le (G h).shape.index (G h).c0 c z
      (G h).denominator_ne_zero hc hz (G h).denominator_dvd X hX
    calc
      _ ≤ K*(X/(27*(sourceCuspScale (G h).shape.index)^2*
          (Ideal.absNorm (Ideal.span {(G h).c0*z}):ℝ)^2))^(-(1/2):ℝ) := hb
      _ ≤ K*(16*(Ideal.absNorm (Ideal.span {c}):ℝ)*
          (Ideal.absNorm (Ideal.span {z}):ℝ)*X^(-(1/2):ℝ)) :=
        mul_le_mul_of_nonneg_left hs hK
      _ = _ := by rw [hzspan]; unfold movingNorm; ring
  rw [fixedFree_completedT_eq_actualControlledSource I Q hI hQ c hc hcQ G
    φ hφ hφn W lo hi hlo hsupp hW X hX]
  change ‖thetaDerivativeScalar⁻¹ * ∑ h, fixedThetaRowCoeff c hc φ h *
    ∑ A : Finset (FreePrimeIndex I Q),
      primeInactiveFourierWeight (freePrimaryPrime I Q)
        (freePrimaryPrime_ne_zero I Q hI) (freePrimaryPrime_good I Q hI)
        (freeExponent I Q) A * f h A‖ ≤ _
  simp_rw [QRHExperimental.ActiveStratumSum.nonzero_exponents_collapse
    (freePrimaryPrime I Q) (freePrimaryPrime_ne_zero I Q hI)
    (freePrimaryPrime_good I Q hI) (freePrimaryPrime_odd I Q hI)
    (freeExponent I Q) (freeExponent_lt I Q) hj0]
  exact fixed_base_sum_bound c hc φ hφn (fun h => f h Finset.univ)
    (K*16) (movingNorm I Q) X (by positivity) (movingNorm_pos I Q).le hX hf

theorem completedT_nonexceptional_period_bound
    (W : ℝ → ℂ) (lo hi : ℝ) (hlo : 0 < lo)
    (hsupp : Function.support W ⊆ Set.Icc lo hi) (hW : ContDiff ℝ ∞ W) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (I Q : Ideal Eis) (hI : Supported I),
      Q ≠ 0 →
      (∀ P : FreePrimeIndex I Q, freeExponent I Q P ≠ 0) →
      (∀ P : FreePrimeIndex I Q, freeExponent I Q P ≠ 4) →
      ∀ (φ : Eis →* ℂ), CanonicalCoefficientClass.FactorsModulo Q φ →
      (∀ n, ‖φ n‖ ≤ 1) → ∀ X : ℝ, 0 < X →
      ‖completedT (φ*freePrimeRow I hI Q) W X‖ ≤
        C*(Ideal.absNorm Q:ℝ)^(3/2:ℝ)*movingNorm I Q*X^(-(1/2):ℝ) := by
  obtain ⟨K,hK,hb⟩ := completedT_nonexceptional_reflected_bound W lo hi hlo hsupp hW
  refine ⟨K*(81:ℝ)^(3/2:ℝ), by positivity, ?_⟩
  intro I Q hI hQ hj0 hj4 φ hφ hφn X hX
  obtain ⟨c,hc,heq,hnorm⟩ := QRHExperimental.IdealConductorBound.period_generator Q hQ
  have h := hb I Q hI hQ hj0 hj4 c hc heq φ hφ hφn X hX
  rw [hnorm,Real.mul_rpow (by norm_num) (Nat.cast_nonneg _)] at h
  exact h.trans_eq (by ring)

theorem rawProjection_nonexceptional
    (W : ℝ → ℂ) (lo hi : ℝ) (hlo : 0 < lo)
    (hsupp : Function.support W ⊆ Set.Icc lo hi) (hW : ContDiff ℝ ∞ W) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (I Q : Ideal Eis) (hI : Supported I),
      Q ≠ 0 →
      (∀ P : FreePrimeIndex I Q, freeExponent I Q P ≠ 0) →
      (∀ P : FreePrimeIndex I Q, freeExponent I Q P ≠ 4) →
      ∀ (φ : Eis →* ℂ), CanonicalCoefficientClass.FactorsModulo Q φ →
      (∀ n, ‖φ n‖ ≤ 1) → ∀ L : ℝ, 0 < L →
      ‖rawProjection (φ*freePrimeRow I hI Q) W L‖ ≤
        C*Real.sqrt L*(Ideal.absNorm Q:ℝ)^(3/4:ℝ)*(movingNorm I Q)^(1/2:ℝ) := by
  obtain ⟨K0,hK0,h0⟩ := QRHExperimental.UniformTrivial.uniform_trivial_bounds
    W lo hi hsupp hW.continuous
  obtain ⟨K1,hK1,h1⟩ := completedT_nonexceptional_period_bound W lo hi hlo hsupp hW
  refine ⟨513*K0+128*K1, by positivity, ?_⟩
  intro I Q hI hQ hj0 hj4 φ hφ hφn L hL
  let Ψ := φ*freePrimeRow I hI Q
  have hΨ : ∀ n, ‖Ψ n‖ ≤ 1 := fixedFreeRow_norm I hI Q φ hφn
  let R : ℝ := (Ideal.absNorm Q:ℝ)^(3/2:ℝ)*movingNorm I Q
  have hQpos : 0 < (Ideal.absNorm Q:ℝ) :=
    nonzeroIdeal_norm_pos ⟨Q,hQ⟩
  have hR : 0 < R := mul_pos (Real.rpow_pos_of_pos hQpos _) (movingNorm_pos I Q)
  have hb := rawProjection_bound_of_completed_bounds Ψ hΨ W
    (HasCompactSupport.of_support_subset_isCompact isCompact_Icc hsupp)
    L R (1/2) (1/2) K0 K1 hL hR (by norm_num) hK0 hK1
    (h0 Ψ hΨ L hL).1 (fun y hy => (h0 Ψ hΨ y hy).2)
    (by
      intro y hy
      simpa only [show (1/2:ℝ)*(2*(1/2)+1)=1 by norm_num, Real.rpow_one,
        R,mul_assoc] using h1 I Q hI hQ hj0 hj4 φ hφ hφn y hy)
  have he : R^(1/2:ℝ) =
      (Ideal.absNorm Q:ℝ)^(3/4:ℝ)*(movingNorm I Q)^(1/2:ℝ) := by
    dsimp only [R]
    rw [Real.mul_rpow (Real.rpow_nonneg hQpos.le _) (movingNorm_pos I Q).le,
      ←Real.rpow_mul hQpos.le]
    norm_num
  rw [he] at hb
  exact hb.trans_eq (by ring)

#print axioms completedT_nonexceptional_reflected_bound
#print axioms completedT_nonexceptional_period_bound
#print axioms rawProjection_nonexceptional
end
end QRHExperimental.NonexceptionalProjection
