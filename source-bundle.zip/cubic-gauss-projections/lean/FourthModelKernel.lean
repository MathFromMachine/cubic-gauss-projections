import ModelKernelMass
import GoodPrimeRadialMass

/-! Positive kernel estimate for the three exact fourth-bracket branches.
The coefficient majorant is stated explicitly; the actual source adapter
is separate. One uniform constant is used before the moving prime. -/
namespace QRHExperimental.FourthModelKernel
noncomputable section
open OAI OAI.ActualEisensteinCubic OAI.CubicEisenstein OAI.CompletedGauss
open QRHExperimental.IdealPowerSums QRHExperimental.SparseRadialSummability
open QRHExperimental.ModelKernelMass QRHExperimental.WeightedKernelBound
open QRHExperimental.GoodPrimeRadialMass
open scoped BigOperators Classical ContDiff
set_option maxHeartbeats 1800000

lemma divisorModelWeight_nonneg (D E : NonzeroIdeal) (t : ThetaFullIndex) :
    0 ≤ divisorModelWeight D E t := by
  unfold divisorModelWeight sparseWeight
  split <;> positivity

lemma divisor_weight_sqrt_mass (D E : NonzeroIdeal) :
    SqrtMassBound (divisorModelWeight D E) modelRadius
      (divisorMassConstant*(idealNorm D)^(-1:ℝ)*(idealNorm E)^(-(5/2):ℝ)) := by
  have hb (t : ThetaFullIndex) : ‖(divisorModelWeight D E t : ℂ)‖ = divisorModelWeight D E t := by
    rw [Complex.norm_real,Real.norm_of_nonneg (divisorModelWeight_nonneg D E t)]
  have hm := model_divisor_sqrt_mass D E (fun t => (divisorModelWeight D E t:ℂ))
    (fun t => (hb t).le)
  simpa only [hb] using hm

def fourthModelWeight (P : NonzeroIdeal) (t : ThetaFullIndex) : ℝ :=
  (idealNorm P)^(-(1/2):ℝ)*divisorModelWeight oneIdeal oneIdeal t +
    (idealNorm P)^(1/2:ℝ)*divisorModelWeight P oneIdeal t +
    (idealNorm P)^(1/2:ℝ)*divisorModelWeight oneIdeal P t

lemma fourthModelWeight_eq (P : NonzeroIdeal) (t : ThetaFullIndex) :
    fourthModelWeight P t =
      (idealNorm P)^(-(1/2):ℝ)*sparseWeight 0 t +
        (idealNorm P)^(1/2:ℝ)*divisorModelWeight P oneIdeal t +
        (idealNorm P)^(1/2:ℝ)*divisorModelWeight oneIdeal P t := by
  simp only [fourthModelWeight,divisorModelWeight,oneIdeal,one_dvd,and_true,true_and,ite_true]

def fourthCost (q : ℝ) : ℝ :=
  q^(-(1/2):ℝ) + q^(1/2:ℝ)*q^(-1:ℝ) + q^(1/2:ℝ)*q^(-(5/2):ℝ)

lemma fourthCost_nonneg (q : ℝ) (hq : 0 ≤ q) : 0 ≤ fourthCost q := by
  unfold fourthCost; positivity

lemma fourthCost_eq (q : ℝ) (hq : 0 < q) :
    fourthCost q = 2*q^(-(1/2):ℝ)+q^(-2:ℝ) := by
  unfold fourthCost
  rw [← Real.rpow_add hq, ← Real.rpow_add hq]
  norm_num
  ring

lemma fourthCost_le (q : ℝ) (hq : 1 ≤ q) :
    fourthCost q ≤ 3*q^(-(1/2):ℝ) := by
  rw [fourthCost_eq q (zero_lt_one.trans_le hq)]
  have h := Real.rpow_le_rpow_of_exponent_le hq (show (-2:ℝ) ≤ -(1/2:ℝ) by norm_num)
  linarith

theorem fourth_model_sqrt_mass (P : NonzeroIdeal) (b : ThetaFullIndex → ℂ)
    (hb : ∀ t, ‖b t‖ ≤ fourthModelWeight P t) :
    SqrtMassBound (fun t => ‖b t‖) modelRadius
      (divisorMassConstant*fourthCost (idealNorm P)) := by
  intro S T hT hS
  have h0 := divisor_weight_sqrt_mass oneIdeal oneIdeal S T hT hS
  have hI := divisor_weight_sqrt_mass P oneIdeal S T hT hS
  have hJ := divisor_weight_sqrt_mass oneIdeal P S T hT hS
  have hOne : idealNorm oneIdeal = 1 := by simp [oneIdeal,idealNorm]
  simp only [hOne,Real.one_rpow,mul_one] at h0 hI hJ
  calc
    _ ≤ ∑ t ∈ S, fourthModelWeight P t := Finset.sum_le_sum (fun t _ => hb t)
    _ = (idealNorm P)^(-(1/2):ℝ)*(∑ t ∈ S, divisorModelWeight oneIdeal oneIdeal t) +
        (idealNorm P)^(1/2:ℝ)*(∑ t ∈ S, divisorModelWeight P oneIdeal t) +
        (idealNorm P)^(1/2:ℝ)*(∑ t ∈ S, divisorModelWeight oneIdeal P t) := by
      simp only [fourthModelWeight,Finset.sum_add_distrib,Finset.mul_sum]
    _ ≤ (idealNorm P)^(-(1/2):ℝ)*(divisorMassConstant*T^(1/2:ℝ)) +
        (idealNorm P)^(1/2:ℝ)*(divisorMassConstant*(idealNorm P)^(-1:ℝ)*T^(1/2:ℝ)) +
        (idealNorm P)^(1/2:ℝ)*(divisorMassConstant*(idealNorm P)^(-(5/2):ℝ)*T^(1/2:ℝ)) :=
      add_le_add (add_le_add (mul_le_mul_of_nonneg_left h0 (by positivity))
        (mul_le_mul_of_nonneg_left hI (by positivity)))
        (mul_le_mul_of_nonneg_left hJ (by positivity))
    _ = _ := by unfold fourthCost; ring

theorem fourth_model_paperKernel_bound
    (W : ℝ → ℂ) (lo hi : ℝ) (hlo : 0 < lo)
    (hsupp : Function.support W ⊆ Set.Icc lo hi) (hW : ContDiff ℝ ∞ W) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (P : NonzeroIdeal) (b : ThetaFullIndex → ℂ),
      (∀ t, ‖b t‖ ≤ fourthModelWeight P t) → ∀ v : ℝ, 0 < v →
      Summable (fun t => ‖b t * CubicReflectionKernel.paperKernel (Vstar W) (v*modelRadius t)‖) ∧
      ‖∑' t, b t * CubicReflectionKernel.paperKernel (Vstar W) (v*modelRadius t)‖ ≤
        C*fourthCost (idealNorm P)*v^(-(1/2):ℝ) := by
  obtain ⟨A,hA,hsmall,hlarge⟩ :=
    QRHExperimental.EndpointProjection.paperKernel_two_sided_bound W lo hi hlo hsupp hW
  refine ⟨5*divisorMassConstant*A, by positivity [divisorMassConstant_nonneg], ?_⟩
  intro P b hb v hv
  have hc : 0 ≤ divisorMassConstant*fourthCost (idealNorm P) :=
    mul_nonneg divisorMassConstant_nonneg (fourthCost_nonneg _ (nonzeroIdeal_norm_pos P).le)
  have h := kernel_summable_and_bound b modelRadius _ A hc hA modelRadius_pos
    (fourth_model_sqrt_mass P b hb) _ hsmall hlarge v hv
  refine ⟨h.1,h.2.trans_eq ?_⟩
  ring

#print axioms fourth_model_sqrt_mass
#print axioms fourth_model_paperKernel_bound
#print axioms fourthCost_eq
#print axioms fourthCost_le
end
end QRHExperimental.FourthModelKernel
