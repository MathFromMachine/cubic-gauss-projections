import FourthModelKernel
import BranchMass

/-! Simultaneous divisor densities for arbitrary finite coprime families.
The same cumulative constant is used for every local branch choice.
The actual character-bracket domination is a separate adapter. -/
namespace QRHExperimental.CompositeModelKernel
noncomputable section
open OAI OAI.ActualEisensteinCubic OAI.CubicEisenstein OAI.CompletedGauss
open QRHExperimental.IdealPowerSums QRHExperimental.SparseRadialSummability
open QRHExperimental.ModelKernelMass QRHExperimental.WeightedKernelBound
open QRHExperimental.FourthModelKernel QRHExperimental.BranchMass
open scoped BigOperators Classical ContDiff
set_option maxHeartbeats 2500000
local notation "Eis" => OAI.ActualEisensteinCubic.O

variable {ι : Type*} [Fintype ι]

def selectedDivisor (P : ι → NonzeroIdeal) (f : ι → Fin 3) (k : Fin 3) : NonzeroIdeal :=
  ⟨∏ i, if f i = k then (P i).val else 1,
    Finset.prod_ne_zero_iff.mpr (fun i _ => by
      split_ifs
      · exact (P i).property
      · exact one_ne_zero)⟩

lemma selectedDivisor_dvd_iff (P : ι → NonzeroIdeal)
    (hcop : Pairwise (fun i j => IsCoprime (P i).val (P j).val))
    (f : ι → Fin 3) (k : Fin 3) (I : Ideal Eis) :
    (selectedDivisor P f k).val ∣ I ↔ ∀ i, f i = k → (P i).val ∣ I := by
  constructor
  · intro h i hi
    have hd := (Finset.dvd_prod_of_mem (fun j => if f j = k then (P j).val else 1)
      (Finset.mem_univ i)).trans h
    simpa only [if_pos hi] using hd
  · intro h
    apply Fintype.prod_dvd_of_coprime
    · intro i j hij
      change IsCoprime (if f i = k then (P i).val else 1)
        (if f j = k then (P j).val else 1)
      by_cases hi : f i = k <;> by_cases hj : f j = k
      · simpa only [if_pos hi,if_pos hj] using hcop hij
      · simp only [if_pos hi,if_neg hj]; exact isCoprime_one_right
      · simp only [if_neg hi,if_pos hj]; exact isCoprime_one_left
      · simp only [if_neg hi,if_neg hj]; exact isCoprime_one_left
    · intro i
      split_ifs with hi
      · exact h i hi
      · exact one_dvd _

lemma selectedDivisor_norm (P : ι → NonzeroIdeal) (f : ι → Fin 3) (k : Fin 3) :
    idealNorm (selectedDivisor P f k) = ∏ i, if f i = k then idealNorm (P i) else 1 := by
  simp only [idealNorm,selectedDivisor,map_prod,Nat.cast_prod]
  apply Finset.prod_congr rfl
  intro i hi
  split_ifs <;> simp

lemma selectedDivisor_rpow (P : ι → NonzeroIdeal) (f : ι → Fin 3) (k : Fin 3) (s : ℝ) :
    (idealNorm (selectedDivisor P f k))^s =
      ∏ i, if f i = k then (idealNorm (P i))^s else 1 := by
  rw [selectedDivisor_norm,← Real.finsetProd_rpow _ _ (by intro i hi; split_ifs <;> positivity)]
  apply Finset.prod_congr rfl
  intro i hi
  split_ifs <;> simp

def branchKeep (P : NonzeroIdeal) (k : Fin 3) (t : ThetaFullIndex) : Prop :=
  (k = 1 → P.val ∣ t.2.2.1.val) ∧ (k = 2 → P.val ∣ t.2.2.2.val)

def localBranch (P : NonzeroIdeal) (a : Fin 3 → ℝ) (k : Fin 3) (t : ThetaFullIndex) : ℝ :=
  if branchKeep P k t then a k else 0

def localDensity (P : NonzeroIdeal) (a : Fin 3 → ℝ) (k : Fin 3) : ℝ :=
  a k * (if k = 1 then (idealNorm P)^(-1:ℝ) else 1) *
    (if k = 2 then (idealNorm P)^(-(5/2):ℝ) else 1)

lemma branch_factorization (P : ι → NonzeroIdeal)
    (hcop : Pairwise (fun i j => IsCoprime (P i).val (P j).val))
    (a : ι → Fin 3 → ℝ) (f : ι → Fin 3) (t : ThetaFullIndex) :
    sparseWeight 0 t * ∏ i, localBranch (P i) (a i) (f i) t =
      (∏ i, a i (f i)) *
        divisorModelWeight (selectedDivisor P f 1) (selectedDivisor P f 2) t := by
  have he : (∀ i, branchKeep (P i) (f i) t) ↔
      (selectedDivisor P f 1).val ∣ t.2.2.1.val ∧
      (selectedDivisor P f 2).val ∣ t.2.2.2.val := by
    simp only [selectedDivisor_dvd_iff P hcop,branchKeep]
    exact forall_and
  by_cases hk : ∀ i, branchKeep (P i) (f i) t
  · have hp : (∏ i, localBranch (P i) (a i) (f i) t) = ∏ i, a i (f i) := by
      apply Finset.prod_congr rfl
      intro i hi
      exact if_pos (hk i)
    rw [hp,divisorModelWeight,if_pos (he.mp hk)]
    ring
  · have hp : (∏ i, localBranch (P i) (a i) (f i) t) = 0 := by
      obtain ⟨i,hi⟩ := not_forall.mp hk
      apply Finset.prod_eq_zero (Finset.mem_univ i)
      exact if_neg hi
    rw [hp,mul_zero,divisorModelWeight,if_neg (fun h => hk (he.mpr h)),mul_zero]

lemma branch_density_factorization (P : ι → NonzeroIdeal)
    (a : ι → Fin 3 → ℝ) (f : ι → Fin 3) :
    (∏ i, a i (f i)) * (idealNorm (selectedDivisor P f 1))^(-1:ℝ) *
      (idealNorm (selectedDivisor P f 2))^(-(5/2):ℝ) =
        ∏ i, localDensity (P i) (a i) (f i) := by
  rw [selectedDivisor_rpow,selectedDivisor_rpow]
  simp only [localDensity,Finset.prod_mul_distrib]

theorem simultaneous_branch_mass (P : ι → NonzeroIdeal)
    (hcop : Pairwise (fun i j => IsCoprime (P i).val (P j).val))
    (a : ι → Fin 3 → ℝ) (ha : ∀ i k, 0 ≤ a i k) (f : ι → Fin 3) :
    SqrtMassBound (fun t => sparseWeight 0 t * ∏ i, localBranch (P i) (a i) (f i) t)
      modelRadius (divisorMassConstant * ∏ i, localDensity (P i) (a i) (f i)) := by
  intro S T hT hS
  simp_rw [branch_factorization P hcop a f]
  rw [← Finset.mul_sum]
  have hm := divisor_weight_sqrt_mass (selectedDivisor P f 1) (selectedDivisor P f 2)
    S T hT hS
  have hprod : 0 ≤ ∏ i, a i (f i) := Finset.prod_nonneg (fun i _ => ha i (f i))
  have hh := mul_le_mul_of_nonneg_left hm hprod
  refine hh.trans_eq ?_
  rw [← branch_density_factorization]
  ring

def localTotal (P : NonzeroIdeal) (a : Fin 3 → ℝ) : ℝ :=
  a 0 + a 1*(idealNorm P)^(-1:ℝ) + a 2*(idealNorm P)^(-(5/2):ℝ)

lemma localDensity_sum (P : NonzeroIdeal) (a : Fin 3 → ℝ) :
    (∑ k : Fin 3, localDensity P a k) = localTotal P a := by
  simp [Fin.sum_univ_succ,localDensity,localTotal,add_assoc]

lemma localBranch_sum (P : NonzeroIdeal) (a : Fin 3 → ℝ) (t : ThetaFullIndex) :
    (∑ k : Fin 3, localBranch P a k t) = a 0 +
      (if P.val ∣ t.2.2.1.val then a 1 else 0) +
      (if P.val ∣ t.2.2.2.val then a 2 else 0) := by
  simp [Fin.sum_univ_succ,localBranch,branchKeep,add_assoc]

theorem composite_model_sqrt_mass (P : ι → NonzeroIdeal)
    (hcop : Pairwise (fun i j => IsCoprime (P i).val (P j).val))
    (a : ι → Fin 3 → ℝ) (ha : ∀ i k, 0 ≤ a i k)
    (b : ThetaFullIndex → ℂ)
    (hb : ∀ t, ‖b t‖ ≤ sparseWeight 0 t * ∏ i, ∑ k, localBranch (P i) (a i) k t) :
    SqrtMassBound (fun t => ‖b t‖) modelRadius
      (divisorMassConstant * ∏ i, localTotal (P i) (a i)) := by
  have h := dominated_product_mass b (sparseWeight 0) modelRadius
    (fun i k t => localBranch (P i) (a i) k t)
    (fun i k => localDensity (P i) (a i) k) divisorMassConstant
    (simultaneous_branch_mass P hcop a ha) hb
  simpa only [localDensity_sum] using h

theorem composite_model_paperKernel_bound
    (W : ℝ → ℂ) (lo hi : ℝ) (hlo : 0 < lo)
    (hsupp : Function.support W ⊆ Set.Icc lo hi) (hW : ContDiff ℝ ∞ W) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (ι : Type*) [Fintype ι] (P : ι → NonzeroIdeal),
      Pairwise (fun i j => IsCoprime (P i).val (P j).val) →
      ∀ (a : ι → Fin 3 → ℝ), (∀ i k, 0 ≤ a i k) →
      ∀ (b : ThetaFullIndex → ℂ),
      (∀ t, ‖b t‖ ≤ sparseWeight 0 t * ∏ i, ∑ k, localBranch (P i) (a i) k t) →
      ∀ v : ℝ, 0 < v →
      Summable (fun t => ‖b t * CubicReflectionKernel.paperKernel (Vstar W) (v*modelRadius t)‖) ∧
      ‖∑' t, b t * CubicReflectionKernel.paperKernel (Vstar W) (v*modelRadius t)‖ ≤
        C*(∏ i, localTotal (P i) (a i))*v^(-(1/2):ℝ) := by
  obtain ⟨A,hA,hsmall,hlarge⟩ :=
    QRHExperimental.EndpointProjection.paperKernel_two_sided_bound W lo hi hlo hsupp hW
  refine ⟨5*divisorMassConstant*A, by positivity [divisorMassConstant_nonneg], ?_⟩
  intro ι _ P hcop a ha b hb v hv
  have hc : 0 ≤ divisorMassConstant * ∏ i, localTotal (P i) (a i) := by
    apply mul_nonneg divisorMassConstant_nonneg
    apply Finset.prod_nonneg
    intro i hi
    unfold localTotal
    positivity [ha i 0,ha i 1,ha i 2]
  have h := kernel_summable_and_bound b modelRadius _ A hc hA modelRadius_pos
    (composite_model_sqrt_mass P hcop a ha b hb) _ hsmall hlarge v hv
  refine ⟨h.1,h.2.trans_eq ?_⟩
  ring

#print axioms simultaneous_branch_mass
#print axioms composite_model_sqrt_mass
#print axioms composite_model_paperKernel_bound
end
end QRHExperimental.CompositeModelKernel
