import MaskSourceAdapter

/-! Exact reductions for mask primes already in the fixed base or moving row. -/
namespace QRHExperimental.MaskOverlap
noncomputable section
open OAI OAI.ActualEisensteinCubic OAI.CompletedGauss OAI.CanonicalQuadraticSieve
open OAI.CanonicalRowCompletion OAI.SevenEighths
open QRHExperimental.MaskExtraction QRHExperimental.MaskSourceAdapter
open scoped BigOperators Classical
local notation "Eis" => OAI.ActualEisensteinCubic.O

lemma coprimeMask_norm_le_one (D : Ideal Eis) (hD : CubicSieve.Admissible D) (n : Eis) :
    ‖coprimeMask D hD n‖ ≤ 1 := by
  rw [coprimeMask_apply]
  split_ifs <;> simp

lemma coprimeMask_factorsModulo (D Q : Ideal Eis) (hD : CubicSieve.Admissible D)
    (hQD : Q ≤ D) : CanonicalCoefficientClass.FactorsModulo Q (coprimeMask D hD) := by
  intro x y hxy
  change (CubicSieve.cubicQuotientCharacter D hD (Ideal.Quotient.mk D x))^3 =
    (CubicSieve.cubicQuotientCharacter D hD (Ideal.Quotient.mk D y))^3
  rw [Ideal.Quotient.eq.mpr (hQD hxy)]

theorem absorb_base_mask (D Q : Ideal Eis) (hD : CubicSieve.Admissible D)
    (hQD : Q ≤ D) (φ : Eis →* ℂ)
    (hφ : CanonicalCoefficientClass.FactorsModulo Q φ) (hφn : ∀ n, ‖φ n‖ ≤ 1) :
    CanonicalCoefficientClass.FactorsModulo Q (φ*coprimeMask D hD) ∧
      ∀ n, ‖(φ*coprimeMask D hD) n‖ ≤ 1 := by
  constructor
  · intro x y hxy
    simp only [MonoidHom.mul_apply,hφ x y hxy,
      coprimeMask_factorsModulo D Q hD hQD x y hxy]
  · intro n
    rw [MonoidHom.mul_apply,norm_mul]
    exact (mul_le_mul (hφn n) (coprimeMask_norm_le_one D hD n)
      (norm_nonneg _) (by norm_num)).trans_eq (by ring)

lemma idealRowHom_sixth_value (D : Ideal Eis) (hD : CubicSieve.Admissible D) (n : Eis) :
    idealRowHom n D ^ 6 = if IsCoprime D (Ideal.span {n}) then 1 else 0 := by
  rw [show (6:ℕ)=2*3 by decide,pow_mul,idealRowHom_square]
  exact CubicSieve.idealSymbol_cube_mask D n hD.2

theorem redundant_moving_mask
    (I D Q : Ideal Eis) (hI : Supported I) (hD : Supported D)
    (hDa : CubicSieve.Admissible D) (hQD : IsCoprime Q D) (hDI : D ∣ I) :
    freePrimeRow I hI Q * coprimeMask D hDa = freePrimeRow I hI Q := by
  ext n
  rw [MonoidHom.mul_apply,coprimeMask_apply]
  by_cases hc : IsCoprime D (Ideal.span {n})
  · rw [if_pos hc,mul_one]
  · have hz : idealRowHom n D = 0 := by
      apply eq_zero_of_pow_eq_zero
      rw [idealRowHom_sixth_value D hDa n,if_neg hc]
    have hzfree : freeIdealHom Q n I = 0 := by
      obtain ⟨J,hJ⟩ := hDI
      rw [hJ,map_mul,freeIdealHom_eq_idealRowHom D Q hD hQD n,hz,zero_mul]
    rw [←freeIdealHom_eq I Q hI n,hzfree,zero_mul]

theorem coprimeMask_product (D E : Ideal Eis)
    (hD : CubicSieve.Admissible D) (hE : CubicSieve.Admissible E)
    (hDE : CubicSieve.Admissible (D*E)) :
    coprimeMask (D*E) hDE = coprimeMask D hD * coprimeMask E hE := by
  ext n
  simp only [MonoidHom.mul_apply,coprimeMask_apply,IsCoprime.mul_left_iff]
  split_ifs <;> simp_all

#print axioms absorb_base_mask
#print axioms redundant_moving_mask
#print axioms coprimeMask_product
end
end QRHExperimental.MaskOverlap
