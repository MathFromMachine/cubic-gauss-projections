import OAI.NumberTheory.DirichletL.GaussSum.FiniteTranslations
import Mathlib.Algebra.Order.Chebyshev

/-! Parseval and an L1 bound for the exact normalized finite Fourier
coefficients used in the actual theta reflection formula. -/
namespace QRHExperimental.FiniteFourierMass
noncomputable section
open scoped BigOperators
open OAI.CubicEisenstein

theorem normalized_fourier_pairing {R : Type*} [CommRing R] [Fintype R]
    (ψ : AddChar R ℂ) (hψ : ψ.IsPrimitive) (φ g : R → ℂ) :
    (∑ h, finiteAdditiveFourierCoeff ψ φ h * star (finiteAdditiveFourierCoeff ψ g h)) =
      (∑ x, φ x * star (g x)) / (Fintype.card R : ℂ) := by
  classical
  let β := finiteAdditiveFourierCoeff ψ g
  have hinner (x : R) : (∑ h, ψ (-h*x) * star (β h)) = star (g x) := by
    rw [← finiteAdditiveFourier_inversion ψ hψ g x]
    simp only [star_sum, star_mul]
    apply Finset.sum_congr rfl
    intro h hh
    have he : ψ (-h*x) = star (ψ (h*x)) := by
      simpa only [neg_mul, starRingEnd_apply] using (AddChar.map_neg_eq_conj ψ (h*x))
    rw [he]
  change (∑ h, finiteAdditiveFourierCoeff ψ φ h * star (β h)) = _
  calc
    _ = (∑ h, ∑ x, φ x * ψ (-h*x) * star (β h)) / (Fintype.card R : ℂ) := by
      simp only [finiteAdditiveFourierCoeff, div_mul_eq_mul_div, Finset.sum_mul, Finset.sum_div]
    _ = (∑ x, φ x * ∑ h, ψ (-h*x) * star (β h)) / (Fintype.card R : ℂ) := by
      rw [Finset.sum_comm]
      congr 1
      apply Finset.sum_congr rfl
      intro x hx
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro h hh
      ring
    _ = _ := by simp only [hinner]

theorem normalized_fourier_parseval {R : Type*} [CommRing R] [Fintype R]
    (ψ : AddChar R ℂ) (hψ : ψ.IsPrimitive) (φ : R → ℂ) :
    (∑ h, ‖finiteAdditiveFourierCoeff ψ φ h‖ ^ 2) =
      (∑ x, ‖φ x‖ ^ 2) / (Fintype.card R : ℝ) := by
  have h := normalized_fourier_pairing ψ hψ φ φ
  have hc (z : ℂ) : z * star z = ((‖z‖^2 : ℝ) : ℂ) := by
    simpa using Complex.mul_conj' z
  simp only [hc] at h
  exact_mod_cast h

theorem normalized_fourier_mass_le_one {R : Type*} [CommRing R] [Fintype R]
    (ψ : AddChar R ℂ) (hψ : ψ.IsPrimitive) (φ : R → ℂ)
    (hφ : ∀ x, ‖φ x‖ ≤ 1) :
    (∑ h, ‖finiteAdditiveFourierCoeff ψ φ h‖ ^ 2) ≤ 1 := by
  rw [normalized_fourier_parseval ψ hψ]
  have hN : (0 : ℝ) < Fintype.card R := by exact_mod_cast Fintype.card_pos
  apply (div_le_one hN).mpr
  calc
    _ ≤ ∑ _x : R, (1 : ℝ) := by
      apply Finset.sum_le_sum
      intro x hx
      nlinarith [norm_nonneg (φ x), hφ x]
    _ = _ := by simp

theorem normalized_fourier_l1_sq_le_card {R : Type*} [CommRing R] [Fintype R]
    (ψ : AddChar R ℂ) (hψ : ψ.IsPrimitive) (φ : R → ℂ)
    (hφ : ∀ x, ‖φ x‖ ≤ 1) :
    (∑ h, ‖finiteAdditiveFourierCoeff ψ φ h‖) ^ 2 ≤ (Fintype.card R : ℝ) := by
  have hcs := sq_sum_le_card_mul_sum_sq
    (s := Finset.univ) (f := fun h => ‖finiteAdditiveFourierCoeff ψ φ h‖)
  have hm := normalized_fourier_mass_le_one ψ hψ φ hφ
  have hN : (0 : ℝ) ≤ Fintype.card R := Nat.cast_nonneg _
  simpa using hcs.trans (mul_le_mul_of_nonneg_left hm hN)

#print axioms normalized_fourier_pairing
#print axioms normalized_fourier_parseval
#print axioms normalized_fourier_mass_le_one
#print axioms normalized_fourier_l1_sq_le_card
end
end QRHExperimental.FiniteFourierMass
