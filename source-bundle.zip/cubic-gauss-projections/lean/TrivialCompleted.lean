import TrivialProjection
import OAI.NumberTheory.DirichletL.CubicSieve.LogSeparation

namespace QRHExperimental.TrivialCompleted
noncomputable section
open OAI OAI.ActualEisensteinCubic OAI.CompletedGauss
open OAI.CubicEisenstein hiding summand
open QRHExperimental.TrivialProjection
open scoped BigOperators Classical
set_option maxHeartbeats 1500000
local notation "Eis" => OAI.ActualEisensteinCubic.O

lemma completedT_reopen_columns (Ψ : Eis →* ℂ) (W : ℝ → ℂ)
    (hW : HasCompactSupport W) (X : ℝ) (hX : 0 < X) :
    completedT Ψ W X = ∑' J : NonzeroIdeal,
      cubeWeight Ψ J.val * (Real.sqrt (X/(Ideal.absNorm J.val:ℝ)^3):ℂ)⁻¹ *
        rawProjection Ψ W (X/(Ideal.absNorm J.val:ℝ)^3) := by
  have hfull := completedT_summable Ψ W hW X hX
  have hswap : (∑' I : Ideal Eis, ∑' J : Ideal Eis, summand Ψ W X I J) =
      ∑' J : Ideal Eis, ∑' I : Ideal Eis, summand Ψ W X I J := hfull.tsum_comm.symm
  change (∑' I : Ideal Eis, ∑' J : Ideal Eis, summand Ψ W X I J) = _
  rw [hswap]
  have hsub : (∑' J : Ideal Eis, ∑' I : Ideal Eis, summand Ψ W X I J) =
      ∑' J : NonzeroIdeal, ∑' I : Ideal Eis, summand Ψ W X I J.val := by
    symm
    apply tsum_subtype_eq_of_support_subset
      (s := {J : Ideal Eis | J ≠ 0})
      (f := fun J : Ideal Eis => ∑' I : Ideal Eis, summand Ψ W X I J)
    intro J hJ hz
    subst J
    exact hJ (by simp only [summand_zero_right, tsum_zero])
  rw [hsub]
  apply tsum_congr
  intro J
  have hscale : 0 < X/(Ideal.absNorm J.val:ℝ)^3 :=
    div_pos hX (pow_pos (nonzeroIdeal_norm_pos J) _)
  rw [rawProjection, ← tsum_mul_left]
  apply tsum_congr
  intro I
  have he := vstar_source_normalization Ψ W _ hscale I
  have ha : (Ideal.absNorm I:ℝ)/(X/(Ideal.absNorm J.val:ℝ)^3) =
      (Ideal.absNorm I:ℝ)*(Ideal.absNorm J.val:ℝ)^3/X := by rw [div_div_eq_mul_div]
  rw [ha] at he
  unfold summand
  calc
    _ = cubeWeight Ψ J.val *
        (columnWeight Ψ I/(Real.sqrt (Ideal.absNorm I:ℝ):ℂ)*
          Vstar W ((Ideal.absNorm I:ℝ)*(Ideal.absNorm J.val:ℝ)^3/X)) := by ring
    _ = _ := by rw [he, ha]; ring

lemma weight_sqrt_scale (X n : ℝ) (hX : 0 < X) (hn : 0 < n) :
    (1/n) * (Real.sqrt (X/n^3))⁻¹ * (X/n^3) =
      Real.sqrt X * n^(-(5/2):ℝ) := by
  have hy : 0 < X/n^3 := div_pos hX (pow_pos hn _)
  have hs : (Real.sqrt (X/n^3))⁻¹ * (X/n^3) = Real.sqrt (X/n^3) := by
    calc
      _ = (Real.sqrt (X/n^3))⁻¹ * (Real.sqrt (X/n^3))^2 := by rw [Real.sq_sqrt hy.le]
      _ = _ := by field_simp [(Real.sqrt_pos.mpr hy).ne']
  rw [mul_assoc, hs, Real.sqrt_eq_rpow, Real.div_rpow hX.le (pow_nonneg hn.le _),
    ← Real.rpow_natCast_mul hn.le, Real.sqrt_eq_rpow]
  rw [div_eq_mul_inv, one_div, div_eq_mul_inv, ← Real.rpow_neg hn.le,
    ← Real.rpow_neg_one]
  calc
    _ = X^(1/2:ℝ)*(n^(-(1:ℝ))*n^(-((3:ℝ)*(1/2)))) := by ring
    _ = _ := by rw [← Real.rpow_add hn]; norm_num

theorem completedT_trivial_bound (Ψ : Eis →* ℂ) (hΨ : ∀ z, ‖Ψ z‖ ≤ 1)
    (W : ℝ → ℂ) (hWc : HasCompactSupport W)
    (b C X : ℝ) (hb : 0 ≤ b) (hC : 0 ≤ C) (hX : 0 < X)
    (hWs : ∀ x, W x ≠ 0 → x ≤ b) (hW : ∀ x, ‖W x‖ ≤ C) :
    ‖completedT Ψ W X‖ ≤
      ((128*b*C)*(∑' J : NonzeroIdeal, (Ideal.absNorm J.val:ℝ)^(-(5/2):ℝ))) *
        Real.sqrt X := by
  let f : NonzeroIdeal → ℂ := fun J =>
    cubeWeight Ψ J.val * (Real.sqrt (X/(Ideal.absNorm J.val:ℝ)^3):ℂ)⁻¹ *
      rawProjection Ψ W (X/(Ideal.absNorm J.val:ℝ)^3)
  let g : NonzeroIdeal → ℝ := fun J =>
    ((128*b*C)*Real.sqrt X)*(Ideal.absNorm J.val:ℝ)^(-(5/2):ℝ)
  have hg : Summable g := (nonzeroIdeal_norm_rpow_summable (5/2) (by norm_num)).mul_left _
  have hbound (J : NonzeroIdeal) : ‖f J‖ ≤ g J := by
    have hn := nonzeroIdeal_norm_pos J
    have hy : 0 < X/(Ideal.absNorm J.val:ℝ)^3 := div_pos hX (pow_pos hn _)
    dsimp only [f, g]
    rw [norm_mul, norm_mul, norm_inv, Complex.norm_real, Real.norm_eq_abs,
      abs_of_nonneg (Real.sqrt_nonneg _)]
    calc
      _ ≤ ((1/(Ideal.absNorm J.val:ℝ))*(Real.sqrt (X/(Ideal.absNorm J.val:ℝ)^3))⁻¹)*
          ((128*b*C)*(X/(Ideal.absNorm J.val:ℝ)^3)) :=
        mul_le_mul
          (mul_le_mul_of_nonneg_right
            (CanonicalRowCompletion.cubeWeight_norm_le Ψ hΨ J.val) (by positivity))
          (rawProjection_norm_le Ψ hΨ W b C _ hb hC hy hWs hW)
          (norm_nonneg _) (by positivity)
      _ = (128*b*C)*((1/(Ideal.absNorm J.val:ℝ))*
          (Real.sqrt (X/(Ideal.absNorm J.val:ℝ)^3))⁻¹*(X/(Ideal.absNorm J.val:ℝ)^3)) := by ring
      _ = _ := by rw [weight_sqrt_scale X _ hX hn]; ring
  have hfn : Summable (fun J => ‖f J‖) :=
    Summable.of_nonneg_of_le (fun _ => norm_nonneg _) hbound hg
  rw [completedT_reopen_columns Ψ W hWc X hX]
  change ‖∑' J, f J‖ ≤ _
  calc
    _ ≤ ∑' J, ‖f J‖ := norm_tsum_le_tsum_norm hfn
    _ ≤ ∑' J, g J := hfn.tsum_le_tsum hbound hg
    _ = _ := by simp only [g, tsum_mul_left]; ring

#print axioms completedT_reopen_columns
#print axioms completedT_trivial_bound
end
end QRHExperimental.TrivialCompleted
