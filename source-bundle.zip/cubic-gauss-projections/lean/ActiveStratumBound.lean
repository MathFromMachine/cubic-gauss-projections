import ActiveStratumSum

/-! Nonnegative exact active/inactive sum bound. The same constant controls
all active subsets; there is no extra factor for the number of subsets. -/
namespace QRHExperimental.ActiveStratumBound
noncomputable section
open OAI OAI.ActualEisensteinCubic OAI.ConcreteTraceCRT
open OAI.CubicEisenstein OAI.CompletedGauss
open scoped BigOperators Classical
local notation "Eis" => OAI.ActualEisensteinCubic.O
variable {ι : Type*} [Fintype ι]

def inactiveCost (q : ℝ) (j : ℕ) : ℝ := if j = 0 then 1-q⁻¹ else 0

lemma inactiveCost_nonneg (q : ℝ) (j : ℕ) (hq : 1 ≤ q) :
    0 ≤ inactiveCost q j := by
  unfold inactiveCost
  split_ifs
  · exact sub_nonneg.mpr (inv_le_one_of_one_le₀ hq)
  · rfl

lemma inactive_weight_norm (p : ι → Eis)
    [∀ i, (Ideal.span {p i}).IsMaximal]
    (hp : ∀ i, p i ≠ 0) (hg : ∀ i, lambda ∉ Ideal.span {p i})
    (hchar : ∀ i, ringChar (Eis ⧸ Ideal.span {p i}) ≠ 2)
    (j : ι → ℕ) (hj : ∀ i, j i < 6) (A : Finset ι) :
    ‖primeInactiveFourierWeight p hp hg j A‖ =
      ∏ i ∈ (Finset.univ : Finset ι) \ A,
        inactiveCost (Ideal.absNorm (Ideal.span {p i})) (j i) := by
  rw [QRHExperimental.ActiveStratumSum.inactive_weight_formula p hp hg hchar j hj A,
    norm_prod]
  apply Finset.prod_congr rfl
  intro i hi
  by_cases hz : j i = 0
  · simp only [hz, inactiveCost, if_true]
    have hq : 1 ≤ (Ideal.absNorm (Ideal.span {p i}):ℝ) :=
      norm_at_least_one (Ideal.span {p i}) (Ideal.span_singleton_eq_bot.not.mpr (hp i))
    have he : (1-(Ideal.absNorm (Ideal.span {p i}):ℂ)⁻¹) =
        Complex.ofReal (1-(Ideal.absNorm (Ideal.span {p i}):ℝ)⁻¹) := by push_cast; rfl
    rw [he, Complex.norm_real, Real.norm_eq_abs,
      abs_of_nonneg (sub_nonneg.mpr (inv_le_one_of_one_le₀ hq))]
  · simp only [hz, if_false, inactiveCost, norm_zero]

lemma real_active_product (a b : ι → ℝ) :
    (∑ A : Finset ι, (∏ i ∈ (Finset.univ : Finset ι) \ A, b i) * ∏ i ∈ A, a i) =
      ∏ i, (a i+b i) := by
  have h := Finset.prod_add a b (Finset.univ : Finset ι)
  have hpow : (Finset.univ : Finset ι).powerset = Finset.univ := by ext A; simp
  rw [hpow] at h
  rw [h]
  apply Finset.sum_congr rfl
  intro A hA
  exact mul_comm _ _

theorem weighted_active_norm_bound (p : ι → Eis)
    [∀ i, (Ideal.span {p i}).IsMaximal]
    (hp : ∀ i, p i ≠ 0) (hg : ∀ i, lambda ∉ Ideal.span {p i})
    (hchar : ∀ i, ringChar (Eis ⧸ Ideal.span {p i}) ≠ 2)
    (j : ι → ℕ) (hj : ∀ i, j i < 6)
    (a : ι → ℝ) (f : Finset ι → ℂ) (K : ℝ)
    (hf : ∀ A, ‖f A‖ ≤ K*∏ i ∈ A, a i) :
    ‖∑ A : Finset ι, primeInactiveFourierWeight p hp hg j A*f A‖ ≤
      K*∏ i, (a i+inactiveCost (Ideal.absNorm (Ideal.span {p i})) (j i)) := by
  let b : ι → ℝ := fun i => inactiveCost (Ideal.absNorm (Ideal.span {p i})) (j i)
  calc
    _ ≤ ∑ A : Finset ι, ‖primeInactiveFourierWeight p hp hg j A*f A‖ :=
      norm_sum_le _ _
    _ = ∑ A : Finset ι, ‖primeInactiveFourierWeight p hp hg j A‖*‖f A‖ := by
      simp only [norm_mul]
    _ ≤ ∑ A : Finset ι, ‖primeInactiveFourierWeight p hp hg j A‖*(K*∏ i ∈ A, a i) := by
      apply Finset.sum_le_sum
      intro A hA
      exact mul_le_mul_of_nonneg_left (hf A) (norm_nonneg _)
    _ = K*∑ A : Finset ι, (∏ i ∈ (Finset.univ : Finset ι) \ A, b i)*∏ i ∈ A, a i := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro A hA
      rw [inactive_weight_norm p hp hg hchar j hj A]
      dsimp only [b]
      ring
    _ = _ := by rw [real_active_product]

#print axioms weighted_active_norm_bound
end
end QRHExperimental.ActiveStratumBound
