import FourthModelKernel
import ControlledReflectionBound
import PhaseNumeratorSupport

/-! Singleton fourth-bracket domination, retaining the exact source support.
Draft for the owning agent's coordinated compilation. -/
namespace QRHExperimental.FourthBracketDomination
noncomputable section
open OAI OAI.ActualEisensteinCubic OAI.ConcreteTraceCRT
open OAI.CubicEisenstein OAI.CompletedGauss OAI.CompletedDyadic
open OAI.LocalReflectionBrackets
open QRHExperimental.IdealPowerSums QRHExperimental.SparseRadialSummability
open QRHExperimental.ModelKernelMass QRHExperimental.FourthModelKernel
open QRHExperimental.ControlledBracketNorms QRHExperimental.ControlledReflectionBound
open QRHExperimental.PhaseNumeratorSupport QRHExperimental.GoodPrimeRadialMass
open scoped BigOperators Classical MatrixGroups
local notation "Eis" => OAI.ActualEisensteinCubic.O
set_option maxHeartbeats 1500000

noncomputable local instance quotientField (P : Ideal Eis) [P.IsMaximal] :
    Field (Eis ⧸ P) := Ideal.Quotient.field P
noncomputable local instance quotientFintype (P : Ideal Eis) [P.IsMaximal] :
    Fintype (Eis ⧸ P) := Fintype.ofFinite _

lemma norm_fourth_bracket_le {F : Type*} [Field F] [Fintype F]
    (χ : MulChar F ℂ) (x : F) :
    ‖bracket χ 4 x‖ ≤ (rootCard F)⁻¹ + rootCard F * (if x = 0 then 1 else 0) := by
  by_cases hx : x = 0
  · subst x
    rw [norm_bracket_four_zero]
    simp only [ite_true, mul_one]
    apply (div_le_iff₀ rootCard_pos).mpr
    have hr := rootCard_sq (F := F)
    have hp := rootCard_pos (F := F)
    have hi : (rootCard F)⁻¹ * rootCard F = 1 := inv_mul_cancel₀ hp.ne'
    nlinarith
  · rw [norm_bracket_four_nonzero χ x hx]
    simp only [if_neg hx, mul_zero, add_zero, le_refl]

lemma amplitude_ne_zero_source {H : SL(2,Eis)} (s : FixedCuspShape H)
    (t : ThetaFullIndex)
    (ha : s.amplitude t.1 t.2.1 t.2.2.1.val t.2.2.2.val ≠ 0) :
    (sourceCuspCoefficients s.index).value (thetaFullFrequency t) ≠ 0 := by
  exact s.amplitude_source_nonzero t ha

variable {ι : Type*} [Fintype ι] [Unique ι] {p : ι → Eis} {N a0 c0 : Eis} {mode : Bool}
variable [∀ i, (Ideal.span {p i}).IsMaximal]

def singletonIdeal (hp : ∀ i, p i ≠ 0) : NonzeroIdeal :=
  ⟨Ideal.span {p default}, Ideal.span_singleton_eq_bot.not.mpr (hp default)⟩

lemma singleton_rootCard (hp : ∀ i, p i ≠ 0) :
    rootCard (Eis ⧸ Ideal.span {p default}) = (idealNorm (singletonIdeal hp))^(1/2:ℝ) := by
  letI : Field (Eis ⧸ Ideal.span {p default}) := Ideal.Quotient.field _
  letI : Fintype (Eis ⧸ Ideal.span {p default}) := Fintype.ofFinite _
  have hcard : (Fintype.card (Eis ⧸ Ideal.span {p default}):ℝ) = idealNorm (singletonIdeal hp) := by
    congr 1
    rw [← Nat.card_eq_fintype_card, ← Submodule.cardQuot_apply, ← Ideal.absNorm_apply]
    rfl
  rw [rootCard,hcard,Real.sqrt_eq_rpow]

theorem reflectedCoefficient_fourth_norm_le
    (D : ControlledStratumArithmetic p N a0 c0 mode)
    (s : FixedCuspShape (ControlledStratumArithmetic.fixedCusp a0 c0 mode))
    (hp : ∀ i, p i ≠ 0) (hc0 : c0 ≠ 0)
    (hg : ∀ i, lambda ∉ Ideal.span {p i})
    (hchar : ∀ i, ringChar (Eis ⧸ Ideal.span {p i}) ≠ 2)
    (hN : (9 : Eis)*c0 ∣ N) (hr : lambda^2 ∣ (∏ i, p i)-1)
    (hbase : if mode then lambda^2 ∣ a0-1 else lambda^2 ∣ c0-1)
    (t : ThetaFullIndex) :
    ‖reflectedCoefficient D s hp hc0 hg (fun _ => 4) t‖ ≤
      fourthModelWeight (singletonIdeal hp) t := by
  let P := singletonIdeal hp
  have hq : 0 < idealNorm P := nonzeroIdeal_norm_pos P
  have hw : 0 ≤ sparseWeight 0 t := by unfold sparseWeight; positivity
  by_cases ha : s.amplitude t.1 t.2.1 t.2.2.1.val t.2.2.2.val = 0
  · simp only [reflectedCoefficient, ha, zero_div, zero_mul, norm_zero]
    unfold fourthModelWeight
    exact add_nonneg (add_nonneg
      (mul_nonneg (by positivity) (divisorModelWeight_nonneg _ _ t))
      (mul_nonneg (by positivity) (divisorModelWeight_nonneg _ _ t)))
      (mul_nonneg (by positivity) (divisorModelWeight_nonneg _ _ t))
  let x := sourceCuspPhaseNumerator s.index (s.upper 0 0) (thetaFullFrequency t)
  have hm : x ∈ P.val ↔ P.val ∣ t.2.2.1.val ∨ P.val ∣ t.2.2.2.val := by
    rcases s.upper_unit with ⟨u, hu⟩
    simpa only [x, ← hu, P, singletonIdeal] using
      phaseNumerator_fullFrequency_mem_iff (Ideal.span {p default}) (hg default) s.index u t
        (amplitude_ne_zero_source s t ha)
  letI : Field (Eis ⧸ Ideal.span {p default}) := Ideal.Quotient.field _
  letI : Fintype (Eis ⧸ Ideal.span {p default}) := Fintype.ofFinite _
  have hb : ‖(star D.fixedFactor *
      ShortDraftCusp.A4BadPhase c0 hc0 (D.matrix (fun _ => 1) 1 1) D.U x) *
      D.bracketProduct hp hg (fun _ => 4) x‖ ≤
      (idealNorm P)^(-(1/2):ℝ) + (idealNorm P)^(1/2:ℝ) *
        (if P.val ∣ t.2.2.1.val ∨ P.val ∣ t.2.2.2.val then 1 else 0) := by
    rw [staticMultiplier_norm_eq D hN hr hbase hc0 hp hg,
      bracketProduct_norm D hp hg hchar (fun _ => 4) (fun _ => by decide)]
    simp only [Fintype.prod_unique]
    have hh := norm_fourth_bracket_le (actualSextic (Ideal.span {p default}) (hg default))
      (Ideal.Quotient.mk (Ideal.span {p default}) x)
    rw [singleton_rootCard hp, ← Real.rpow_neg hq.le] at hh
    have hm' : x ∈ Ideal.span {p default} ↔ P.val ∣ t.2.2.1.val ∨ P.val ∣ t.2.2.2.val := hm
    simp only [Ideal.Quotient.eq_zero_iff_mem, hm'] at hh
    exact hh
  have hd := thetaFullIndex_denominator_pos t
  have hcoeff : ‖reflectedCoefficient D s hp hc0 hg (fun _ => 4) t‖ ≤
      sparseWeight 0 t * ((idealNorm P)^(-(1/2):ℝ) +
        (idealNorm P)^(1/2:ℝ) *
          (if P.val ∣ t.2.2.1.val ∨ P.val ∣ t.2.2.2.val then 1 else 0)) := by
    rw [reflectedCoefficient, norm_mul, norm_div, Complex.norm_real,
      Real.norm_of_nonneg hd.le]
    calc
      _ ≤ (1/(ramifiedScale 1 completedRamifiedStep t.2.1 *
          Real.sqrt (Ideal.absNorm t.2.2.1.val:ℝ)*(Ideal.absNorm t.2.2.2.val:ℝ))) *
          ((idealNorm P)^(-(1/2):ℝ) + (idealNorm P)^(1/2:ℝ) *
            (if P.val ∣ t.2.2.1.val ∨ P.val ∣ t.2.2.2.val then 1 else 0)) :=
        mul_le_mul (div_le_div_of_nonneg_right
          (s.amplitude_norm t.1 t.2.1 t.2.2.1.val t.2.2.2.val) hd.le)
          hb (norm_nonneg _) (by positivity)
      _ = _ := by rw [inverse_denominator]
  apply hcoeff.trans
  change sparseWeight 0 t * ((idealNorm P)^(-(1/2):ℝ) +
      (idealNorm P)^(1/2:ℝ) *
        (if P.val ∣ t.2.2.1.val ∨ P.val ∣ t.2.2.2.val then 1 else 0)) ≤ fourthModelWeight P t
  rw [fourthModelWeight_eq]
  unfold divisorModelWeight oneIdeal
  simp only [one_dvd, and_true, true_and]
  by_cases hI : P.val ∣ t.2.2.1.val <;>
    by_cases hJ : P.val ∣ t.2.2.2.val <;>
    simp only [hI,hJ,or_true,true_or,false_or,or_false,ite_true,ite_false] <;>
    nlinarith [Real.rpow_nonneg hq.le (1/2:ℝ)]

#print axioms reflectedCoefficient_fourth_norm_le
end
end QRHExperimental.FourthBracketDomination
