import MaskExtraction
import CompositeProjectionCosts

/-! The exact actual-character bridge for squarefree Gauss extraction. -/
namespace QRHExperimental.MaskSourceAdapter
noncomputable section
open OAI OAI.ActualEisensteinCubic OAI.CompletedGauss OAI.CanonicalQuadraticSieve
open OAI.CanonicalRowCompletion UniqueFactorizationMonoid
open OAI.SevenEighths
open QRHExperimental.MaskExtraction QRHExperimental.CompositeProjection
open QRHExperimental.CompositeProjectionCosts QRHExperimental.NonexceptionalProjection
open scoped BigOperators Classical
set_option maxHeartbeats 2500000
local notation "Eis" => OAI.ActualEisensteinCubic.O

def freeIdealHom (Q : Ideal Eis) (n : Eis) : Ideal Eis →*₀ ℂ :=
  primeValueHom (fun P => if Q ≤ P then 1 else localRowValue n P)

lemma freeIdealHom_eq (I Q : Ideal Eis) (hI : Supported I) (n : Eis) :
    freeIdealHom Q n I = freePrimeRow I hI Q n := by
  have he : I = ∏ P : PrimeIndex I, P.val^((normalizedFactors I).count P.val) := by
    change I = ∏ P : (normalizedFactors I).toFinset, P.val^((normalizedFactors I).count P.val)
    exact ((Ideal.prod_normalizedFactors_eq_self hI.1).symm.trans (Finset.prod_multiset_count _)).trans
      (Finset.prod_coe_sort (normalizedFactors I).toFinset
        (fun P => P^((normalizedFactors I).count P))).symm
  have hp : freeIdealHom Q n I = ∏ P : PrimeIndex I,
      if Q ≤ P.val then 1 else localRowValue n P.val^((normalizedFactors I).count P.val) := by
    conv_lhs => rw [he]
    simp only [map_prod,map_pow]
    apply Finset.prod_congr rfl
    intro P hP
    rw [freeIdealHom,primeValueHom_prime _ P.val
      (Ideal.prime_of_isPrime (NeZero.ne P.val) inferInstance)]
    split_ifs <;> simp
  rw [hp,←Fintype.prod_subtype_mul_prod_subtype (fun P : PrimeIndex I => Q ≤ P.val)]
  have hb : (∏ P : BasePrimeIndex I Q,
      if Q ≤ P.val.val then (1:ℂ) else
        localRowValue n P.val.val^((normalizedFactors I).count P.val.val)) = 1 := by
    apply Finset.prod_eq_one
    intro P hP
    exact if_pos P.property
  rw [hb,one_mul]
  change (∏ P : FreePrimeIndex I Q, _) = ∏ P : FreePrimeIndex I Q, _
  apply Finset.prod_congr rfl
  intro P hP
  rw [if_neg P.property,localRowValue_good n P.val.val
    ((supported_factors_good I hI P.val.val (Multiset.mem_toFinset.mp P.val.property)).2.1)]
  exact actualSextic_power_mod_six P.val.val _ _
    (Nat.ne_of_gt (Multiset.count_pos.mpr (Multiset.mem_toFinset.mp P.val.property))) n

lemma not_base_of_coprime (D Q P : Ideal Eis) (hc : IsCoprime Q D)
    (hP : Prime P) (hPD : P ∣ D) : ¬Q ≤ P := by
  intro hQP
  have hcp : IsCoprime Q P := hc.of_isCoprime_of_dvd_right hPD
  have htop : P = ⊤ := by
    simpa only [sup_eq_right.mpr hQP] using Ideal.isCoprime_iff_sup_eq.mp hcp
  exact hP.not_unit (Ideal.isUnit_iff.mpr htop)

lemma freeIdealHom_eq_idealRowHom (D Q : Ideal Eis) (hD : Supported D)
    (hc : IsCoprime Q D) (n : Eis) : freeIdealHom Q n D = idealRowHom n D := by
  change (if D=0 then 0 else _) = (if D=0 then 0 else _)
  rw [if_neg hD.1,if_neg hD.1]
  congr 1
  apply Multiset.map_congr rfl
  intro P hP
  have hp := (mem_normalizedFactors_iff hD.1).mp hP
  exact if_neg (not_base_of_coprime D Q P hc hp.1 hp.2)

theorem freePrimeRow_mul_fourth
    (I D Q : Ideal Eis) (hI : Supported I) (hD : Supported D)
    (hDa : CubicSieve.Admissible D) (hc : IsCoprime Q D) :
    freePrimeRow (I*D^4) ((supported_mul_iff _ _).mpr ⟨hI,supported_pow hD 4⟩) Q =
      freePrimeRow I hI Q * fourthTwist D hDa := by
  ext n
  rw [←freeIdealHom_eq,MonoidHom.mul_apply,←freeIdealHom_eq,
    map_mul,map_pow,freeIdealHom_eq_idealRowHom D Q hD hc n,fourthTwist_apply]
  congr 1
  rw [show (4:ℕ)=2*2 by decide,pow_mul,idealRowHom_square]
  rfl

def costFactor (I Q P : Ideal Eis) : ℝ :=
  if Q ≤ P then 1 else primeCost (Ideal.absNorm P:ℝ) ((normalizedFactors I).count P % 6)

lemma sourceCost_eq_support (I Q : Ideal Eis) (hI : Supported I) :
    sourceCost I Q = ∏ P ∈ (normalizedFactors I).toFinset, costFactor I Q P := by
  rw [sourceCost_eq_prime_product I Q hI,
    ←Finset.prod_coe_sort (normalizedFactors I).toFinset (costFactor I Q)]
  symm
  change (∏ P : PrimeIndex I, costFactor I Q P.val) = _
  rw [←Fintype.prod_subtype_mul_prod_subtype (fun P : PrimeIndex I => Q ≤ P.val)]
  have hb : (∏ P : BasePrimeIndex I Q, costFactor I Q P.val.val) = 1 := by
    apply Finset.prod_eq_one
    intro P hP
    exact if_pos P.property
  rw [hb,one_mul]
  apply Finset.prod_congr rfl
  intro P hP
  simp only [costFactor,if_neg P.property,freeExponent]

lemma sourceCost_coprime_mul (I J Q : Ideal Eis) (hI : Supported I) (hJ : Supported J)
    (hc : IsCoprime I J) : sourceCost (I*J) Q = sourceCost I Q * sourceCost J Q := by
  have hd : Disjoint (normalizedFactors I).toFinset (normalizedFactors J).toFinset :=
    (OAI.IdealCoprimeSieveOperator.primeSupport_disjoint_iff hI.1 hJ.1).mpr hc
  rw [sourceCost_eq_support _ Q ((supported_mul_iff _ _).mpr ⟨hI,hJ⟩),
    sourceCost_eq_support I Q hI,sourceCost_eq_support J Q hJ]
  rw [normalizedFactors_mul hI.1 hJ.1,Multiset.toFinset_add,Finset.prod_union hd]
  congr 1
  · apply Finset.prod_congr rfl
    intro P hP
    have hz : (normalizedFactors J).count P = 0 := Multiset.count_eq_zero.mpr (by
      intro hm
      exact Finset.disjoint_left.mp hd hP (Multiset.mem_toFinset.mpr hm))
    simp only [costFactor,normalizedFactors_mul hI.1 hJ.1,Multiset.count_add,hz,add_zero]
  · apply Finset.prod_congr rfl
    intro P hP
    have hz : (normalizedFactors I).count P = 0 := Multiset.count_eq_zero.mpr (by
      intro hm
      exact Finset.disjoint_left.mp hd (Multiset.mem_toFinset.mpr hm) hP)
    simp only [costFactor,normalizedFactors_mul hI.1 hJ.1,Multiset.count_add,hz,zero_add]

lemma sourceCost_fourth (D Q : Ideal Eis) (hD : Supported D) (hsq : Squarefree D)
    (hc : IsCoprime Q D) :
    sourceCost (D^4) Q = ∏ P ∈ (normalizedFactors D).toFinset,
      (2*(Ideal.absNorm P:ℝ)^(1/2:ℝ)+(Ideal.absNorm P:ℝ)⁻¹) := by
  have hs : (normalizedFactors (D^4)).toFinset = (normalizedFactors D).toFinset := by
    ext P
    simp [normalizedFactors_pow]
  rw [sourceCost_eq_support _ Q (supported_pow hD 4),hs]
  apply Finset.prod_congr rfl
  intro P hP
  have hp := (mem_normalizedFactors_iff hD.1).mp (Multiset.mem_toFinset.mp hP)
  have hn : (normalizedFactors D).count P = 1 := by
    rw [squarefree_prime_count_indicator D P hsq hp.1,if_pos hp.2]
  simp only [costFactor,if_neg (not_base_of_coprime D Q P hc hp.1 hp.2),
    normalizedFactors_pow,Multiset.count_nsmul,hn,smul_eq_mul,mul_one]
  norm_num [primeCost]

theorem sourceCost_mul_fourth (I D Q : Ideal Eis) (hI : Supported I) (hD : Supported D)
    (hsq : Squarefree D) (hID : IsCoprime I D) (hQD : IsCoprime Q D) :
    sourceCost (I*D^4) Q = sourceCost I Q *
      ∏ P ∈ (normalizedFactors D).toFinset,
        (2*(Ideal.absNorm P:ℝ)^(1/2:ℝ)+(Ideal.absNorm P:ℝ)⁻¹) := by
  rw [sourceCost_coprime_mul I (D^4) Q hI (supported_pow hD 4) hID.pow_right,
    sourceCost_fourth D Q hD hsq hQD]

#print axioms freeIdealHom_eq
#print axioms freePrimeRow_mul_fourth
#print axioms sourceCost_coprime_mul
#print axioms sourceCost_mul_fourth
end
end QRHExperimental.MaskSourceAdapter
