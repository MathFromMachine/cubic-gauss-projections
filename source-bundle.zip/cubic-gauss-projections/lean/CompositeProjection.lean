import NonexceptionalProjection
import CompositeControlledReflection
import ActiveStratumBound

/-! Complete mixed moving-prime projection. The exact active
strata and fixed Fourier coefficients precede every norm estimate. -/
namespace QRHExperimental.CompositeProjection
noncomputable section
open OAI OAI.ActualEisensteinCubic OAI.ConcreteTraceCRT
open OAI.CubicEisenstein OAI.CompletedGauss OAI.CanonicalRowCompletion
open OAI.CanonicalQuadraticSieve
open QRHExperimental.TrivialProjection QRHExperimental.CubeInverseAssembly
open QRHExperimental.FiniteBaseBounds
open scoped BigOperators Classical ContDiff
set_option maxHeartbeats 3000000
local notation "Eis" => OAI.ActualEisensteinCubic.O

open QRHExperimental.NonexceptionalProjection
open QRHExperimental.CompositeBracketDomination QRHExperimental.ActiveStratumBound

def primeNorm (I Q : Ideal Eis) (P : FreePrimeIndex I Q) : ℝ :=
  Ideal.absNorm (Ideal.span {freePrimaryPrime I Q P})

def activeCost (q : ℝ) (j : ℕ) : ℝ := q*localReflectionCost q j

def sourceCost (I Q : Ideal Eis) : ℝ :=
  ∏ P : FreePrimeIndex I Q,
    (activeCost (primeNorm I Q P) (freeExponent I Q P) +
      inactiveCost (primeNorm I Q P) (freeExponent I Q P))

lemma primeNorm_pos (I Q : Ideal Eis) (hI : Supported I) (P : FreePrimeIndex I Q) :
    0 < primeNorm I Q P := principal_norm_pos _ (freePrimaryPrime_ne_zero I Q hI P)

lemma primeNorm_one_le (I Q : Ideal Eis) (hI : Supported I) (P : FreePrimeIndex I Q) :
    1 ≤ primeNorm I Q P := norm_at_least_one _
      (Ideal.span_singleton_eq_bot.not.mpr (freePrimaryPrime_ne_zero I Q hI P))

lemma primeNorm_eq (I Q : Ideal Eis) (hI : Supported I) (P : FreePrimeIndex I Q) :
    primeNorm I Q P = (Ideal.absNorm P.val.val:ℝ) := by
  rw [primeNorm,freePrimaryPrime_span I Q hI P]

lemma sourceCost_pos (I Q : Ideal Eis) (hI : Supported I) : 0 < sourceCost I Q := by
  apply Finset.prod_pos
  intro P hP
  exact add_pos_of_pos_of_nonneg
    (mul_pos (primeNorm_pos I Q hI P)
      (localReflectionCost_pos _ (primeNorm_pos I Q hI P) _))
    (inactiveCost_nonneg _ _ (primeNorm_one_le I Q hI P))

/-- Uniformity includes arbitrary mixtures of all six local exponents.
Every active subset has the same analytic constant. -/
theorem completedT_composite_reflected_bound
    (W : ℝ → ℂ) (lo hi : ℝ) (hlo : 0 < lo)
    (hsupp : Function.support W ⊆ Set.Icc lo hi) (hW : ContDiff ℝ ∞ W) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (I Q : Ideal Eis) (hI : Supported I),
      Q ≠ 0 →
      ∀ (c : Eis), c ≠ 0 → Ideal.span {c} = Ideal.span {(9:Eis)}*Q →
      ∀ (φ : Eis →* ℂ), CanonicalCoefficientClass.FactorsModulo Q φ →
      (∀ n, ‖φ n‖ ≤ 1) → ∀ X : ℝ, 0 < X →
      ‖completedT (φ*freePrimeRow I hI Q) W X‖ ≤
        C*(Ideal.absNorm (Ideal.span {c}):ℝ)^(3/2:ℝ)*sourceCost I Q*
          X^(-(1/2):ℝ) := by
  obtain ⟨K,hK,hbound⟩ :=
    QRHExperimental.CompositeControlledReflection.smoothedValue_composite_uniform_bound
      W lo hi hlo hsupp hW
  refine ⟨‖thetaDerivativeScalar⁻¹‖*(K*16), by positivity, ?_⟩
  intro I Q hI hQ c hc hcQ φ hφ hφn X hX
  letI : Finite (Eis ⧸ Ideal.span {c}) := finite_quotient_span hc
  letI : Fintype (Eis ⧸ Ideal.span {c}) := Fintype.ofFinite _
  letI : ∀ P : FreePrimeIndex I Q,
      (Ideal.span {freePrimaryPrime I Q P}:Ideal Eis).IsMaximal :=
    freePrimaryPrime_maximal I Q hI
  let G : ∀ h : Eis ⧸ Ideal.span {c}, FixedFourierGeometry c h :=
    fixedFourierGeometry c hc
  let f : (Eis ⧸ Ideal.span {c}) → Finset (FreePrimeIndex I Q) → ℂ := fun h A =>
    (freePrimaryControlledStratum I Q hI c hcQ h (G h) A).smoothedValue
      (mul_dvd_mul_left 9 (G h).denominator_dvd)
      (primary_finset_product Finset.univ (fun P:A => freePrimaryPrime I Q P.val)
        (fun P _ => freePrimaryPrime_primary I Q hI P.val))
      (G h).primary (G h).shape (fun P => freePrimaryPrime_ne_zero I Q hI P.val)
      (G h).denominator_ne_zero (fun P => freePrimaryPrime_good I Q hI P.val)
      (fun P => freeExponent I Q P.val) W X
  have hf (h : Eis ⧸ Ideal.span {c}) (A : Finset (FreePrimeIndex I Q)) :
      ‖f h A‖ ≤ ((K*16)*(Ideal.absNorm (Ideal.span {c}):ℝ)*X^(-(1/2):ℝ))*
        ∏ P ∈ A, activeCost (primeNorm I Q P) (freeExponent I Q P) := by
    let z : Eis := ∏ P : A, freePrimaryPrime I Q P.val
    have hz : z ≠ 0 := Finset.prod_ne_zero_iff.mpr
      (fun P _ => freePrimaryPrime_ne_zero I Q hI P.val)
    have hznorm : (Ideal.absNorm (Ideal.span {z}):ℝ) =
        ∏ P : A, primeNorm I Q P.val := by
      simp only [z,FiniteGaussPhase.span_finset_prod,map_prod,Nat.cast_prod,primeNorm]
    have hprod : (∏ P : A, primeNorm I Q P.val) *
        (∏ P : A, localReflectionCost (primeNorm I Q P.val) (freeExponent I Q P.val)) =
        ∏ P ∈ A, activeCost (primeNorm I Q P) (freeExponent I Q P) := by
      rw [←Finset.prod_mul_distrib]
      exact Finset.prod_coe_sort A
        (fun P : FreePrimeIndex I Q => activeCost (primeNorm I Q P) (freeExponent I Q P))
    have hcop : Pairwise (Function.onFun IsCoprime
        (fun P : A => (Ideal.span {freePrimaryPrime I Q P.val}:Ideal Eis))) := by
      intro P R hPR
      exact freePrimaryPrime_coprime I Q hI (fun he => hPR (Subtype.ext he))
    have hb := hbound A (fun P : A => freePrimaryPrime I Q P.val)
      (9*c) (G h).a0 (G h).c0 (G h).mode
      (freePrimaryControlledStratum I Q hI c hcQ h (G h) A)
      (mul_dvd_mul_left 9 (G h).denominator_dvd)
      (primary_finset_product Finset.univ (fun P:A => freePrimaryPrime I Q P.val)
        (fun P _ => freePrimaryPrime_primary I Q hI P.val))
      (G h).primary (G h).shape (fun P => freePrimaryPrime_ne_zero I Q hI P.val)
      (G h).denominator_ne_zero hcop (fun P => freePrimaryPrime_good I Q hI P.val)
      (fun P => freePrimaryPrime_odd I Q hI P.val)
      (fun P => freeExponent I Q P.val) (fun P => freeExponent_lt I Q P.val)
      X hX
    have hs := cusp_scale_power_le (G h).shape.index (G h).c0 c z
      (G h).denominator_ne_zero hc hz (G h).denominator_dvd X hX
    have hlocal : 0 ≤ ∏ P : A,
        localReflectionCost (primeNorm I Q P.val) (freeExponent I Q P.val) := by
      apply Finset.prod_nonneg
      intro P hP
      exact localReflectionCost_nonneg _ (primeNorm_pos I Q hI P.val) _
    calc
      _ ≤ K*(∏ P : A, localReflectionCost (primeNorm I Q P.val) (freeExponent I Q P.val))*
          (X/(27*(sourceCuspScale (G h).shape.index)^2*
          (Ideal.absNorm (Ideal.span {(G h).c0*z}):ℝ)^2))^(-(1/2):ℝ) := hb
      _ ≤ K*(∏ P : A, localReflectionCost (primeNorm I Q P.val) (freeExponent I Q P.val))*
          (16*(Ideal.absNorm (Ideal.span {c}):ℝ)*
          (Ideal.absNorm (Ideal.span {z}):ℝ)*X^(-(1/2):ℝ)) :=
        mul_le_mul_of_nonneg_left hs (mul_nonneg hK hlocal)
      _ = ((K*16)*(Ideal.absNorm (Ideal.span {c}):ℝ)*X^(-(1/2):ℝ))*
          ((∏ P : A, primeNorm I Q P.val)*
          (∏ P : A, localReflectionCost (primeNorm I Q P.val) (freeExponent I Q P.val))) := by
        rw [hznorm]
        ring
      _ = _ := by rw [hprod]
  have hsum (h : Eis ⧸ Ideal.span {c}) :
      ‖∑ A : Finset (FreePrimeIndex I Q),
        primeInactiveFourierWeight (freePrimaryPrime I Q)
          (freePrimaryPrime_ne_zero I Q hI) (freePrimaryPrime_good I Q hI)
          (freeExponent I Q) A*f h A‖ ≤
      (K*16)*(Ideal.absNorm (Ideal.span {c}):ℝ)*sourceCost I Q*X^(-(1/2):ℝ) := by
    have hb := weighted_active_norm_bound
      (freePrimaryPrime I Q) (freePrimaryPrime_ne_zero I Q hI)
      (freePrimaryPrime_good I Q hI) (freePrimaryPrime_odd I Q hI)
      (freeExponent I Q) (freeExponent_lt I Q)
      (fun P => activeCost (primeNorm I Q P) (freeExponent I Q P))
      (f h) ((K*16)*(Ideal.absNorm (Ideal.span {c}):ℝ)*X^(-(1/2):ℝ)) (hf h)
    exact hb.trans_eq (by unfold sourceCost primeNorm; ring)
  rw [fixedFree_completedT_eq_actualControlledSource I Q hI hQ c hc hcQ G
    φ hφ hφn W lo hi hlo hsupp hW X hX]
  change ‖thetaDerivativeScalar⁻¹ * ∑ h, fixedThetaRowCoeff c hc φ h *
    ∑ A : Finset (FreePrimeIndex I Q),
      primeInactiveFourierWeight (freePrimaryPrime I Q)
        (freePrimaryPrime_ne_zero I Q hI) (freePrimaryPrime_good I Q hI)
        (freeExponent I Q) A * f h A‖ ≤ _
  exact fixed_base_sum_bound c hc φ hφn
    (fun h => ∑ A : Finset (FreePrimeIndex I Q),
      primeInactiveFourierWeight (freePrimaryPrime I Q)
        (freePrimaryPrime_ne_zero I Q hI) (freePrimaryPrime_good I Q hI)
        (freeExponent I Q) A*f h A)
    (K*16) (sourceCost I Q) X (by positivity) (sourceCost_pos I Q hI).le hX hsum

theorem completedT_composite_period_bound
    (W : ℝ → ℂ) (lo hi : ℝ) (hlo : 0 < lo)
    (hsupp : Function.support W ⊆ Set.Icc lo hi) (hW : ContDiff ℝ ∞ W) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (I Q : Ideal Eis) (hI : Supported I),
      Q ≠ 0 →
      ∀ (φ : Eis →* ℂ), CanonicalCoefficientClass.FactorsModulo Q φ →
      (∀ n, ‖φ n‖ ≤ 1) → ∀ X : ℝ, 0 < X →
      ‖completedT (φ*freePrimeRow I hI Q) W X‖ ≤
        C*(Ideal.absNorm Q:ℝ)^(3/2:ℝ)*sourceCost I Q*X^(-(1/2):ℝ) := by
  obtain ⟨K,hK,hb⟩ := completedT_composite_reflected_bound W lo hi hlo hsupp hW
  refine ⟨K*(81:ℝ)^(3/2:ℝ), by positivity, ?_⟩
  intro I Q hI hQ φ hφ hφn X hX
  obtain ⟨c,hc,heq,hnorm⟩ := QRHExperimental.IdealConductorBound.period_generator Q hQ
  have h := hb I Q hI hQ c hc heq φ hφ hφn X hX
  rw [hnorm,Real.mul_rpow (by norm_num) (Nat.cast_nonneg _)] at h
  exact h.trans_eq (by ring)

theorem rawProjection_composite
    (W : ℝ → ℂ) (lo hi : ℝ) (hlo : 0 < lo)
    (hsupp : Function.support W ⊆ Set.Icc lo hi) (hW : ContDiff ℝ ∞ W) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (I Q : Ideal Eis) (hI : Supported I),
      Q ≠ 0 →
      ∀ (φ : Eis →* ℂ), CanonicalCoefficientClass.FactorsModulo Q φ →
      (∀ n, ‖φ n‖ ≤ 1) → ∀ L : ℝ, 0 < L →
      ‖rawProjection (φ*freePrimeRow I hI Q) W L‖ ≤
        C*Real.sqrt L*(Ideal.absNorm Q:ℝ)^(3/4:ℝ)*(sourceCost I Q)^(1/2:ℝ) := by
  obtain ⟨K0,hK0,h0⟩ := QRHExperimental.UniformTrivial.uniform_trivial_bounds
    W lo hi hsupp hW.continuous
  obtain ⟨K1,hK1,h1⟩ := completedT_composite_period_bound W lo hi hlo hsupp hW
  refine ⟨513*K0+128*K1, by positivity, ?_⟩
  intro I Q hI hQ φ hφ hφn L hL
  let Ψ := φ*freePrimeRow I hI Q
  have hΨ : ∀ n, ‖Ψ n‖ ≤ 1 := fixedFreeRow_norm I hI Q φ hφn
  let R : ℝ := (Ideal.absNorm Q:ℝ)^(3/2:ℝ)*sourceCost I Q
  have hQpos : 0 < (Ideal.absNorm Q:ℝ) :=
    nonzeroIdeal_norm_pos ⟨Q,hQ⟩
  have hR : 0 < R := mul_pos (Real.rpow_pos_of_pos hQpos _) (sourceCost_pos I Q hI)
  have hb := rawProjection_bound_of_completed_bounds Ψ hΨ W
    (HasCompactSupport.of_support_subset_isCompact isCompact_Icc hsupp)
    L R (1/2) (1/2) K0 K1 hL hR (by norm_num) hK0 hK1
    (h0 Ψ hΨ L hL).1 (fun y hy => (h0 Ψ hΨ y hy).2)
    (by
      intro y hy
      simpa only [show (1/2:ℝ)*(2*(1/2)+1)=1 by norm_num, Real.rpow_one,
        R,mul_assoc] using h1 I Q hI hQ φ hφ hφn y hy)
  have he : R^(1/2:ℝ) =
      (Ideal.absNorm Q:ℝ)^(3/4:ℝ)*(sourceCost I Q)^(1/2:ℝ) := by
    dsimp only [R]
    rw [Real.mul_rpow (Real.rpow_nonneg hQpos.le _) (sourceCost_pos I Q hI).le,
      ←Real.rpow_mul hQpos.le]
    norm_num
  rw [he] at hb
  exact hb.trans_eq (by ring)

#print axioms completedT_composite_reflected_bound
#print axioms completedT_composite_period_bound
#print axioms rawProjection_composite
end
end QRHExperimental.CompositeProjection
