import CompositeProjection

/-! Exact local ideal-norm table for the actual mixed projection theorem. -/
namespace QRHExperimental.CompositeProjectionCosts
noncomputable section
open OAI OAI.ActualEisensteinCubic OAI.CubicEisenstein OAI.CompletedGauss
open OAI.CanonicalQuadraticSieve OAI.CanonicalRowCompletion OAI.ConcreteTraceCRT
open QRHExperimental.CompositeProjection QRHExperimental.NonexceptionalProjection
open QRHExperimental.CompositeBracketDomination QRHExperimental.ActiveStratumBound
open QRHExperimental.TrivialProjection
open scoped BigOperators Classical ContDiff
local notation "Eis" => OAI.ActualEisensteinCubic.O

lemma mul_neg_half (q : ℝ) (hq : 0 < q) : q*q^(-(1/2):ℝ) = q^(1/2:ℝ) := by
  conv_lhs => lhs; rw [←Real.rpow_one q]
  rw [←Real.rpow_add hq]
  norm_num

lemma mul_neg_two (q : ℝ) (hq : 0 < q) : q*q^(-2:ℝ) = q⁻¹ := by
  conv_lhs => lhs; rw [←Real.rpow_one q]
  rw [←Real.rpow_add hq]
  norm_num only
  exact Real.rpow_neg_one q

lemma activeCost_zero (q : ℝ) (hq : 0 < q) : activeCost q 0 = q^(1/2:ℝ) := by
  simpa [activeCost,localReflectionCost] using mul_neg_half q hq

lemma activeCost_fourth (q : ℝ) (hq : 0 < q) :
    activeCost q 4 = 2*q^(1/2:ℝ)+q⁻¹ := by
  simp only [activeCost,localReflectionCost,show (4:ℕ)≠0 by decide,if_false,ite_true]
  rw [mul_add,←mul_assoc, mul_comm q 2,mul_assoc,mul_neg_half q hq,mul_neg_two q hq]

lemma activeCost_nonexceptional (q : ℝ) (j : ℕ) (h0 : j ≠ 0) (h4 : j ≠ 4) :
    activeCost q j = q := by simp [activeCost,localReflectionCost,h0,h4]

def primeCost (q : ℝ) (j : ℕ) : ℝ :=
  if j = 0 then 1-q⁻¹+q^(1/2:ℝ) else
    if j = 4 then 2*q^(1/2:ℝ)+q⁻¹ else q

lemma active_inactive_eq_primeCost (q : ℝ) (hq : 0 < q) (j : ℕ) :
    activeCost q j+inactiveCost q j = primeCost q j := by
  by_cases h0 : j = 0
  · subst j
    rw [activeCost_zero q hq]
    simp only [inactiveCost,primeCost,ite_true]
    ring
  by_cases h4 : j = 4
  · subst j
    rw [activeCost_fourth q hq]
    simp [inactiveCost,primeCost]
  · simp [activeCost_nonexceptional q j h0 h4,inactiveCost,primeCost,h0,h4]

lemma sourceCost_eq_prime_product (I Q : Ideal Eis) (hI : Supported I) :
    sourceCost I Q = ∏ P : FreePrimeIndex I Q,
      primeCost (Ideal.absNorm P.val.val:ℝ) (freeExponent I Q P) := by
  unfold sourceCost
  apply Finset.prod_congr rfl
  intro P hP
  rw [active_inactive_eq_primeCost _ (primeNorm_pos I Q hI P),primeNorm_eq I Q hI P]

theorem rawProjection_composite_prime_product
    (W : ℝ → ℂ) (lo hi : ℝ) (hlo : 0 < lo)
    (hsupp : Function.support W ⊆ Set.Icc lo hi) (hW : ContDiff ℝ ∞ W) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (I Q : Ideal Eis) (hI : Supported I), Q ≠ 0 →
      ∀ (φ : Eis →* ℂ), CanonicalCoefficientClass.FactorsModulo Q φ →
      (∀ n, ‖φ n‖ ≤ 1) → ∀ L : ℝ, 0 < L →
      ‖rawProjection (φ*freePrimeRow I hI Q) W L‖ ≤
        C*Real.sqrt L*(Ideal.absNorm Q:ℝ)^(3/4:ℝ)*
          (∏ P : FreePrimeIndex I Q,
            primeCost (Ideal.absNorm P.val.val:ℝ) (freeExponent I Q P))^(1/2:ℝ) := by
  obtain ⟨C,hC,hb⟩ := rawProjection_composite W lo hi hlo hsupp hW
  refine ⟨C,hC,?_⟩
  intro I Q hI hQ φ hφ hφn L hL
  rw [←sourceCost_eq_prime_product I Q hI]
  exact hb I Q hI hQ φ hφ hφn L hL

#print axioms activeCost_zero
#print axioms activeCost_fourth
#print axioms sourceCost_eq_prime_product
#print axioms rawProjection_composite_prime_product
end
end QRHExperimental.CompositeProjectionCosts
