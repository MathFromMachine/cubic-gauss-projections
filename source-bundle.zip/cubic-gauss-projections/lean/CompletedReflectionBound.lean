import UniformReflectionBound

/-! A uniform conductor bound for the actual completed smoothed sum,
using the canonical cusp reflection, source cusp height, and normalized
finite Fourier Parseval. The profile W and exponent s remain fixed. -/
namespace QRHExperimental.CompletedReflectionBound
noncomputable section
set_option maxHeartbeats 2000000
open OAI OAI.ActualEisensteinCubic OAI.ConcreteTraceCRT
open OAI.CubicEisenstein OAI.CompletedGauss
open QRHExperimental.UniformReflectionBound
open scoped BigOperators Classical ContDiff
local notation "Eis" => OAI.ActualEisensteinCubic.O

theorem completedT_uniform_reflected_bound
    (W : ℝ → ℂ) (v0 v1 : ℝ) (hv0 : 0 < v0)
    (hWs : Function.support W ⊆ Set.Icc v0 v1) (hW : ContDiff ℝ ∞ W)
    (s : ℝ) (hs : 1/2 < s) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (Ψ : Eis →* ℂ), (∀ x, ‖Ψ x‖ ≤ 1) →
      ∀ (Q : Ideal Eis), CanonicalCoefficientClass.FactorsModulo Q Ψ →
      ∀ (c : Eis), c ≠ 0 → Ideal.span {c} ≤ Ideal.span {(9:Eis)}*Q →
      ∀ (X : ℝ), 0 < X →
      ‖completedT Ψ W X‖ ≤ C * (Ideal.absNorm (Ideal.span {c}):ℝ)^(2*s+1/2) * X^(-s) := by
  obtain ⟨K, hK, hk⟩ := smoothedKernel_uniform_height_bound W v0 v1 hv0 hWs hW s hs
  refine ⟨‖thetaDerivativeScalar⁻¹‖ * K, mul_nonneg (norm_nonneg _) hK, ?_⟩
  intro Ψ hΨ Q hperiod c hc hcQ X hX
  let : Finite (Eis ⧸ Ideal.span {c}) := finite_quotient_span hc
  let : Fintype (Eis ⧸ Ideal.span {c}) := Fintype.ofFinite _
  let R : ℝ := (Ideal.absNorm (Ideal.span {c}):ℝ)
  have hcard : (Fintype.card (Eis ⧸ Ideal.span {c}) : ℝ) = R := by
    congr 1
    rw [← Nat.card_eq_fintype_card, ← Submodule.cardQuot_apply, ← Ideal.absNorm_apply]
  have hR : 0 < R := by
    rw [← hcard]
    exact_mod_cast Fintype.card_pos (α := Eis ⧸ Ideal.span {c})
  let a : (Eis ⧸ Ideal.span {c}) → ℂ :=
    finiteAdditiveFourierCoeff (quotientTrace c hc) (fixedThetaQuotient Ψ c)
  have hparseval : (∑ h, ‖a h‖)^2 ≤ R := by
    rw [← hcard]
    exact QRHExperimental.FiniteFourierMass.normalized_fourier_l1_sq_le_card
      (quotientTrace c hc) (GeneralPrimitiveTrace.eisTraceModChar_breveE_primitive c hc)
      (fixedThetaQuotient Ψ c) (fixedThetaQuotient_norm_le_one Ψ hΨ c)
  have hl1 : (∑ h, ‖a h‖) ≤ Real.sqrt R := by
    have hn : 0 ≤ ∑ h, ‖a h‖ := Finset.sum_nonneg (fun _ _ => norm_nonneg _)
    have hr := Real.sq_sqrt hR.le
    have hr0 := Real.sqrt_nonneg R
    nlinarith
  have hkernel (h : Eis ⧸ Ideal.span {c}) :
      ‖(finiteTwistCusp c hc h).smoothedKernel W X‖ ≤ K * R^(2*s) * X^(-s) := by
    apply (hk (finiteTwistCusp c hc h) X hX).trans
    apply mul_le_mul_of_nonneg_right _ (Real.rpow_nonneg hX.le _)
    apply mul_le_mul_of_nonneg_left _ hK
    exact Real.rpow_le_rpow (finiteTwistCusp c hc h).heightScale_pos.le
      (QRHExperimental.CuspHeight.finiteTwistCusp_heightScale_le c hc h) (by linarith)
  have hsum : ‖∑ h, a h * (finiteTwistCusp c hc h).smoothedKernel W X‖ ≤
      K * R^(2*s+1/2) * X^(-s) := by
    calc
      _ ≤ ∑ h, ‖a h * (finiteTwistCusp c hc h).smoothedKernel W X‖ := norm_sum_le _ _
      _ ≤ ∑ h, ‖a h‖ * (K * R^(2*s) * X^(-s)) := by
        apply Finset.sum_le_sum
        intro h hh
        rw [norm_mul]
        exact mul_le_mul_of_nonneg_left (hkernel h) (norm_nonneg _)
      _ = (∑ h, ‖a h‖) * (K * R^(2*s) * X^(-s)) := (Finset.sum_mul _ _ _).symm
      _ ≤ Real.sqrt R * (K * R^(2*s) * X^(-s)) :=
        mul_le_mul_of_nonneg_right hl1 (by positivity)
      _ = _ := by
        rw [Real.sqrt_eq_rpow, Real.rpow_add hR]
        ring
  rw [completedT_canonical_smoothed_reflection Ψ hΨ Q hperiod c hc hcQ
    W v0 v1 hv0 hWs hW X hX, norm_mul]
  exact (mul_le_mul_of_nonneg_left hsum (norm_nonneg _)).trans_eq (by ring)

#print axioms completedT_uniform_reflected_bound
end
end QRHExperimental.CompletedReflectionBound
