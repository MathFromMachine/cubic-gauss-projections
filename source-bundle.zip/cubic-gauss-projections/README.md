# Smooth cubic-Gauss projections with coprimality masks

A proof companion for an explicit mixed-prime bound over the Eisenstein
integers and an inexpensive separate coprimality-mask corollary.

- [Complete proof, definitions, and normalization](PROOF.txt)
- [Readable Lean theorem entry points](lean/FinalTheorems.lean)
- [HTML proof companion](index.html)
- [Reproduction instructions and verification limits](README.txt)
- [Source and dependency manifest](sources.json)
- [Verification summary](verification-summary.json)
- [SHA-256 checksums](SHA256SUMS)

For a fixed smooth profile, the mixed bound is
`C_W sqrt(L) (NQ)^(3/4) sqrt(product d_j(Np))`, where
`d_0(q)=1-1/q+sqrt(q)`, `d_4(q)=2sqrt(q)+1/q`, and the other local costs
are `q`. All source masks and the Gauss normalization are retained.
A separate admissible mask, coprime to the fixed modulus and the moving
ideal, costs `product [1+sqrt(2q^(-1/2)+q^(-2))]`, hence at most an
arbitrarily small power of its norm. See the precise quantifiers and
overlap qualifications in the proof.

## Recheck

A prebuilt OAI Lake project at the recorded pins and Lean 4.34.1 are required.
From this directory:

```sh
sha256sum -c SHA256SUMS
python3 reproduce.py check
python3 reproduce.py verify-env ../qrh-reproduction/project
python3 reproduce.py build ../qrh-reproduction/project
```

Replace the project path with your prepared environment. Builds use one
Lean process at a time and at most two threads. Generated files go in
`build/`; they are excluded from the source archive. Details are in
[README.txt](README.txt).

## Scope and provenance

This is a formalization checkpoint. No new zero-free endpoint, RH result,
optimality, or established analytic novelty is claimed. The cubic
specialization overlaps the adjacent Patterson angular estimates in the
pinned [OpenAI mathematics source](https://github.com/openai/math/tree/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb).
The added assembly was developed with AI assistance. Existing source
notices and the [upstream Lean license](config/OPENAI-LEAN-LICENSE) are retained.

The receipt records ordinary module compilation using the three standard
axioms. It is not a new exported-proof replay, second-kernel verification,
full foundation rebuild, or external peer review.
